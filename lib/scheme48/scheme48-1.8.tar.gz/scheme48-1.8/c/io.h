/* Copyright (c) 1993-2008 by Richard Kelsey and Jonathan Rees.
   See file COPYING. */

#include <stdio.h>

extern FILE	*ps_open_input_file(char *, long *);
extern FILE	*ps_open_output_file(char *, long *);
extern long	ps_close(FILE *);
extern char	ps_read_char(FILE *, char *, long *, char);
extern long	ps_read_integer(FILE *, char *, long *);
extern long	ps_write_char(char, FILE *);
extern long	ps_write_integer(long, FILE *);
extern long	ps_write_string(char *, FILE *);
extern long	ps_read_block(FILE *, char *, long, char *, long *);
extern long	ps_write_block(FILE *, char *, long);
extern char	*ps_error_string(long);
extern void	ps_error(char *, long count, ...);
