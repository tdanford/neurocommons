#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "prescheme.h"
#include "scheme48vm-prelude.h"

struct image_location {
  long new_descriptor;
  long next;
};
struct table {
  long *keys;
  struct image_location **values;
  long count;
  long size;
};
struct event_type {
  long uid;
  char usedP;
  struct event_type *next;
};
static char add_more_channels(long);
static void use_event_type_uidB(long);
static char add_external_event_types(long);
static char encode_scalar_value(long, long, char *, long, char*, char*, long*);
static char decode_scalar_value(long, char *, long, char*, char*, long*, long*);
static char integerLE(long, long);
static char integerGE(long, long);
static char shared_binding_undefinedP(long);
static void enqueue_channelB(long, long, long);
static void decode_utf_8B(char *, long, long);
static void copy_vm_string_to_stringUlatin_1B(long, long, long, char*);
static long close_channelB(long);
static long make_blank_return_code(long, long, long, long, long);
static long enter_stringAgc_n(char*, long);
static long add_log_entryAgc(long, long, long, long, long, char);
static long enter_bignum(char *);
static char integerE(long, long);
static long make_channel(long, long, long, long, long, long, long, long);
static long write_vm_string(long, FILE *);
static long Haction4880(long);
static long current_code_vector(void);
static void channel_close_error(long, long, long);
static long integer_bit_count(long);
static long integer_add(long, long);
static long integer_subtract(long, long);
static long integer_multiply(long, long);
static long integer_bitwise_not(long);
static long integer_bitwise_and(long, long);
static long integer_bitwise_ior(long, long);
static long integer_bitwise_xor(long, long);
static long Hinteger_op8281(long, long);
static long Hinteger_op8212(long, long);
static char for_each_imported_binding(char(*)(long));
static long really_preserve_continuation(long);
static void push_exception_setupB(long, long);
static long Hlookup833(long, long, long);
static long Hlookup814(long, long, long);
static void HtopD11605(char, char);
static void HtopD11616(void);
static long unused_event_type_uid(void);
void s48_set_native_protocolB(long);
void s48_set_extension_valueB(long);
long s48_channel_count(void);
long *s48_channels(void);
long s48_imported_bindings(void);
long s48_exported_bindings(void);
char s48_os_signal_pending(void);
long s48_symbol_table(void);
char * s48_set_gc_roots_baseB(void);
char s48_release_gc_roots_baseB(char *);
void s48_reset_external_rootsB(void);
char s48_external_event_readyPUunsafe(void);
void s48_note_event(void);
void s48_reset_interruptsB(void);
void s48_disable_interruptsB(void);
void s48_add_os_signal(long);
void s48_push_gc_rootsB(char *, long);
char * s48_register_gc_rootB(char *);
char s48_external_event_pendingPUunsafe(void);
long s48_dequeue_external_eventBUunsafe(char*);
void s48_unregister_external_event_uid(long);
void s48_note_external_eventBUunsafe(long);
void s48_stack_setB(long, long);
long s48_stack_ref(long);
void s48_push(long);
long s48_resetup_external_exception(long, long);
char s48_pop_gc_rootsB(void);
void s48_unregister_gc_rootB(char *);
char * s48_shorten_bignum(char *, long);
long s48_allocate_string(long);
long s48_allocate_bignum(long);
void s48_enable_interruptsB(void);
long s48_set_channel_os_index(long, long);
long s48_enter_string_utf_8(char *);
long s48_enter_string_utf_8_n(char *, long);
long s48_integer_or_floanum_L(long, long);
long s48_integer_or_floanum_G(long, long);
long s48_integer_or_floanum_LE(long, long);
long s48_integer_or_floanum_GE(long, long);
long s48_make_blank_return_code(long, long, long, long);
long s48_enter_string_latin_1_n(char*, long);
long s48_integer_or_floanum_E(long, long);
void s48_close_channel(long);
long s48_enter_string_latin_1(char*);
void s48_string_set(long, long, long);
long s48_string_ref(long, long);
long s48_string_length(long);
void s48_copy_latin_1_to_string_n(char*, long, long);
void s48_copy_latin_1_to_string(char*, long);
void s48_copy_string_to_latin_1(long, char*);
void s48_copy_string_to_latin_1_n(long, long, long, char*);
long s48_string_utf_8_length(long);
long s48_string_utf_8_length_n(long, long, long);
void s48_copy_string_to_utf_8(long, char *);
void s48_copy_string_to_utf_8_n(long, long, long, char *);
void check_stack(void);
long s48_really_add_channel(long, long, long);
long s48_integer_bit_count(long);
long s48_enter_integer(long);
long s48_enter_unsigned_integer(unsigned long);
long s48_integer_or_floanum_add(long, long);
long s48_integer_or_floanum_sub(long, long);
long s48_integer_or_floanum_mul(long, long);
long s48_integer_bitwise_not(long);
long s48_integer_bitwise_and(long, long);
long s48_integer_bitwise_ior(long, long);
long s48_integer_bitwise_xor(long, long);
void s48_setup_external_exception(long, long);
long s48_integer_quotient(long, long);
long s48_integer_remainder(long, long);
void s48_copy_stack_into_heap(void);
long s48_get_imported_binding(char*);
void s48_define_exported_binding(char*, long);
void s48_initialize_vm(char *, long);
void s48_post_gc_cleanup(char, char);
void s48_gc_root(void);
long s48_restart(long, long);
long s48_call_startup_procedure(char**, long);
long s48_external_event_uid(void);
long s48_permanent_external_event_uid(char*);
static long Spending_interruptsS;
static long Snumber_of_channelsS;
static long *Svm_channelsS;
static long Spending_channels_headS;
static long Spending_channels_tailS;
static long *Sutf_8_state_tableS;
static long *Sutf_8_masksS;
static long Stemp0S;
static long Stemp1S;
static char * Sstack_beginS;
static char * Sstack_endS;
static char * Sreal_stack_limitS;
static char * Sbottom_of_stackS;
static long Sheap_continuationS;
static char Sstack_warningPS;
static long Simported_bindingsS;
static long Sexported_bindingsS;
static long Snumber_of_event_typesS;
static struct event_type **Sevent_typesS;
static struct event_type *Spending_event_types_headS;
static struct event_type *Spending_event_types_tailS;
static struct event_type *Spending_event_types_readyS;
static struct event_type *Sunused_event_types_headS;
static long Sexception_handlersS;
static long Sinterrupt_handlersS;
static char * Slast_code_pointer_resumedS;
static long Scurrent_threadS;
static long Ssession_dataS;
static long Sfinalizer_alistS;
static long Sfinalize_theseS;
static char Sgc_in_troublePS;
static long Senabled_interruptsS;
static long Sinterrupted_templateS;
static long Sinterrupted_byte_opcode_return_codeS;
static long Sinterrupted_native_call_return_codeS;
static long Snative_poll_return_codeS;
static long Sexception_return_codeS;
static long Snative_exception_return_codeS;
static long Scall_with_values_return_codeS;
static long Ssaved_pcS;
static long *Sos_signal_ringS;
static long Sos_signal_ring_startS;
static long Sos_signal_ring_readyS;
static long Sos_signal_ring_endS;
static char Sexternal_exceptionPS;
static long Sexternal_exception_nargsS;
static long Sthe_symbol_tableS;
static char * Sexternal_root_stackS;
static char * Sexternal_root_stack_baseS;
static char * Spermanent_external_rootsS;
static long Sempty_logS;
static void (*Spost_gc_cleanupS)(char, char);
static void (*Sgc_root_procS)(void);
char * SstackS;
char * s48_Sstack_limitS;
char * ScontS;
char * Scode_pointerS;
long SvalS;
long Slast_code_calledS;
char s48_Spending_interruptPS;
long Snative_exception_contS;
long s48_Snative_protocolS;
long s48_Sextension_valueS;
long s48_Scallback_return_stack_blockS;
char s48_Spending_eventsPS;

static char add_more_channels(long index_7X)
{
  long arg0K0;
  long i_13X;
  long i_12X;
  long *new_vm_channels_11X;
  long new_count_10X;
  long y_9X;
  long x_8X;
 {  x_8X = 1 + index_7X;
  y_9X = 8 + (Snumber_of_channelsS);
  if ((x_8X < y_9X)) {
    arg0K0 = y_9X;
    goto L3694;}
  else {
    arg0K0 = x_8X;
    goto L3694;}}
 L3694: {
  new_count_10X = arg0K0;
  new_vm_channels_11X = (long*)malloc(sizeof(long) * new_count_10X);
  if ((NULL == new_vm_channels_11X)) {
    return 0;}
  else {
    arg0K0 = 0;
    goto L3706;}}
 L3706: {
  i_12X = arg0K0;
  if ((i_12X == (Snumber_of_channelsS))) {
    arg0K0 = (Snumber_of_channelsS);
    goto L3779;}
  else {
    *(new_vm_channels_11X + i_12X) = (*((Svm_channelsS) + i_12X));
    arg0K0 = (1 + i_12X);
    goto L3706;}}
 L3779: {
  i_13X = arg0K0;
  if ((i_13X == new_count_10X)) {
    free((Svm_channelsS));
    Svm_channelsS = new_vm_channels_11X;
    Snumber_of_channelsS = new_count_10X;
    return 1;}
  else {
    *(new_vm_channels_11X + i_13X) = 1;
    arg0K0 = (1 + i_13X);
    goto L3779;}}
}
static void use_event_type_uidB(long id_14X)
{
  struct event_type *arg1K1;
  struct event_type *arg1K0;
  struct event_type *unused_type_18X;
  struct event_type *previous_17X;
  char v_16X;
  struct event_type *type_15X;
 {  type_15X = *((Sevent_typesS) + id_14X);
  v_16X = type_15X->usedP;
  if (v_16X) {
    ps_write_string("trying to use an event uid that's already in use : ", (stderr));
    ps_write_integer(id_14X, (stderr));
    { long ignoreXX;
    PS_WRITE_CHAR(10, (stderr), ignoreXX) }
    ps_error("assertion violation", 0);
    goto L3967;}
  else {
    goto L3967;}}
 L3967: {
  type_15X->usedP = 1;
  arg1K0 = (NULL);
  arg1K1 = (Sunused_event_types_headS);
  goto L3974;}
 L3974: {
  previous_17X = arg1K0;
  unused_type_18X = arg1K1;
  if ((NULL == unused_type_18X)) {
    goto L4063;}
  else {
    if ((type_15X == unused_type_18X)) {
      if ((NULL == previous_17X)) {
        Sunused_event_types_headS = (unused_type_18X->next);
        goto L4063;}
      else {
        previous_17X->next = (unused_type_18X->next);
        goto L4063;}}
    else {
      arg1K0 = unused_type_18X;
      arg1K1 = (unused_type_18X->next);
      goto L3974;}}}
 L4063: {
  type_15X->next = (NULL);
  return;}
}
static char add_external_event_types(long min_count_19X)
{
  long arg0K0;
  struct event_type *arg1K0;
  struct event_type *t_26X;
  struct event_type *event_type_25X;
  struct event_type *next_24X;
  long i_23X;
  struct event_type **new_event_types_22X;
  long old_count_21X;
  struct event_type **old_event_types_20X;
 {  old_event_types_20X = Sevent_typesS;
  old_count_21X = Snumber_of_event_typesS;
  new_event_types_22X = (struct event_type**)malloc(sizeof(struct event_type*) * min_count_19X);
  if ((NULL == new_event_types_22X)) {
    return 0;}
  else {
    arg0K0 = 0;
    goto L5437;}}
 L5437: {
  i_23X = arg0K0;
  if ((i_23X == min_count_19X)) {
    Sevent_typesS = new_event_types_22X;
    Snumber_of_event_typesS = min_count_19X;
    free(old_event_types_20X);
    return 1;}
  else {
    if ((i_23X < old_count_21X)) {
      *(new_event_types_22X + i_23X) = (*(old_event_types_20X + i_23X));
      arg0K0 = (1 + i_23X);
      goto L5437;}
    else {
      next_24X = Sunused_event_types_headS;
      event_type_25X = (struct event_type*)malloc(sizeof(struct event_type));
      if ((NULL == event_type_25X)) {
        arg1K0 = event_type_25X;
        goto L5453;}
      else {
        event_type_25X->uid = i_23X;
        event_type_25X->usedP = 0;
        event_type_25X->next = next_24X;
        arg1K0 = event_type_25X;
        goto L5453;}}}}
 L5453: {
  t_26X = arg1K0;
  if ((NULL == t_26X)) {
    Sevent_typesS = new_event_types_22X;
    Snumber_of_event_typesS = i_23X;
    return 0;}
  else {
    *(new_event_types_22X + i_23X) = t_26X;
    Sunused_event_types_headS = t_26X;
    arg0K0 = (1 + i_23X);
    goto L5437;}}
}
static char encode_scalar_value(long encoding_27X, long value_28X, char * buffer_29X, long count_30X, char *TT0, char *TT1, long *TT2)
{
  long word_34X;
  long word_33X;
  long word_32X;
  long word_31X;
 {  if ((0 == encoding_27X)) {
    if ((count_30X < 1)) {
      *TT0 = 1;
      *TT1 = 1;
      *TT2 = 1;
      return 1;}
    else {
      if ((value_28X < 128)) {
        *((unsigned char *) buffer_29X) = (unsigned char) (value_28X);
        *TT0 = 1;
        *TT1 = 0;
        *TT2 = 1;
        return 1;}
      else {
        *TT0 = 0;
        *TT1 = 0;
        *TT2 = 0;
        return 1;}}}
  else {
    if ((1 == encoding_27X)) {
      if ((count_30X < 1)) {
        *TT0 = 1;
        *TT1 = 1;
        *TT2 = 1;
        return 1;}
      else {
        if ((value_28X < 256)) {
          *((unsigned char *) buffer_29X) = (unsigned char) (value_28X);
          *TT0 = 1;
          *TT1 = 0;
          *TT2 = 1;
          return 1;}
        else {
          *TT0 = 0;
          *TT1 = 0;
          *TT2 = 0;
          return 1;}}}
    else {
      if ((2 == encoding_27X)) {
        if ((127 < value_28X)) {
          if ((2047 < value_28X)) {
            if ((65535 < value_28X)) {
              if ((count_30X < 4)) {
                *TT0 = 1;
                *TT1 = 1;
                *TT2 = 4;
                return 1;}
              else {
                *((unsigned char *) buffer_29X) = (unsigned char) ((240 + ((long)(((unsigned long)(1835008 & value_28X))>>18))));
                *((unsigned char *) (buffer_29X + 1)) = (unsigned char) ((128 + ((long)(((unsigned long)(258048 & value_28X))>>12))));
                *((unsigned char *) (buffer_29X + 2)) = (unsigned char) ((128 + ((long)(((unsigned long)(4032 & value_28X))>>6))));
                *((unsigned char *) (buffer_29X + 3)) = (unsigned char) ((128 + (63 & value_28X)));
                *TT0 = 1;
                *TT1 = 0;
                *TT2 = 4;
                return 1;}}
            else {
              if ((count_30X < 3)) {
                *TT0 = 1;
                *TT1 = 1;
                *TT2 = 3;
                return 1;}
              else {
                *((unsigned char *) buffer_29X) = (unsigned char) ((224 + ((long)(((unsigned long)(61440 & value_28X))>>12))));
                *((unsigned char *) (buffer_29X + 1)) = (unsigned char) ((128 + ((long)(((unsigned long)(4032 & value_28X))>>6))));
                *((unsigned char *) (buffer_29X + 2)) = (unsigned char) ((128 + (63 & value_28X)));
                *TT0 = 1;
                *TT1 = 0;
                *TT2 = 3;
                return 1;}}}
          else {
            if ((count_30X < 2)) {
              *TT0 = 1;
              *TT1 = 1;
              *TT2 = 2;
              return 1;}
            else {
              *((unsigned char *) buffer_29X) = (unsigned char) ((192 + ((long)(((unsigned long)(1984 & value_28X))>>6))));
              *((unsigned char *) (buffer_29X + 1)) = (unsigned char) ((128 + (63 & value_28X)));
              *TT0 = 1;
              *TT1 = 0;
              *TT2 = 2;
              return 1;}}}
        else {
          if ((count_30X < 1)) {
            *TT0 = 1;
            *TT1 = 1;
            *TT2 = 1;
            return 1;}
          else {
            *((unsigned char *) buffer_29X) = (unsigned char) (value_28X);
            *TT0 = 1;
            *TT1 = 0;
            *TT2 = 1;
            return 1;}}}
      else {
        if ((3 == encoding_27X)) {
          if ((65535 < value_28X)) {
            if ((count_30X < 4)) {
              *TT0 = 1;
              *TT1 = 1;
              *TT2 = 4;
              return 1;}
            else {
              word_31X = 55232 + ((long)(((unsigned long)value_28X)>>10));
              *((unsigned char *) buffer_29X) = (unsigned char) ((255 & word_31X));
              *((unsigned char *) (buffer_29X + 1)) = (unsigned char) (((long)(((unsigned long)word_31X)>>8)));
              word_32X = 56320 + (1023 & value_28X);
              *((unsigned char *) (buffer_29X + 2)) = (unsigned char) ((255 & word_32X));
              *((unsigned char *) (buffer_29X + 3)) = (unsigned char) (((long)(((unsigned long)word_32X)>>8)));
              *TT0 = 1;
              *TT1 = 0;
              *TT2 = 4;
              return 1;}}
          else {
            if ((count_30X < 2)) {
              *TT0 = 1;
              *TT1 = 1;
              *TT2 = 2;
              return 1;}
            else {
              *((unsigned char *) buffer_29X) = (unsigned char) ((255 & value_28X));
              *((unsigned char *) (buffer_29X + 1)) = (unsigned char) (((long)(((unsigned long)value_28X)>>8)));
              *TT0 = 1;
              *TT1 = 0;
              *TT2 = 2;
              return 1;}}}
        else {
          if ((4 == encoding_27X)) {
            if ((65535 < value_28X)) {
              if ((count_30X < 4)) {
                *TT0 = 1;
                *TT1 = 1;
                *TT2 = 4;
                return 1;}
              else {
                word_33X = 55232 + ((long)(((unsigned long)value_28X)>>10));
                *((unsigned char *) buffer_29X) = (unsigned char) (((long)(((unsigned long)word_33X)>>8)));
                *((unsigned char *) (buffer_29X + 1)) = (unsigned char) ((255 & word_33X));
                word_34X = 56320 + (1023 & value_28X);
                *((unsigned char *) (buffer_29X + 2)) = (unsigned char) (((long)(((unsigned long)word_34X)>>8)));
                *((unsigned char *) (buffer_29X + 3)) = (unsigned char) ((255 & word_34X));
                *TT0 = 1;
                *TT1 = 0;
                *TT2 = 4;
                return 1;}}
            else {
              if ((count_30X < 2)) {
                *TT0 = 1;
                *TT1 = 1;
                *TT2 = 2;
                return 1;}
              else {
                *((unsigned char *) buffer_29X) = (unsigned char) (((long)(((unsigned long)value_28X)>>8)));
                *((unsigned char *) (buffer_29X + 1)) = (unsigned char) ((255 & value_28X));
                *TT0 = 1;
                *TT1 = 0;
                *TT2 = 2;
                return 1;}}}
          else {
            if ((5 == encoding_27X)) {
              if ((count_30X < 4)) {
                *TT0 = 1;
                *TT1 = 1;
                *TT2 = 4;
                return 1;}
              else {
                *((unsigned char *) buffer_29X) = (unsigned char) ((255 & value_28X));
                *((unsigned char *) (buffer_29X + 1)) = (unsigned char) (((long)(((unsigned long)(65280 & value_28X))>>8)));
                *((unsigned char *) (buffer_29X + 2)) = (unsigned char) (((long)(((unsigned long)(16711680 & value_28X))>>16)));
                *((unsigned char *) (buffer_29X + 3)) = (unsigned char) (((long)(((unsigned long)value_28X)>>24)));
                *TT0 = 1;
                *TT1 = 0;
                *TT2 = 4;
                return 1;}}
            else {
              if ((6 == encoding_27X)) {
                if ((count_30X < 4)) {
                  *TT0 = 1;
                  *TT1 = 1;
                  *TT2 = 4;
                  return 1;}
                else {
                  *((unsigned char *) buffer_29X) = (unsigned char) (((long)(((unsigned long)value_28X)>>24)));
                  *((unsigned char *) (buffer_29X + 1)) = (unsigned char) (((long)(((unsigned long)(16711680 & value_28X))>>16)));
                  *((unsigned char *) (buffer_29X + 2)) = (unsigned char) (((long)(((unsigned long)(65280 & value_28X))>>8)));
                  *((unsigned char *) (buffer_29X + 3)) = (unsigned char) ((255 & value_28X));
                  *TT0 = 1;
                  *TT1 = 0;
                  *TT2 = 4;
                  return 1;}}
              else {
                *TT0 = 0;
                *TT1 = 0;
                *TT2 = 0;
                return 0;}}}}}}}}
}
static char decode_scalar_value(long encoding_35X, char * buffer_36X, long count_37X, char *TT0, char *TT1, long *TT2, long *TT3)
{
  long arg0K3;
  long arg0K2;
  long arg0K1;
  long arg0K0;
  long v_51X;
  long scalar_value_50X;
  long state_49X;
  long c_48X;
  long scalar_value_47X;
  long mask_46X;
  long state_45X;
  long q_44X;
  long code_point_43X;
  long code_point_42X;
  long word1_41X;
  long word0_40X;
  long word1_39X;
  long word0_38X;
 {  if ((0 == encoding_35X)) {
    *TT0 = 1;
    *TT1 = 0;
    *TT2 = (*((unsigned char *) buffer_36X));
    *TT3 = 1;
    return 1;}
  else {
    if ((1 == encoding_35X)) {
      *TT0 = 1;
      *TT1 = 0;
      *TT2 = (*((unsigned char *) buffer_36X));
      *TT3 = 1;
      return 1;}
    else {
      if ((2 == encoding_35X)) {
        arg0K0 = 0;
        arg0K1 = 0;
        arg0K2 = 0;
        arg0K3 = 0;
        goto L8130;}
      else {
        if ((3 == encoding_35X)) {
          if ((count_37X < 2)) {
            *TT0 = 1;
            *TT1 = 1;
            *TT2 = 0;
            *TT3 = 2;
            return 1;}
          else {
            word0_38X = (*((unsigned char *) buffer_36X)) + ((((*((unsigned char *) (buffer_36X + 1))))<<8));
            if ((word0_38X < 55296)) {
              *TT0 = 1;
              *TT1 = 0;
              *TT2 = word0_38X;
              *TT3 = 2;
              return 1;}
            else {
              if ((57343 < word0_38X)) {
                *TT0 = 1;
                *TT1 = 0;
                *TT2 = word0_38X;
                *TT3 = 2;
                return 1;}
              else {
                if ((count_37X < 4)) {
                  *TT0 = 1;
                  *TT1 = 1;
                  *TT2 = 0;
                  *TT3 = 4;
                  return 1;}
                else {
                  if ((56319 < word0_38X)) {
                    *TT0 = 0;
                    *TT1 = 0;
                    *TT2 = 0;
                    *TT3 = 0;
                    return 1;}
                  else {
                    word1_39X = (*((unsigned char *) (buffer_36X + 2))) + ((((*((unsigned char *) (buffer_36X + 3))))<<8));
                    if ((word1_39X < 56320)) {
                      *TT0 = 0;
                      *TT1 = 0;
                      *TT2 = 0;
                      *TT3 = 0;
                      return 1;}
                    else {
                      if ((57343 < word1_39X)) {
                        *TT0 = 0;
                        *TT1 = 0;
                        *TT2 = 0;
                        *TT3 = 0;
                        return 1;}
                      else {
                        *TT0 = 1;
                        *TT1 = 0;
                        *TT2 = ((-56557568 + (((word0_38X)<<10))) + (1023 & word1_39X));
                        *TT3 = 4;
                        return 1;}}}}}}}}
        else {
          if ((4 == encoding_35X)) {
            if ((count_37X < 2)) {
              *TT0 = 1;
              *TT1 = 1;
              *TT2 = 0;
              *TT3 = 2;
              return 1;}
            else {
              word0_40X = ((((*((unsigned char *) buffer_36X)))<<8)) + (*((unsigned char *) (buffer_36X + 1)));
              if ((word0_40X < 55296)) {
                *TT0 = 1;
                *TT1 = 0;
                *TT2 = word0_40X;
                *TT3 = 2;
                return 1;}
              else {
                if ((57343 < word0_40X)) {
                  *TT0 = 1;
                  *TT1 = 0;
                  *TT2 = word0_40X;
                  *TT3 = 2;
                  return 1;}
                else {
                  if ((count_37X < 4)) {
                    *TT0 = 1;
                    *TT1 = 1;
                    *TT2 = 0;
                    *TT3 = 4;
                    return 1;}
                  else {
                    if ((56319 < word0_40X)) {
                      *TT0 = 0;
                      *TT1 = 0;
                      *TT2 = 0;
                      *TT3 = 0;
                      return 1;}
                    else {
                      word1_41X = ((((*((unsigned char *) (buffer_36X + 2))))<<8)) + (*((unsigned char *) (buffer_36X + 3)));
                      if ((word1_41X < 56320)) {
                        *TT0 = 0;
                        *TT1 = 0;
                        *TT2 = 0;
                        *TT3 = 0;
                        return 1;}
                      else {
                        if ((57343 < word1_41X)) {
                          *TT0 = 0;
                          *TT1 = 0;
                          *TT2 = 0;
                          *TT3 = 0;
                          return 1;}
                        else {
                          *TT0 = 1;
                          *TT1 = 0;
                          *TT2 = ((-56557568 + (((word0_40X)<<10))) + (1023 & word1_41X));
                          *TT3 = 4;
                          return 1;}}}}}}}}
          else {
            if ((5 == encoding_35X)) {
              if ((count_37X < 4)) {
                *TT0 = 1;
                *TT1 = 1;
                *TT2 = 0;
                *TT3 = 4;
                return 1;}
              else {
                code_point_42X = (((*((unsigned char *) buffer_36X)) + ((((*((unsigned char *) (buffer_36X + 1))))<<8))) + ((((*((unsigned char *) (buffer_36X + 2))))<<16))) + ((((*((unsigned char *) (buffer_36X + 3))))<<24));
                if ((code_point_42X < 0)) {
                  *TT0 = 0;
                  *TT1 = 0;
                  *TT2 = 0;
                  *TT3 = 0;
                  return 1;}
                else {
                  if ((55295 < code_point_42X)) {
                    if ((code_point_42X < 57344)) {
                      *TT0 = 0;
                      *TT1 = 0;
                      *TT2 = 0;
                      *TT3 = 0;
                      return 1;}
                    else {
                      if ((1114111 < code_point_42X)) {
                        *TT0 = 0;
                        *TT1 = 0;
                        *TT2 = 0;
                        *TT3 = 0;
                        return 1;}
                      else {
                        *TT0 = 1;
                        *TT1 = 0;
                        *TT2 = code_point_42X;
                        *TT3 = 4;
                        return 1;}}}
                  else {
                    *TT0 = 1;
                    *TT1 = 0;
                    *TT2 = code_point_42X;
                    *TT3 = 4;
                    return 1;}}}}
            else {
              if ((6 == encoding_35X)) {
                if ((count_37X < 4)) {
                  *TT0 = 1;
                  *TT1 = 1;
                  *TT2 = 0;
                  *TT3 = 4;
                  return 1;}
                else {
                  code_point_43X = ((((((*((unsigned char *) buffer_36X)))<<24)) + ((((*((unsigned char *) (buffer_36X + 1))))<<16))) + ((((*((unsigned char *) (buffer_36X + 2))))<<8))) + (*((unsigned char *) (buffer_36X + 3)));
                  if ((code_point_43X < 0)) {
                    *TT0 = 0;
                    *TT1 = 0;
                    *TT2 = 0;
                    *TT3 = 0;
                    return 1;}
                  else {
                    if ((55295 < code_point_43X)) {
                      if ((code_point_43X < 57344)) {
                        *TT0 = 0;
                        *TT1 = 0;
                        *TT2 = 0;
                        *TT3 = 0;
                        return 1;}
                      else {
                        if ((1114111 < code_point_43X)) {
                          *TT0 = 0;
                          *TT1 = 0;
                          *TT2 = 0;
                          *TT3 = 0;
                          return 1;}
                        else {
                          *TT0 = 1;
                          *TT1 = 0;
                          *TT2 = code_point_43X;
                          *TT3 = 4;
                          return 1;}}}
                    else {
                      *TT0 = 1;
                      *TT1 = 0;
                      *TT2 = code_point_43X;
                      *TT3 = 4;
                      return 1;}}}}
              else {
                *TT0 = 0;
                *TT1 = 0;
                *TT2 = 0;
                *TT3 = 0;
                return 0;}}}}}}}}
 L8130: {
  q_44X = arg0K0;
  state_45X = arg0K1;
  mask_46X = arg0K2;
  scalar_value_47X = arg0K3;
  if ((q_44X < count_37X)) {
    c_48X = *((unsigned char *) (buffer_36X + q_44X));
    state_49X = *(Sutf_8_state_tableS + ((((state_45X)<<5)) + (((c_48X)>>3))));
    if ((state_49X == 0)) {
      scalar_value_50X = scalar_value_47X + (127 & c_48X);
      if ((scalar_value_50X < 0)) {
        *TT0 = 0;
        *TT1 = 0;
        *TT2 = 0;
        *TT3 = 0;
        return 1;}
      else {
        if ((55295 < scalar_value_50X)) {
          if ((scalar_value_50X < 57344)) {
            *TT0 = 0;
            *TT1 = 0;
            *TT2 = 0;
            *TT3 = 0;
            return 1;}
          else {
            if ((1114111 < scalar_value_50X)) {
              *TT0 = 0;
              *TT1 = 0;
              *TT2 = 0;
              *TT3 = 0;
              return 1;}
            else {
              goto L8145;}}}
        else {
          goto L8145;}}}
    else {
      if ((state_49X == 1)) {
        goto L8156;}
      else {
        if ((state_49X == 2)) {
          goto L8156;}
        else {
          if ((state_49X == 3)) {
            goto L8156;}
          else {
            if ((state_49X == -2)) {
              *TT0 = 0;
              *TT1 = 0;
              *TT2 = 0;
              *TT3 = 0;
              return 1;}
            else {
              if ((state_49X == -1)) {
                *TT0 = 0;
                *TT1 = 0;
                *TT2 = 0;
                *TT3 = 0;
                return 1;}
              else {
                *TT0 = 0;
                *TT1 = 0;
                *TT2 = 0;
                *TT3 = 0;
                return 1;}}}}}}}
  else {
    *TT0 = 1;
    *TT1 = 1;
    *TT2 = 0;
    *TT3 = (1 + q_44X);
    return 1;}}
 L8145: {
  *TT0 = 1;
  *TT1 = 0;
  *TT2 = scalar_value_50X;
  *TT3 = (1 + q_44X);
  return 1;}
 L8156: {
  if ((0 == mask_46X)) {
    arg0K0 = (*(Sutf_8_masksS + state_49X));
    goto L8162;}
  else {
    arg0K0 = mask_46X;
    goto L8162;}}
 L8162: {
  v_51X = arg0K0;
  arg0K0 = (1 + q_44X);
  arg0K1 = state_49X;
  arg0K2 = 63;
  arg0K3 = ((((scalar_value_47X + (c_48X & v_51X)))<<6));
  goto L8130;}
}
static char integerLE(long x_52X, long y_53X)
{
  long v_56X;
  long v_55X;
  long v_54X;
 {  if ((0 == (3 & y_53X))) {
    if ((0 == (3 & x_52X))) {
      if ((y_53X < x_52X)) {
        return 0;}
      else {
        return 1;}}
    else {
      v_54X = s48_bignum_test((((char *) (-3 + x_52X))));
      if ((1 == v_54X)) {
        return 0;}
      else {
        return 1;}}}
  else {
    if ((0 == (3 & x_52X))) {
      v_55X = s48_bignum_test((((char *) (-3 + y_53X))));
      if ((1 == v_55X)) {
        return 1;}
      else {
        return 0;}}
    else {
      v_56X = s48_bignum_compare((((char *) (-3 + y_53X))), (((char *) (-3 + x_52X))));
      if ((-1 == v_56X)) {
        return 0;}
      else {
        return 1;}}}}
}
static char integerGE(long x_57X, long y_58X)
{
  long v_61X;
  long v_60X;
  long v_59X;
 {  if ((0 == (3 & x_57X))) {
    if ((0 == (3 & y_58X))) {
      if ((x_57X < y_58X)) {
        return 0;}
      else {
        return 1;}}
    else {
      v_59X = s48_bignum_test((((char *) (-3 + y_58X))));
      if ((1 == v_59X)) {
        return 0;}
      else {
        return 1;}}}
  else {
    if ((0 == (3 & y_58X))) {
      v_60X = s48_bignum_test((((char *) (-3 + x_57X))));
      if ((1 == v_60X)) {
        return 1;}
      else {
        return 0;}}
    else {
      v_61X = s48_bignum_compare((((char *) (-3 + x_57X))), (((char *) (-3 + y_58X))));
      if ((-1 == v_61X)) {
        return 0;}
      else {
        return 1;}}}}
}
static char shared_binding_undefinedP(long binding_62X)
{

 {  return (17 == (255 & (*((long *) ((((char *) (-3 + binding_62X))) + 8)))));}
}
static void enqueue_channelB(long index_63X, long status_64X, long errorP_65X)
{
  char * addr_71X;
  long x_70X;
  char * addr_69X;
  char * addr_68X;
  long val_67X;
  long channel_66X;
 {  channel_66X = *((Svm_channelsS) + index_63X);
  val_67X = ((status_64X)<<2);
  addr_68X = (((char *) (-3 + channel_66X))) + 20;S48_WRITE_BARRIER(channel_66X, addr_68X, val_67X);
  *((long *) addr_68X) = (long) (val_67X);
  addr_69X = (((char *) (-3 + channel_66X))) + 24;S48_WRITE_BARRIER(channel_66X, addr_69X, errorP_65X);
  *((long *) addr_69X) = (long) (errorP_65X);
  if ((1 == (*((long *) ((((char *) (-3 + channel_66X))) + 16))))) {
    if ((channel_66X == (Spending_channels_headS))) {
      return;}
    else {
      if ((channel_66X == (Spending_channels_tailS))) {
        return;}
      else {
        if ((1 == (Spending_channels_headS))) {
          Spending_channels_headS = channel_66X;
          Spending_channels_tailS = channel_66X;
          return;}
        else {
          x_70X = Spending_channels_tailS;
          addr_71X = (((char *) (-3 + x_70X))) + 16;S48_WRITE_BARRIER(x_70X, addr_71X, channel_66X);
          *((long *) addr_71X) = (long) (channel_66X);
          Spending_channels_tailS = channel_66X;
          return;}}}}
  else {
    return;}}
}
static void decode_utf_8B(char * p_72X, long s_73X, long size_74X)
{
  long arg0K2;
  long arg0K1;
  long arg0K0;
  long shifted_90X;
  long j_89X;
  long bits_88X;
  long shifted_87X;
  long j_86X;
  long bits_85X;
  long shifted_84X;
  long j_83X;
  long bits_82X;
  long count_81X;
  long value_80X;
  char incompleteP_79X;
  char v_78X;
  char encoding_okP_77X;
  long target_index_76X;
  long index_75X;
 {  arg0K0 = 0;
  arg0K1 = 0;
  goto L14872;}
 L14872: {
  index_75X = arg0K0;
  target_index_76X = arg0K1;
  if ((index_75X < size_74X)) {
    encoding_okP_77X = decode_scalar_value(2, (p_72X + index_75X), (size_74X - index_75X), &v_78X, &incompleteP_79X, &value_80X, &count_81X);
    if (encoding_okP_77X) {
      if (incompleteP_79X) {
        arg0K0 = 0;
        arg0K1 = 0;
        arg0K2 = 63;
        goto L14945;}
      else {
        arg0K0 = 0;
        arg0K1 = 0;
        arg0K2 = value_80X;
        goto L14962;}}
    else {
      arg0K0 = 0;
      arg0K1 = 0;
      arg0K2 = 63;
      goto L14928;}}
  else {
    return;}}
 L14945: {
  bits_82X = arg0K0;
  j_83X = arg0K1;
  shifted_84X = arg0K2;
  if ((j_83X < 4)) {
    *((unsigned char *) ((((char *) (-3 + s_73X))) + ((((target_index_76X)<<2)) + j_83X))) = (unsigned char) ((255 & shifted_84X));
    arg0K0 = (8 + bits_82X);
    arg0K1 = (1 + j_83X);
    arg0K2 = ((long)(((unsigned long)shifted_84X)>>8));
    goto L14945;}
  else {
    return;}}
 L14962: {
  bits_85X = arg0K0;
  j_86X = arg0K1;
  shifted_87X = arg0K2;
  if ((j_86X < 4)) {
    *((unsigned char *) ((((char *) (-3 + s_73X))) + ((((target_index_76X)<<2)) + j_86X))) = (unsigned char) ((255 & shifted_87X));
    arg0K0 = (8 + bits_85X);
    arg0K1 = (1 + j_86X);
    arg0K2 = ((long)(((unsigned long)shifted_87X)>>8));
    goto L14962;}
  else {
    arg0K0 = (index_75X + count_81X);
    arg0K1 = (1 + target_index_76X);
    goto L14872;}}
 L14928: {
  bits_88X = arg0K0;
  j_89X = arg0K1;
  shifted_90X = arg0K2;
  if ((j_89X < 4)) {
    *((unsigned char *) ((((char *) (-3 + s_73X))) + ((((target_index_76X)<<2)) + j_89X))) = (unsigned char) ((255 & shifted_90X));
    arg0K0 = (8 + bits_88X);
    arg0K1 = (1 + j_89X);
    arg0K2 = ((long)(((unsigned long)shifted_90X)>>8));
    goto L14928;}
  else {
    arg0K0 = (1 + index_75X);
    arg0K1 = (1 + target_index_76X);
    goto L14872;}}
}
static void copy_vm_string_to_stringUlatin_1B(long vm_string_91X, long start_92X, long count_93X, char *string_94X)
{
  char arg2K0;
  long arg0K2;
  long arg0K1;
  long arg0K0;
  char v_100X;
  long x_99X;
  long scalar_value_98X;
  long j_97X;
  long bits_96X;
  long i_95X;
 {  arg0K0 = 0;
  goto L15105;}
 L15105: {
  i_95X = arg0K0;
  if ((i_95X < count_93X)) {
    arg0K0 = 0;
    arg0K1 = 0;
    arg0K2 = 0;
    goto L15147;}
  else {
    return;}}
 L15147: {
  bits_96X = arg0K0;
  j_97X = arg0K1;
  scalar_value_98X = arg0K2;
  if ((j_97X < 4)) {
    PS_SHIFT_LEFT((*((unsigned char *) ((((char *) (-3 + vm_string_91X))) + ((((i_95X)<<2)) + j_97X)))), bits_96X, x_99X)
    arg0K0 = (8 + bits_96X);
    arg0K1 = (1 + j_97X);
    arg0K2 = (x_99X + scalar_value_98X);
    goto L15147;}
  else {
    if ((255 < scalar_value_98X)) {
      arg2K0 = 63;
      goto L15123;}
    else {
      arg2K0 = (((char) scalar_value_98X));
      goto L15123;}}}
 L15123: {
  v_100X = arg2K0;
  *(string_94X + (i_95X + start_92X)) = v_100X;
  arg0K0 = (1 + i_95X);
  goto L15105;}
}
static long close_channelB(long channel_101X)
{
  long arg0K0;
  char * addr_109X;
  long status_108X;
  long v_107X;
  long v_106X;
  long v_105X;
  long v_104X;
  long x_103X;
  long os_index_102X;
 {  os_index_102X = (((*((long *) ((((char *) (-3 + channel_101X))) + 8))))>>2);
  x_103X = *((long *) ((((char *) (-3 + channel_101X))) + 20));
  if ((5 == x_103X)) {
    v_104X = ps_abort_fd_op(os_index_102X);enqueue_channelB(os_index_102X, v_104X, 1);
    goto L15618;}
  else {
    goto L15618;}}
 L15618: {
  v_105X = *((long *) (((char *) (-3 + channel_101X))));
  if ((4 == v_105X)) {
    goto L15633;}
  else {
    if ((12 == (*((long *) (((char *) (-3 + channel_101X))))))) {
      goto L15633;}
    else {
      v_106X = ps_close_fd(os_index_102X);
      arg0K0 = v_106X;
      goto L15640;}}}
 L15633: {
  v_107X = ps_close_fd(os_index_102X);
  arg0K0 = v_107X;
  goto L15640;}
 L15640: {
  status_108X = arg0K0;
  *((Svm_channelsS) + os_index_102X) = 1;
  addr_109X = ((char *) (-3 + channel_101X));S48_WRITE_BARRIER(channel_101X, addr_109X, 0);
  *((long *) addr_109X) = (long) (0);
  return status_108X;}
}
static long make_blank_return_code(long protocol_110X, long template_111X, long frame_size_112X, long opcode_count_113X, long key_114X)
{
  long code_117X;
  char * addr_116X;
  long length_115X;
 {  length_115X = 15 + opcode_count_113X;
  addr_116X = s48_allocate_small((4 + length_115X));
  *((long *) addr_116X) = (long) ((70 + (((length_115X)<<8))));
  code_117X = 3 + (((long) (addr_116X + 4)));
  *((unsigned char *) (((char *) (-3 + code_117X)))) = (unsigned char) (0);
  *((unsigned char *) ((((char *) (-3 + code_117X))) + 1)) = (unsigned char) (protocol_110X);
  *((unsigned char *) ((((char *) (-3 + code_117X))) + 2)) = (unsigned char) (0);
  *((unsigned char *) ((((char *) (-3 + code_117X))) + 3)) = (unsigned char) (31);
  *((unsigned char *) ((((char *) (-3 + code_117X))) + 4)) = (unsigned char) (0);
  *((unsigned char *) ((((char *) (-3 + code_117X))) + 5)) = (unsigned char) (8);
  *((unsigned char *) ((((char *) (-3 + code_117X))) + 6)) = (unsigned char) ((255 & (((template_111X)>>8))));
  *((unsigned char *) ((((char *) (-3 + code_117X))) + 7)) = (unsigned char) ((255 & template_111X));
  *((unsigned char *) ((((char *) (-3 + code_117X))) + 8)) = (unsigned char) (0);
  *((unsigned char *) ((((char *) (-3 + code_117X))) + 9)) = (unsigned char) (13);
  *((unsigned char *) ((((char *) (-3 + code_117X))) + 10)) = (unsigned char) (0);
  *((unsigned char *) ((((char *) (-3 + code_117X))) + 11)) = (unsigned char) ((255 & (((frame_size_112X)>>8))));
  *((unsigned char *) ((((char *) (-3 + code_117X))) + 12)) = (unsigned char) ((255 & frame_size_112X));
  *((unsigned char *) ((((char *) (-3 + code_117X))) + 13)) = (unsigned char) (0);
  *((unsigned char *) ((((char *) (-3 + code_117X))) + 14)) = (unsigned char) (protocol_110X);
  return code_117X;}
}
static long enter_stringAgc_n(char *string_118X, long len_119X)
{
  long arg0K2;
  long arg0K1;
  long arg0K0;
  long shifted_128X;
  long j_127X;
  long bits_126X;
  long c_125X;
  long i_124X;
  long s_123X;
  long string_122X;
  char * addr_121X;
  long len_120X;
 {  len_120X = ((len_119X)<<2);
  addr_121X = s48_allocate_untracedAgc((4 + len_120X));
  if ((addr_121X == NULL)) {
    arg0K0 = 1;
    goto L17737;}
  else {
    *((long *) addr_121X) = (long) ((66 + (((len_120X)<<8))));
    arg0K0 = (3 + (((long) (addr_121X + 4))));
    goto L17737;}}
 L17737: {
  string_122X = arg0K0;
  if ((1 == string_122X)) {
    ps_error("Out of space, unable to allocate", 0);
    arg0K0 = string_122X;
    goto L17728;}
  else {
    arg0K0 = string_122X;
    goto L17728;}}
 L17728: {
  s_123X = arg0K0;
  arg0K0 = 0;
  goto L17760;}
 L17760: {
  i_124X = arg0K0;
  if ((i_124X < len_119X)) {
    c_125X = ((unsigned char) (*(string_118X + i_124X)));
    arg0K0 = 0;
    arg0K1 = 0;
    arg0K2 = c_125X;
    goto L17771;}
  else {
    return s_123X;}}
 L17771: {
  bits_126X = arg0K0;
  j_127X = arg0K1;
  shifted_128X = arg0K2;
  if ((j_127X < 4)) {
    *((unsigned char *) ((((char *) (-3 + s_123X))) + ((((i_124X)<<2)) + j_127X))) = (unsigned char) ((255 & shifted_128X));
    arg0K0 = (8 + bits_126X);
    arg0K1 = (1 + j_127X);
    arg0K2 = ((long)(((unsigned long)shifted_128X)>>8));
    goto L17771;}
  else {
    arg0K0 = (1 + i_124X);
    goto L17760;}}
}
static long add_log_entryAgc(long proposal_index_129X, long i_130X, long stob_131X, long index_132X, long value_133X, char verifyP_134X)
{
  long arg0K2;
  long arg0K1;
  long arg0K0;
  char * addr_159X;
  long value_158X;
  long v_157X;
  long value_156X;
  char * addr_155X;
  long i_154X;
  long stob_153X;
  long proposal_152X;
  long new_151X;
  char * addr_150X;
  char * addr_149X;
  long value_148X;
  long vector_147X;
  char * addr_146X;
  char * addr_145X;
  char * addr_144X;
  long log_143X;
  long value_142X;
  long stob_141X;
  long proposal_140X;
  char * addr_139X;
  long len_138X;
  long new_size_137X;
  long log_size_136X;
  long proposal_135X;
 {  proposal_135X = *((long *) ((((char *) (-3 + (Scurrent_threadS)))) + 12));
  log_size_136X = (((3 + ((long)(((unsigned long)(*((long *) ((((char *) (-3 + (*((long *) ((((char *) (-3 + proposal_135X))) + (((proposal_index_129X)<<2)))))))) + -4))))>>8))))>>2);
  if ((i_130X == (-1 + log_size_136X))) {
    Stemp0S = stob_131X;
    Stemp1S = value_133X;
    if ((1 == log_size_136X)) {
      arg0K0 = 17;
      goto L13768;}
    else {
      arg0K0 = (-1 + (((log_size_136X)<<1)));
      goto L13768;}}
  else {
    arg0K0 = proposal_135X;
    arg0K1 = stob_131X;
    arg0K2 = value_133X;
    goto L17995;}}
 L13768: {
  new_size_137X = arg0K0;
  len_138X = ((new_size_137X)<<2);
  addr_139X = s48_allocate_tracedAgc((4 + len_138X));
  if ((addr_139X == NULL)) {
    arg0K0 = 1;
    goto L13814;}
  else {
    *((long *) addr_139X) = (long) ((10 + (((len_138X)<<8))));
    arg0K0 = (3 + (((long) (addr_139X + 4))));
    goto L13814;}}
 L17995: {
  proposal_140X = arg0K0;
  stob_141X = arg0K1;
  value_142X = arg0K2;
  log_143X = *((long *) ((((char *) (-3 + proposal_140X))) + (((proposal_index_129X)<<2))));
  addr_144X = (((char *) (-3 + log_143X))) + (((i_130X)<<2));S48_WRITE_BARRIER(log_143X, addr_144X, stob_141X);
  *((long *) addr_144X) = (long) (stob_141X);
  addr_145X = (((char *) (-3 + log_143X))) + (4 + (((i_130X)<<2)));S48_WRITE_BARRIER(log_143X, addr_145X, index_132X);
  *((long *) addr_145X) = (long) (index_132X);
  addr_146X = (((char *) (-3 + log_143X))) + (8 + (((i_130X)<<2)));S48_WRITE_BARRIER(log_143X, addr_146X, value_142X);
  *((long *) addr_146X) = (long) (value_142X);
  if (verifyP_134X) {
    arg0K0 = value_142X;
    goto L18016;}
  else {
    arg0K0 = 29;
    goto L18016;}}
 L13814: {
  vector_147X = arg0K0;
  if ((1 == vector_147X)) {
    ps_error("Out of space, unable to allocate", 0);
    arg0K0 = vector_147X;
    goto L13772;}
  else {
    arg0K0 = vector_147X;
    goto L13772;}}
 L18016: {
  value_148X = arg0K0;
  addr_149X = (((char *) (-3 + log_143X))) + (12 + (((i_130X)<<2)));S48_WRITE_BARRIER(log_143X, addr_149X, value_148X);
  *((long *) addr_149X) = (long) (value_148X);
  addr_150X = (((char *) (-3 + log_143X))) + (16 + (((i_130X)<<2)));S48_WRITE_BARRIER(log_143X, addr_150X, 1);
  *((long *) addr_150X) = (long) (1);
  return value_142X;}
 L13772: {
  new_151X = arg0K0;
  proposal_152X = *((long *) ((((char *) (-3 + (Scurrent_threadS)))) + 12));
  if ((1 < log_size_136X)) {
    stob_153X = *((long *) ((((char *) (-3 + proposal_152X))) + 4));
    memmove((void *)(((char *) (-3 + new_151X))), (void *)(((char *) (-3 + stob_153X))),(-4 + (((log_size_136X)<<2))));
    goto L13792;}
  else {
    goto L13792;}}
 L13792: {
  arg0K0 = (4 + log_size_136X);
  goto L13796;}
 L13796: {
  i_154X = arg0K0;
  if ((i_154X == new_size_137X)) {
    addr_155X = (((char *) (-3 + proposal_152X))) + (((proposal_index_129X)<<2));S48_WRITE_BARRIER(proposal_152X, addr_155X, new_151X);
    *((long *) addr_155X) = (long) (new_151X);
    value_156X = Stemp0S;
    Stemp0S = 1;
    v_157X = *((long *) ((((char *) (-3 + (Scurrent_threadS)))) + 12));
    value_158X = Stemp1S;
    Stemp1S = 1;
    arg0K0 = v_157X;
    arg0K1 = value_156X;
    arg0K2 = value_158X;
    goto L17995;}
  else {
    addr_159X = (((char *) (-3 + new_151X))) + (((i_154X)<<2));S48_WRITE_BARRIER(new_151X, addr_159X, 0);
    *((long *) addr_159X) = (long) (0);
    arg0K0 = (1 + i_154X);
    goto L13796;}}
}
static long enter_bignum(char * external_bignum_160X)
{
  long desc_161X;
 {  desc_161X = 3 + (((long) external_bignum_160X));
  if ((3 == (3 & desc_161X))) {
    if ((19 == (31 & ((((*((long *) ((((char *) (-3 + desc_161X))) + -4))))>>2))))) {
      goto L18746;}
    else {
      goto L18760;}}
  else {
    goto L18760;}}
 L18746: {
  if ((3 == (3 & desc_161X))) {
    if ((0 == (128 & (*((long *) ((((char *) (-3 + desc_161X))) + -4)))))) {
      *((long *) ((((char *) (-3 + desc_161X))) + -4)) = (long) ((128 | (*((long *) ((((char *) (-3 + desc_161X))) + -4)))));
      return desc_161X;}
    else {
      return desc_161X;}}
  else {
    return desc_161X;}}
 L18760: {
  ps_error("not a bignum", 1, desc_161X);
  goto L18746;}
}
static char integerE(long x_162X, long y_163X)
{

 {  if ((0 == (3 & (x_162X | y_163X)))) {
    return (x_162X == y_163X);}
  else {
    if ((3 == (3 & x_162X))) {
      if ((19 == (31 & ((((*((long *) ((((char *) (-3 + x_162X))) + -4))))>>2))))) {
        if ((3 == (3 & y_163X))) {
          if ((19 == (31 & ((((*((long *) ((((char *) (-3 + y_163X))) + -4))))>>2))))) {
            return s48_bignum_equal_p((((char *) (-3 + x_162X))), (((char *) (-3 + y_163X))));}
          else {
            return 0;}}
        else {
          return 0;}}
      else {
        return 0;}}
    else {
      return 0;}}}
}
static long make_channel(long a_164X, long b_165X, long c_166X, long d_167X, long e_168X, long f_169X, long g_170X, long key_171X)
{
  long x_173X;
  char * addr_172X;
 {  addr_172X = s48_allocate_small(32);
  *((long *) addr_172X) = (long) (7194);
  x_173X = 3 + (((long) (addr_172X + 4)));
  *((long *) (((char *) (-3 + x_173X)))) = (long) (a_164X);
  *((long *) ((((char *) (-3 + x_173X))) + 4)) = (long) (b_165X);
  *((long *) ((((char *) (-3 + x_173X))) + 8)) = (long) (c_166X);
  *((long *) ((((char *) (-3 + x_173X))) + 12)) = (long) (d_167X);
  *((long *) ((((char *) (-3 + x_173X))) + 16)) = (long) (e_168X);
  *((long *) ((((char *) (-3 + x_173X))) + 20)) = (long) (f_169X);
  *((long *) ((((char *) (-3 + x_173X))) + 24)) = (long) (g_170X);
  return x_173X;}
}
static long write_vm_string(long vm_string_174X, FILE * out_175X)
{
  long arg0K2;
  long arg0K1;
  long arg0K0;
  long x_182X;
  long scalar_value_181X;
  long j_180X;
  long bits_179X;
  long i_178X;
  long size_177X;
  long v_176X;
 {  v_176X = ((long)(((unsigned long)(*((long *) ((((char *) (-3 + vm_string_174X))) + -4))))>>8)) / 4;
  arg0K0 = v_176X;
  arg0K1 = 0;
  goto L20935;}
 L20935: {
  size_177X = arg0K0;
  i_178X = arg0K1;
  if ((i_178X < size_177X)) {
    arg0K0 = 0;
    arg0K1 = 0;
    arg0K2 = 0;
    goto L20968;}
  else {
    return 0;}}
 L20968: {
  bits_179X = arg0K0;
  j_180X = arg0K1;
  scalar_value_181X = arg0K2;
  if ((j_180X < 4)) {
    PS_SHIFT_LEFT((*((unsigned char *) ((((char *) (-3 + vm_string_174X))) + ((((i_178X)<<2)) + j_180X)))), bits_179X, x_182X)
    arg0K0 = (8 + bits_179X);
    arg0K1 = (1 + j_180X);
    arg0K2 = (x_182X + scalar_value_181X);
    goto L20968;}
  else {
    { long ignoreXX;
    PS_WRITE_CHAR((((char) scalar_value_181X)), out_175X, ignoreXX) }
    arg0K0 = size_177X;
    arg0K1 = (1 + i_178X);
    goto L20935;}}
}
static long Haction4880(long s_183X)
{
  long arg0K2;
  long arg0K1;
  long arg0K0;
  long x_191X;
  long scalar_value_190X;
  long j_189X;
  long bits_188X;
  long ans_187X;
  long i_186X;
  long i_185X;
  long end_184X;
 {  end_184X = ((long)(((unsigned long)(*((long *) ((((char *) (-3 + s_183X))) + -4))))>>8)) / 4;
  arg0K0 = 65536;
  goto L21067;}
 L21067: {
  i_185X = arg0K0;
  if ((i_185X < 4194304)) {
    arg0K0 = (i_185X + i_185X);
    goto L21067;}
  else {
    arg0K0 = 0;
    arg0K1 = 0;
    goto L21169;}}
 L21169: {
  i_186X = arg0K0;
  ans_187X = arg0K1;
  if ((i_186X < end_184X)) {
    arg0K0 = 0;
    arg0K1 = 0;
    arg0K2 = 0;
    goto L21178;}
  else {
    return (ans_187X % 4194304);}}
 L21178: {
  bits_188X = arg0K0;
  j_189X = arg0K1;
  scalar_value_190X = arg0K2;
  if ((j_189X < 4)) {
    PS_SHIFT_LEFT((*((unsigned char *) ((((char *) (-3 + s_183X))) + ((((i_186X)<<2)) + j_189X)))), bits_188X, x_191X)
    arg0K0 = (8 + bits_188X);
    arg0K1 = (1 + j_189X);
    arg0K2 = (x_191X + scalar_value_190X);
    goto L21178;}
  else {
    arg0K0 = (1 + i_186X);
    arg0K1 = ((-1 + i_185X) & ((37 * ans_187X) + scalar_value_190X));
    goto L21169;}}
}
static long current_code_vector(void)
{
  long arg0K0;
  long x_204X;
  long v_203X;
  long x_202X;
  long header_201X;
  char * start_200X;
  char * code_pointer_199X;
  long code_198X;
  char * pointer_197X;
  char * code_pointer_196X;
  long header_195X;
  char * start_194X;
  long code_193X;
  char * code_pointer_192X;
 {  code_pointer_192X = Scode_pointerS;
  code_193X = Slast_code_calledS;
  start_194X = ((char *) (-3 + code_193X));
  if ((code_pointer_192X < start_194X)) {
    goto L21713;}
  else {
    header_195X = *((long *) ((((char *) (-3 + code_193X))) + -4));
    if ((3 == (3 & header_195X))) {
      arg0K0 = header_195X;
      goto L21734;}
    else {
      arg0K0 = code_193X;
      goto L21734;}}}
 L21713: {
  code_pointer_196X = Slast_code_pointer_resumedS;
  pointer_197X = code_pointer_196X + -5;
  code_198X = 3 + (((long) (code_pointer_196X + (0 - (((((*((unsigned char *) pointer_197X)))<<8)) + (*((unsigned char *) (pointer_197X + 1))))))));
  code_pointer_199X = Scode_pointerS;
  start_200X = ((char *) (-3 + code_198X));
  if ((code_pointer_199X < start_200X)) {
    goto L21721;}
  else {
    header_201X = *((long *) ((((char *) (-3 + code_198X))) + -4));
    if ((3 == (3 & header_201X))) {
      arg0K0 = header_201X;
      goto L21755;}
    else {
      arg0K0 = code_198X;
      goto L21755;}}}
 L21734: {
  x_202X = arg0K0;
  if ((code_pointer_192X < (start_194X + ((long)(((unsigned long)(*((long *) ((((char *) (-3 + x_202X))) + -4))))>>8))))) {
    return (Slast_code_calledS);}
  else {
    goto L21713;}}
 L21721: {
  ps_error("VM error: unable to locate current code vector", 3, (((long) (Scode_pointerS))), (Slast_code_calledS), (((long) (Slast_code_pointer_resumedS))));
  return v_203X;}
 L21755: {
  x_204X = arg0K0;
  if ((code_pointer_199X < (start_200X + ((long)(((unsigned long)(*((long *) ((((char *) (-3 + x_204X))) + -4))))>>8))))) {
    return code_198X;}
  else {
    goto L21721;}}
}
static void channel_close_error(long status_205X, long index_206X, long id_207X)
{

 {  ps_write_string("Error: ", (stderr));
  ps_write_string((ps_error_string(status_205X)), (stderr));
  { long ignoreXX;
  PS_WRITE_CHAR(10, (stderr), ignoreXX) }
  ps_write_string(" while closing port ", (stderr));
  if ((3 == (3 & id_207X))) {
    if ((16 == (31 & ((((*((long *) ((((char *) (-3 + id_207X))) + -4))))>>2))))) {
      ps_write_string((((char *)(((char *) (-3 + id_207X))))), (stderr));
      goto L22172;}
    else {
      goto L22160;}}
  else {
    goto L22160;}}
 L22172: {
  { long ignoreXX;
  PS_WRITE_CHAR(10, (stderr), ignoreXX) }
  return;}
 L22160: {
  if ((0 == (3 & id_207X))) {
    ps_write_integer((((index_206X)>>2)), (stderr));
    goto L22172;}
  else {
    ps_write_string("<strange id>", (stderr));
    goto L22172;}}
}
static long integer_bit_count(long x_208X)
{
  long arg0K1;
  long arg0K0;
  char * arg3K0;
  long n_215X;
  char * v_214X;
  char * v_213X;
  long value_212X;
  long v_211X;
  long extra_210X;
  long length_209X;
 {  if ((0 == (3 & x_208X))) {
    arg0K0 = 1;
    arg0K1 = 3;
    goto L24265;}
  else {
    arg0K0 = (-1 + ((((3 + ((long)(((unsigned long)(*((long *) ((((char *) (-3 + x_208X))) + -4))))>>8))))>>2)));
    arg0K1 = 0;
    goto L24265;}}
 L24265: {
  length_209X = arg0K0;
  extra_210X = arg0K1;
  if ((length_209X < 1)) {
    arg0K0 = 1;
    goto L24267;}
  else {
    arg0K0 = length_209X;
    goto L24267;}}
 L24267: {
  v_211X = arg0K0;
  Stemp0S = x_208X;s48_make_availableAgc((((((1 + ((((11 + (((v_211X)<<2))))>>2))) + extra_210X))<<2)));
  value_212X = Stemp0S;
  Stemp0S = 1;
  if ((0 == (3 & value_212X))) {
    v_213X = (char *) s48_long_to_bignum((((value_212X)>>2)));
    arg3K0 = v_213X;
    goto L24257;}
  else {
    arg3K0 = (((char *) (-3 + value_212X)));
    goto L24257;}}
 L24257: {
  v_214X = arg3K0;
  n_215X = s48_bignum_bit_count(v_214X);
  return (((n_215X)<<2));}
}
static long integer_add(long x_216X, long y_217X)
{
  char * arg3K0;
  long arg0K1;
  long arg0K0;
  long n_231X;
  char v_230X;
  char * external_bignum_229X;
  char * y_228X;
  char * v_227X;
  long value_226X;
  char * x_225X;
  char * v_224X;
  long value_223X;
  long v_222X;
  long extra1_221X;
  long length1_220X;
  long extra0_219X;
  long length0_218X;
 {  if ((0 == (3 & x_216X))) {
    arg0K0 = 1;
    arg0K1 = 3;
    goto L21672;}
  else {
    arg0K0 = (-1 + ((((3 + ((long)(((unsigned long)(*((long *) ((((char *) (-3 + x_216X))) + -4))))>>8))))>>2)));
    arg0K1 = 0;
    goto L21672;}}
 L21672: {
  length0_218X = arg0K0;
  extra0_219X = arg0K1;
  if ((0 == (3 & y_217X))) {
    arg0K0 = 1;
    arg0K1 = 3;
    goto L21680;}
  else {
    arg0K0 = (-1 + ((((3 + ((long)(((unsigned long)(*((long *) ((((char *) (-3 + y_217X))) + -4))))>>8))))>>2)));
    arg0K1 = 0;
    goto L21680;}}
 L21680: {
  length1_220X = arg0K0;
  extra1_221X = arg0K1;
  if ((length0_218X < length1_220X)) {
    arg0K0 = length1_220X;
    goto L21702;}
  else {
    arg0K0 = length0_218X;
    goto L21702;}}
 L21702: {
  v_222X = arg0K0;
  Stemp0S = x_216X;
  Stemp1S = y_217X;s48_make_availableAgc(((((((1 + ((((11 + (((v_222X)<<2))))>>2))) + extra0_219X) + extra1_221X))<<2)));
  value_223X = Stemp0S;
  Stemp0S = 1;
  if ((0 == (3 & value_223X))) {
    v_224X = (char *) s48_long_to_bignum((((value_223X)>>2)));
    arg3K0 = v_224X;
    goto L24403;}
  else {
    arg3K0 = (((char *) (-3 + value_223X)));
    goto L24403;}}
 L24403: {
  x_225X = arg3K0;
  value_226X = Stemp1S;
  Stemp1S = 1;
  if ((0 == (3 & value_226X))) {
    v_227X = (char *) s48_long_to_bignum((((value_226X)>>2)));
    arg3K0 = v_227X;
    goto L24407;}
  else {
    arg3K0 = (((char *) (-3 + value_226X)));
    goto L24407;}}
 L24407: {
  y_228X = arg3K0;
  external_bignum_229X = (char *)s48_bignum_add(x_225X, y_228X);
  v_230X = s48_bignum_fits_in_word_p(external_bignum_229X, 30, 1);
  if (v_230X) {
    n_231X = s48_bignum_to_long(external_bignum_229X);
    return (((n_231X)<<2));}
  else {
    return enter_bignum(external_bignum_229X);}}
}
static long integer_subtract(long x_232X, long y_233X)
{
  char * arg3K0;
  long arg0K1;
  long arg0K0;
  long n_247X;
  char v_246X;
  char * external_bignum_245X;
  char * y_244X;
  char * v_243X;
  long value_242X;
  char * x_241X;
  char * v_240X;
  long value_239X;
  long v_238X;
  long extra1_237X;
  long length1_236X;
  long extra0_235X;
  long length0_234X;
 {  if ((0 == (3 & x_232X))) {
    arg0K0 = 1;
    arg0K1 = 3;
    goto L21629;}
  else {
    arg0K0 = (-1 + ((((3 + ((long)(((unsigned long)(*((long *) ((((char *) (-3 + x_232X))) + -4))))>>8))))>>2)));
    arg0K1 = 0;
    goto L21629;}}
 L21629: {
  length0_234X = arg0K0;
  extra0_235X = arg0K1;
  if ((0 == (3 & y_233X))) {
    arg0K0 = 1;
    arg0K1 = 3;
    goto L21637;}
  else {
    arg0K0 = (-1 + ((((3 + ((long)(((unsigned long)(*((long *) ((((char *) (-3 + y_233X))) + -4))))>>8))))>>2)));
    arg0K1 = 0;
    goto L21637;}}
 L21637: {
  length1_236X = arg0K0;
  extra1_237X = arg0K1;
  if ((length0_234X < length1_236X)) {
    arg0K0 = length1_236X;
    goto L21659;}
  else {
    arg0K0 = length0_234X;
    goto L21659;}}
 L21659: {
  v_238X = arg0K0;
  Stemp0S = x_232X;
  Stemp1S = y_233X;s48_make_availableAgc(((((((1 + ((((11 + (((v_238X)<<2))))>>2))) + extra0_235X) + extra1_237X))<<2)));
  value_239X = Stemp0S;
  Stemp0S = 1;
  if ((0 == (3 & value_239X))) {
    v_240X = (char *) s48_long_to_bignum((((value_239X)>>2)));
    arg3K0 = v_240X;
    goto L24477;}
  else {
    arg3K0 = (((char *) (-3 + value_239X)));
    goto L24477;}}
 L24477: {
  x_241X = arg3K0;
  value_242X = Stemp1S;
  Stemp1S = 1;
  if ((0 == (3 & value_242X))) {
    v_243X = (char *) s48_long_to_bignum((((value_242X)>>2)));
    arg3K0 = v_243X;
    goto L24481;}
  else {
    arg3K0 = (((char *) (-3 + value_242X)));
    goto L24481;}}
 L24481: {
  y_244X = arg3K0;
  external_bignum_245X = (char *)s48_bignum_subtract(x_241X, y_244X);
  v_246X = s48_bignum_fits_in_word_p(external_bignum_245X, 30, 1);
  if (v_246X) {
    n_247X = s48_bignum_to_long(external_bignum_245X);
    return (((n_247X)<<2));}
  else {
    return enter_bignum(external_bignum_245X);}}
}
static long integer_multiply(long x_248X, long y_249X)
{
  char * arg3K0;
  long arg0K1;
  long arg0K0;
  long n_262X;
  char v_261X;
  char * external_bignum_260X;
  char * y_259X;
  char * v_258X;
  long value_257X;
  char * x_256X;
  char * v_255X;
  long value_254X;
  long extra1_253X;
  long length1_252X;
  long extra0_251X;
  long length0_250X;
 {  if ((0 == (3 & x_248X))) {
    arg0K0 = 1;
    arg0K1 = 3;
    goto L21592;}
  else {
    arg0K0 = (-1 + ((((3 + ((long)(((unsigned long)(*((long *) ((((char *) (-3 + x_248X))) + -4))))>>8))))>>2)));
    arg0K1 = 0;
    goto L21592;}}
 L21592: {
  length0_250X = arg0K0;
  extra0_251X = arg0K1;
  if ((0 == (3 & y_249X))) {
    arg0K0 = 1;
    arg0K1 = 3;
    goto L21600;}
  else {
    arg0K0 = (-1 + ((((3 + ((long)(((unsigned long)(*((long *) ((((char *) (-3 + y_249X))) + -4))))>>8))))>>2)));
    arg0K1 = 0;
    goto L21600;}}
 L21600: {
  length1_252X = arg0K0;
  extra1_253X = arg0K1;
  Stemp0S = x_248X;
  Stemp1S = y_249X;s48_make_availableAgc(((((((1 + ((((7 + ((((length0_250X + length1_252X))<<2))))>>2))) + extra0_251X) + extra1_253X))<<2)));
  value_254X = Stemp0S;
  Stemp0S = 1;
  if ((0 == (3 & value_254X))) {
    v_255X = (char *) s48_long_to_bignum((((value_254X)>>2)));
    arg3K0 = v_255X;
    goto L24551;}
  else {
    arg3K0 = (((char *) (-3 + value_254X)));
    goto L24551;}}
 L24551: {
  x_256X = arg3K0;
  value_257X = Stemp1S;
  Stemp1S = 1;
  if ((0 == (3 & value_257X))) {
    v_258X = (char *) s48_long_to_bignum((((value_257X)>>2)));
    arg3K0 = v_258X;
    goto L24555;}
  else {
    arg3K0 = (((char *) (-3 + value_257X)));
    goto L24555;}}
 L24555: {
  y_259X = arg3K0;
  external_bignum_260X = (char *)s48_bignum_multiply(x_256X, y_259X);
  v_261X = s48_bignum_fits_in_word_p(external_bignum_260X, 30, 1);
  if (v_261X) {
    n_262X = s48_bignum_to_long(external_bignum_260X);
    return (((n_262X)<<2));}
  else {
    return enter_bignum(external_bignum_260X);}}
}
static long integer_bitwise_not(long x_263X)
{
  long arg0K1;
  long arg0K0;
  char * arg3K0;
  long n_272X;
  char v_271X;
  char * external_bignum_270X;
  char * v_269X;
  char * v_268X;
  long value_267X;
  long v_266X;
  long extra_265X;
  long length_264X;
 {  if ((0 == (3 & x_263X))) {
    arg0K0 = 1;
    arg0K1 = 3;
    goto L24924;}
  else {
    arg0K0 = (-1 + ((((3 + ((long)(((unsigned long)(*((long *) ((((char *) (-3 + x_263X))) + -4))))>>8))))>>2)));
    arg0K1 = 0;
    goto L24924;}}
 L24924: {
  length_264X = arg0K0;
  extra_265X = arg0K1;
  if ((length_264X < 1)) {
    arg0K0 = 1;
    goto L24926;}
  else {
    arg0K0 = length_264X;
    goto L24926;}}
 L24926: {
  v_266X = arg0K0;
  Stemp0S = x_263X;s48_make_availableAgc((((((1 + ((((11 + (((v_266X)<<2))))>>2))) + extra_265X))<<2)));
  value_267X = Stemp0S;
  Stemp0S = 1;
  if ((0 == (3 & value_267X))) {
    v_268X = (char *) s48_long_to_bignum((((value_267X)>>2)));
    arg3K0 = v_268X;
    goto L24916;}
  else {
    arg3K0 = (((char *) (-3 + value_267X)));
    goto L24916;}}
 L24916: {
  v_269X = arg3K0;
  external_bignum_270X = (char *) s48_bignum_bitwise_not(v_269X);
  v_271X = s48_bignum_fits_in_word_p(external_bignum_270X, 30, 1);
  if (v_271X) {
    n_272X = s48_bignum_to_long(external_bignum_270X);
    return (((n_272X)<<2));}
  else {
    return enter_bignum(external_bignum_270X);}}
}
static long integer_bitwise_and(long x_273X, long y_274X)
{
  char * arg3K0;
  long arg0K1;
  long arg0K0;
  long n_288X;
  char v_287X;
  char * external_bignum_286X;
  char * y_285X;
  char * v_284X;
  long value_283X;
  char * x_282X;
  char * v_281X;
  long value_280X;
  long v_279X;
  long extra1_278X;
  long length1_277X;
  long extra0_276X;
  long length0_275X;
 {  if ((0 == (3 & x_273X))) {
    arg0K0 = 1;
    arg0K1 = 3;
    goto L21411;}
  else {
    arg0K0 = (-1 + ((((3 + ((long)(((unsigned long)(*((long *) ((((char *) (-3 + x_273X))) + -4))))>>8))))>>2)));
    arg0K1 = 0;
    goto L21411;}}
 L21411: {
  length0_275X = arg0K0;
  extra0_276X = arg0K1;
  if ((0 == (3 & y_274X))) {
    arg0K0 = 1;
    arg0K1 = 3;
    goto L21419;}
  else {
    arg0K0 = (-1 + ((((3 + ((long)(((unsigned long)(*((long *) ((((char *) (-3 + y_274X))) + -4))))>>8))))>>2)));
    arg0K1 = 0;
    goto L21419;}}
 L21419: {
  length1_277X = arg0K0;
  extra1_278X = arg0K1;
  if ((length0_275X < length1_277X)) {
    arg0K0 = length1_277X;
    goto L21441;}
  else {
    arg0K0 = length0_275X;
    goto L21441;}}
 L21441: {
  v_279X = arg0K0;
  Stemp0S = x_273X;
  Stemp1S = y_274X;s48_make_availableAgc(((((((1 + ((((11 + (((v_279X)<<2))))>>2))) + extra0_276X) + extra1_278X))<<2)));
  value_280X = Stemp0S;
  Stemp0S = 1;
  if ((0 == (3 & value_280X))) {
    v_281X = (char *) s48_long_to_bignum((((value_280X)>>2)));
    arg3K0 = v_281X;
    goto L24983;}
  else {
    arg3K0 = (((char *) (-3 + value_280X)));
    goto L24983;}}
 L24983: {
  x_282X = arg3K0;
  value_283X = Stemp1S;
  Stemp1S = 1;
  if ((0 == (3 & value_283X))) {
    v_284X = (char *) s48_long_to_bignum((((value_283X)>>2)));
    arg3K0 = v_284X;
    goto L24987;}
  else {
    arg3K0 = (((char *) (-3 + value_283X)));
    goto L24987;}}
 L24987: {
  y_285X = arg3K0;
  external_bignum_286X = (char *) s48_bignum_bitwise_and(x_282X, y_285X);
  v_287X = s48_bignum_fits_in_word_p(external_bignum_286X, 30, 1);
  if (v_287X) {
    n_288X = s48_bignum_to_long(external_bignum_286X);
    return (((n_288X)<<2));}
  else {
    return enter_bignum(external_bignum_286X);}}
}
static long integer_bitwise_ior(long x_289X, long y_290X)
{
  char * arg3K0;
  long arg0K1;
  long arg0K0;
  long n_304X;
  char v_303X;
  char * external_bignum_302X;
  char * y_301X;
  char * v_300X;
  long value_299X;
  char * x_298X;
  char * v_297X;
  long value_296X;
  long v_295X;
  long extra1_294X;
  long length1_293X;
  long extra0_292X;
  long length0_291X;
 {  if ((0 == (3 & x_289X))) {
    arg0K0 = 1;
    arg0K1 = 3;
    goto L21368;}
  else {
    arg0K0 = (-1 + ((((3 + ((long)(((unsigned long)(*((long *) ((((char *) (-3 + x_289X))) + -4))))>>8))))>>2)));
    arg0K1 = 0;
    goto L21368;}}
 L21368: {
  length0_291X = arg0K0;
  extra0_292X = arg0K1;
  if ((0 == (3 & y_290X))) {
    arg0K0 = 1;
    arg0K1 = 3;
    goto L21376;}
  else {
    arg0K0 = (-1 + ((((3 + ((long)(((unsigned long)(*((long *) ((((char *) (-3 + y_290X))) + -4))))>>8))))>>2)));
    arg0K1 = 0;
    goto L21376;}}
 L21376: {
  length1_293X = arg0K0;
  extra1_294X = arg0K1;
  if ((length0_291X < length1_293X)) {
    arg0K0 = length1_293X;
    goto L21398;}
  else {
    arg0K0 = length0_291X;
    goto L21398;}}
 L21398: {
  v_295X = arg0K0;
  Stemp0S = x_289X;
  Stemp1S = y_290X;s48_make_availableAgc(((((((1 + ((((11 + (((v_295X)<<2))))>>2))) + extra0_292X) + extra1_294X))<<2)));
  value_296X = Stemp0S;
  Stemp0S = 1;
  if ((0 == (3 & value_296X))) {
    v_297X = (char *) s48_long_to_bignum((((value_296X)>>2)));
    arg3K0 = v_297X;
    goto L25057;}
  else {
    arg3K0 = (((char *) (-3 + value_296X)));
    goto L25057;}}
 L25057: {
  x_298X = arg3K0;
  value_299X = Stemp1S;
  Stemp1S = 1;
  if ((0 == (3 & value_299X))) {
    v_300X = (char *) s48_long_to_bignum((((value_299X)>>2)));
    arg3K0 = v_300X;
    goto L25061;}
  else {
    arg3K0 = (((char *) (-3 + value_299X)));
    goto L25061;}}
 L25061: {
  y_301X = arg3K0;
  external_bignum_302X = (char *) s48_bignum_bitwise_ior(x_298X, y_301X);
  v_303X = s48_bignum_fits_in_word_p(external_bignum_302X, 30, 1);
  if (v_303X) {
    n_304X = s48_bignum_to_long(external_bignum_302X);
    return (((n_304X)<<2));}
  else {
    return enter_bignum(external_bignum_302X);}}
}
static long integer_bitwise_xor(long x_305X, long y_306X)
{
  char * arg3K0;
  long arg0K1;
  long arg0K0;
  long n_320X;
  char v_319X;
  char * external_bignum_318X;
  char * y_317X;
  char * v_316X;
  long value_315X;
  char * x_314X;
  char * v_313X;
  long value_312X;
  long v_311X;
  long extra1_310X;
  long length1_309X;
  long extra0_308X;
  long length0_307X;
 {  if ((0 == (3 & x_305X))) {
    arg0K0 = 1;
    arg0K1 = 3;
    goto L21325;}
  else {
    arg0K0 = (-1 + ((((3 + ((long)(((unsigned long)(*((long *) ((((char *) (-3 + x_305X))) + -4))))>>8))))>>2)));
    arg0K1 = 0;
    goto L21325;}}
 L21325: {
  length0_307X = arg0K0;
  extra0_308X = arg0K1;
  if ((0 == (3 & y_306X))) {
    arg0K0 = 1;
    arg0K1 = 3;
    goto L21333;}
  else {
    arg0K0 = (-1 + ((((3 + ((long)(((unsigned long)(*((long *) ((((char *) (-3 + y_306X))) + -4))))>>8))))>>2)));
    arg0K1 = 0;
    goto L21333;}}
 L21333: {
  length1_309X = arg0K0;
  extra1_310X = arg0K1;
  if ((length0_307X < length1_309X)) {
    arg0K0 = length1_309X;
    goto L21355;}
  else {
    arg0K0 = length0_307X;
    goto L21355;}}
 L21355: {
  v_311X = arg0K0;
  Stemp0S = x_305X;
  Stemp1S = y_306X;s48_make_availableAgc(((((((1 + ((((11 + (((v_311X)<<2))))>>2))) + extra0_308X) + extra1_310X))<<2)));
  value_312X = Stemp0S;
  Stemp0S = 1;
  if ((0 == (3 & value_312X))) {
    v_313X = (char *) s48_long_to_bignum((((value_312X)>>2)));
    arg3K0 = v_313X;
    goto L25131;}
  else {
    arg3K0 = (((char *) (-3 + value_312X)));
    goto L25131;}}
 L25131: {
  x_314X = arg3K0;
  value_315X = Stemp1S;
  Stemp1S = 1;
  if ((0 == (3 & value_315X))) {
    v_316X = (char *) s48_long_to_bignum((((value_315X)>>2)));
    arg3K0 = v_316X;
    goto L25135;}
  else {
    arg3K0 = (((char *) (-3 + value_315X)));
    goto L25135;}}
 L25135: {
  y_317X = arg3K0;
  external_bignum_318X = (char *) s48_bignum_bitwise_xor(x_314X, y_317X);
  v_319X = s48_bignum_fits_in_word_p(external_bignum_318X, 30, 1);
  if (v_319X) {
    n_320X = s48_bignum_to_long(external_bignum_318X);
    return (((n_320X)<<2));}
  else {
    return enter_bignum(external_bignum_318X);}}
}
static long Hinteger_op8281(long x_321X, long y_322X)
{
  long arg0K1;
  long arg0K0;
  char * arg3K0;
  long n_334X;
  char v_333X;
  char * external_bignum_332X;
  char * y_331X;
  char * v_330X;
  long value_329X;
  char * x_328X;
  char * v_327X;
  long value_326X;
  long extra1_325X;
  long extra0_324X;
  long length0_323X;
 {  if ((0 == (3 & x_321X))) {
    arg0K0 = 1;
    arg0K1 = 3;
    goto L25221;}
  else {
    arg0K0 = (-1 + ((((3 + ((long)(((unsigned long)(*((long *) ((((char *) (-3 + x_321X))) + -4))))>>8))))>>2)));
    arg0K1 = 0;
    goto L25221;}}
 L25221: {
  length0_323X = arg0K0;
  extra0_324X = arg0K1;
  if ((0 == (3 & y_322X))) {
    arg0K0 = 3;
    goto L25223;}
  else {
    arg0K0 = 0;
    goto L25223;}}
 L25223: {
  extra1_325X = arg0K0;
  Stemp0S = x_321X;
  Stemp1S = y_322X;s48_make_availableAgc(((((((6 + (-2 & ((((7 + (((length0_323X)<<2))))>>1)))) + extra0_324X) + extra1_325X))<<2)));
  value_326X = Stemp0S;
  Stemp0S = 1;
  if ((0 == (3 & value_326X))) {
    v_327X = (char *) s48_long_to_bignum((((value_326X)>>2)));
    arg3K0 = v_327X;
    goto L25205;}
  else {
    arg3K0 = (((char *) (-3 + value_326X)));
    goto L25205;}}
 L25205: {
  x_328X = arg3K0;
  value_329X = Stemp1S;
  Stemp1S = 1;
  if ((0 == (3 & value_329X))) {
    v_330X = (char *) s48_long_to_bignum((((value_329X)>>2)));
    arg3K0 = v_330X;
    goto L25209;}
  else {
    arg3K0 = (((char *) (-3 + value_329X)));
    goto L25209;}}
 L25209: {
  y_331X = arg3K0;
  external_bignum_332X = (char *)s48_bignum_quotient(x_328X, y_331X);
  v_333X = s48_bignum_fits_in_word_p(external_bignum_332X, 30, 1);
  if (v_333X) {
    n_334X = s48_bignum_to_long(external_bignum_332X);
    return (((n_334X)<<2));}
  else {
    return enter_bignum(external_bignum_332X);}}
}
static long Hinteger_op8212(long x_335X, long y_336X)
{
  long arg0K1;
  long arg0K0;
  char * arg3K0;
  long n_348X;
  char v_347X;
  char * external_bignum_346X;
  char * y_345X;
  char * v_344X;
  long value_343X;
  char * x_342X;
  char * v_341X;
  long value_340X;
  long extra1_339X;
  long extra0_338X;
  long length0_337X;
 {  if ((0 == (3 & x_335X))) {
    arg0K0 = 1;
    arg0K1 = 3;
    goto L25312;}
  else {
    arg0K0 = (-1 + ((((3 + ((long)(((unsigned long)(*((long *) ((((char *) (-3 + x_335X))) + -4))))>>8))))>>2)));
    arg0K1 = 0;
    goto L25312;}}
 L25312: {
  length0_337X = arg0K0;
  extra0_338X = arg0K1;
  if ((0 == (3 & y_336X))) {
    arg0K0 = 3;
    goto L25314;}
  else {
    arg0K0 = 0;
    goto L25314;}}
 L25314: {
  extra1_339X = arg0K0;
  Stemp0S = x_335X;
  Stemp1S = y_336X;s48_make_availableAgc(((((((6 + (-2 & ((((7 + (((length0_337X)<<2))))>>1)))) + extra0_338X) + extra1_339X))<<2)));
  value_340X = Stemp0S;
  Stemp0S = 1;
  if ((0 == (3 & value_340X))) {
    v_341X = (char *) s48_long_to_bignum((((value_340X)>>2)));
    arg3K0 = v_341X;
    goto L25296;}
  else {
    arg3K0 = (((char *) (-3 + value_340X)));
    goto L25296;}}
 L25296: {
  x_342X = arg3K0;
  value_343X = Stemp1S;
  Stemp1S = 1;
  if ((0 == (3 & value_343X))) {
    v_344X = (char *) s48_long_to_bignum((((value_343X)>>2)));
    arg3K0 = v_344X;
    goto L25300;}
  else {
    arg3K0 = (((char *) (-3 + value_343X)));
    goto L25300;}}
 L25300: {
  y_345X = arg3K0;
  external_bignum_346X = (char *)s48_bignum_remainder(x_342X, y_345X);
  v_347X = s48_bignum_fits_in_word_p(external_bignum_346X, 30, 1);
  if (v_347X) {
    n_348X = s48_bignum_to_long(external_bignum_346X);
    return (((n_348X)<<2));}
  else {
    return enter_bignum(external_bignum_346X);}}
}
static char for_each_imported_binding(char (*proc_349X)(long))
{
  long arg0K0;
  long link_356X;
  char x_355X;
  long entry_354X;
  long link_353X;
  char temp_352X;
  long i_351X;
  long table_350X;
 {  table_350X = Simported_bindingsS;
  arg0K0 = 0;
  goto L22339;}
 L22339: {
  i_351X = arg0K0;
  temp_352X = 1024 == i_351X;
  if (temp_352X) {
    return temp_352X;}
  else {
    link_353X = *((long *) ((((char *) (-3 + table_350X))) + (((i_351X)<<2))));
    if ((0 == (3 & link_353X))) {
      arg0K0 = (3 + (-4 & link_353X));
      goto L22311;}
    else {
      arg0K0 = link_353X;
      goto L22311;}}}
 L22311: {
  entry_354X = arg0K0;
  if ((1 == entry_354X)) {
    arg0K0 = (1 + i_351X);
    goto L22339;}
  else {
    x_355X = (*proc_349X)(entry_354X);
    if (x_355X) {
      link_356X = *((long *) ((((char *) (-3 + entry_354X))) + 12));
      if ((0 == (3 & link_356X))) {
        arg0K0 = (3 + (-4 & link_356X));
        goto L22311;}
      else {
        arg0K0 = link_356X;
        goto L22311;}}
    else {
      return 1;}}}
}
static long really_preserve_continuation(long key_357X)
{
  char * arg3K0;
  long arg0K1;
  long arg0K0;
  char * next_370X;
  long pc_369X;
  char * pointer_368X;
  char * pointer_367X;
  long new_366X;
  char * addr_365X;
  long len_364X;
  long size_363X;
  long size_362X;
  char * pointer_361X;
  long previous_360X;
  char * cont_359X;
  long temp_358X;
 {  if (((ScontS) == (Sbottom_of_stackS))) {
    goto L26744;}
  else {
    temp_358X = Sheap_continuationS;
    arg3K0 = (ScontS);
    arg0K1 = 1;
    goto L26714;}}
 L26744: {
  return (Sheap_continuationS);}
 L26714: {
  cont_359X = arg3K0;
  previous_360X = arg0K1;
  if ((cont_359X == (Sbottom_of_stackS))) {
    *((long *) ((((char *) (-3 + previous_360X))) + 8)) = (long) (temp_358X);
    ScontS = (Sbottom_of_stackS);
    goto L26744;}
  else {
    pointer_361X = (((char *) (*((long *) cont_359X)))) + -2;
    size_362X = ((((*((unsigned char *) pointer_361X)))<<8)) + (*((unsigned char *) (pointer_361X + 1)));
    if ((65535 == size_362X)) {
      arg0K0 = ((((*((long *) (cont_359X + 4))))>>2));
      goto L23133;}
    else {
      arg0K0 = size_362X;
      goto L23133;}}}
 L23133: {
  size_363X = arg0K0;
  len_364X = 12 + (((size_363X)<<2));
  addr_365X = s48_allocate_small((4 + len_364X));
  *((long *) addr_365X) = (long) ((42 + (((len_364X)<<8))));
  new_366X = 3 + (((long) (addr_365X + 4)));
  pointer_367X = ((char *) (*((long *) cont_359X)));
  pointer_368X = pointer_367X + -5;
  pc_369X = ((((*((unsigned char *) pointer_368X)))<<8)) + (*((unsigned char *) (pointer_368X + 1)));
  memmove((void *)((((char *) (-3 + new_366X))) + 12), (void *)(cont_359X + 4),(((size_363X)<<2)));
  *((long *) (((char *) (-3 + new_366X)))) = (long) ((((pc_369X)<<2)));
  *((long *) ((((char *) (-3 + new_366X))) + 4)) = (long) ((3 + (((long) (pointer_367X + (0 - pc_369X))))));
  next_370X = cont_359X + (4 + (((size_363X)<<2)));
  if ((3 == (3 & previous_360X))) {
    if ((10 == (31 & ((((*((long *) ((((char *) (-3 + previous_360X))) + -4))))>>2))))) {
      *((long *) ((((char *) (-3 + previous_360X))) + 8)) = (long) (new_366X);
      arg3K0 = next_370X;
      arg0K1 = new_366X;
      goto L26714;}
    else {
      goto L26732;}}
  else {
    goto L26732;}}
 L26732: {
  Sheap_continuationS = new_366X;
  arg3K0 = next_370X;
  arg0K1 = new_366X;
  goto L26714;}
}
static void push_exception_setupB(long exception_371X, long instruction_size_372X)
{
  long n_384X;
  long data_383X;
  long n_382X;
  long code_381X;
  long pc_380X;
  char * code_pointer_379X;
  long x_378X;
  long data_377X;
  long n_376X;
  long pc_375X;
  char * code_pointer_374X;
  long code_373X;
 {  if ((0 == (Snative_exception_contS))) {
    code_373X = current_code_vector();
    code_pointer_374X = (((char *) (-3 + (Sexception_return_codeS)))) + 13;
    pc_375X = ((((Scode_pointerS) - (((char *) (-3 + code_373X)))))<<2);
    SstackS = ((SstackS) + -20);
    n_376X = ((((ScontS) - (SstackS)))>>2);
    data_377X = 3 + (((long) (SstackS)));
    *((long *) (((char *) (-3 + data_377X)))) = (long) ((((n_376X)<<2)));
    *((long *) ((((char *) (-3 + data_377X))) + 4)) = (long) (pc_375X);
    *((long *) ((((char *) (-3 + data_377X))) + 8)) = (long) (code_373X);
    *((long *) ((((char *) (-3 + data_377X))) + 12)) = (long) ((((exception_371X)<<2)));
    *((long *) ((((char *) (-3 + data_377X))) + 16)) = (long) ((((instruction_size_372X)<<2)));
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) ((((long) code_pointer_374X)));
    ScontS = (SstackS);
    goto L27072;}
  else {
    x_378X = Snative_exception_contS;
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) (x_378X);
    ScontS = (SstackS);
    ps_write_string("handling exception for nc ", (stderr));
    ps_write_integer((Snative_exception_contS), (stderr));
    code_pointer_379X = (((char *) (-3 + (Snative_exception_return_codeS)))) + 13;
    pc_380X = (((*((unsigned char *) (Scode_pointerS))))<<2);
    code_381X = Snative_exception_contS;
    SstackS = ((SstackS) + -20);
    n_382X = ((((ScontS) - (SstackS)))>>2);
    data_383X = 3 + (((long) (SstackS)));
    *((long *) (((char *) (-3 + data_383X)))) = (long) ((((n_382X)<<2)));
    *((long *) ((((char *) (-3 + data_383X))) + 4)) = (long) (pc_380X);
    *((long *) ((((char *) (-3 + data_383X))) + 8)) = (long) (code_381X);
    *((long *) ((((char *) (-3 + data_383X))) + 12)) = (long) ((((exception_371X)<<2)));
    *((long *) ((((char *) (-3 + data_383X))) + 16)) = (long) (0);
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) ((((long) code_pointer_379X)));
    ScontS = (SstackS);
    Snative_exception_contS = 0;
    goto L27072;}}
 L27072: {
  n_384X = *((unsigned char *) (Scode_pointerS));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((n_384X)<<2)));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((exception_371X)<<2)));
  return;}
}
static long Hlookup833(long table_385X, long string_386X, long key_387X)
{
  long arg0K0;
  char * addr_400X;
  long value_399X;
  long link_398X;
  long x_397X;
  char * addr_396X;
  long next_395X;
  long len_394X;
  long s2_393X;
  long foo_392X;
  long bucket_391X;
  long link_390X;
  long index_389X;
  long v_388X;
 {  v_388X = Haction4880(string_386X);
  index_389X = 1023 & v_388X;
  link_390X = *((long *) ((((char *) (-3 + table_385X))) + (((index_389X)<<2))));
  if ((0 == (3 & link_390X))) {
    arg0K0 = (3 + (-4 & link_390X));
    goto L27901;}
  else {
    arg0K0 = link_390X;
    goto L27901;}}
 L27901: {
  bucket_391X = arg0K0;
  arg0K0 = bucket_391X;
  goto L27907;}
 L27907: {
  foo_392X = arg0K0;
  if ((1 == foo_392X)) {
    if ((3 == (3 & bucket_391X))) {
      arg0K0 = (-4 & bucket_391X);
      goto L27912;}
    else {
      arg0K0 = bucket_391X;
      goto L27912;}}
  else {
    s2_393X = *((long *) (((char *) (-3 + foo_392X))));
    len_394X = (long)(((unsigned long)(*((long *) ((((char *) (-3 + string_386X))) + -4))))>>8);
    if ((len_394X == ((long)(((unsigned long)(*((long *) ((((char *) (-3 + s2_393X))) + -4))))>>8)))) {
      if (((!memcmp((void *)(((char *) (-3 + s2_393X))), (void *)(((char *) (-3 + string_386X))),len_394X)))) {
        return foo_392X;}
      else {
        goto L27927;}}
    else {
      goto L27927;}}}
 L27912: {
  next_395X = arg0K0;
  addr_396X = s48_allocate_small(20);
  *((long *) addr_396X) = (long) (4154);
  x_397X = 3 + (((long) (addr_396X + 4)));
  *((long *) (((char *) (-3 + x_397X)))) = (long) (string_386X);
  *((long *) ((((char *) (-3 + x_397X))) + 4)) = (long) (1);
  *((long *) ((((char *) (-3 + x_397X))) + 8)) = (long) (13);
  *((long *) ((((char *) (-3 + x_397X))) + 12)) = (long) (next_395X);
  if ((3 == (3 & x_397X))) {
    arg0K0 = (-4 & x_397X);
    goto L27918;}
  else {
    arg0K0 = x_397X;
    goto L27918;}}
 L27927: {
  link_398X = *((long *) ((((char *) (-3 + foo_392X))) + 12));
  if ((0 == (3 & link_398X))) {
    arg0K0 = (3 + (-4 & link_398X));
    goto L27907;}
  else {
    arg0K0 = link_398X;
    goto L27907;}}
 L27918: {
  value_399X = arg0K0;
  addr_400X = (((char *) (-3 + table_385X))) + (((index_389X)<<2));S48_WRITE_BARRIER(table_385X, addr_400X, value_399X);
  *((long *) addr_400X) = (long) (value_399X);
  return x_397X;}
}
static long Hlookup814(long table_401X, long string_402X, long key_403X)
{
  long arg0K0;
  char * addr_416X;
  long value_415X;
  long link_414X;
  long x_413X;
  char * addr_412X;
  long next_411X;
  long len_410X;
  long s2_409X;
  long foo_408X;
  long bucket_407X;
  long link_406X;
  long index_405X;
  long v_404X;
 {  v_404X = Haction4880(string_402X);
  index_405X = 1023 & v_404X;
  link_406X = *((long *) ((((char *) (-3 + table_401X))) + (((index_405X)<<2))));
  if ((0 == (3 & link_406X))) {
    arg0K0 = (3 + (-4 & link_406X));
    goto L28044;}
  else {
    arg0K0 = link_406X;
    goto L28044;}}
 L28044: {
  bucket_407X = arg0K0;
  arg0K0 = bucket_407X;
  goto L28050;}
 L28050: {
  foo_408X = arg0K0;
  if ((1 == foo_408X)) {
    if ((3 == (3 & bucket_407X))) {
      arg0K0 = (-4 & bucket_407X);
      goto L28055;}
    else {
      arg0K0 = bucket_407X;
      goto L28055;}}
  else {
    s2_409X = *((long *) (((char *) (-3 + foo_408X))));
    len_410X = (long)(((unsigned long)(*((long *) ((((char *) (-3 + string_402X))) + -4))))>>8);
    if ((len_410X == ((long)(((unsigned long)(*((long *) ((((char *) (-3 + s2_409X))) + -4))))>>8)))) {
      if (((!memcmp((void *)(((char *) (-3 + s2_409X))), (void *)(((char *) (-3 + string_402X))),len_410X)))) {
        return foo_408X;}
      else {
        goto L28070;}}
    else {
      goto L28070;}}}
 L28055: {
  next_411X = arg0K0;
  addr_412X = s48_allocate_small(20);
  *((long *) addr_412X) = (long) (4154);
  x_413X = 3 + (((long) (addr_412X + 4)));
  *((long *) (((char *) (-3 + x_413X)))) = (long) (string_402X);
  *((long *) ((((char *) (-3 + x_413X))) + 4)) = (long) (5);
  *((long *) ((((char *) (-3 + x_413X))) + 8)) = (long) (13);
  *((long *) ((((char *) (-3 + x_413X))) + 12)) = (long) (next_411X);
  if ((3 == (3 & x_413X))) {
    arg0K0 = (-4 & x_413X);
    goto L28061;}
  else {
    arg0K0 = x_413X;
    goto L28061;}}
 L28070: {
  link_414X = *((long *) ((((char *) (-3 + foo_408X))) + 12));
  if ((0 == (3 & link_414X))) {
    arg0K0 = (3 + (-4 & link_414X));
    goto L28050;}
  else {
    arg0K0 = link_414X;
    goto L28050;}}
 L28061: {
  value_415X = arg0K0;
  addr_416X = (((char *) (-3 + table_401X))) + (((index_405X)<<2));S48_WRITE_BARRIER(table_401X, addr_416X, value_415X);
  *((long *) addr_416X) = (long) (value_415X);
  return x_413X;}
}
static void HtopD11605(char majorP_417X, char in_troubleP_418X)
{
  long arg0K2;
  long arg0K1;
  long arg0K0;
  long id_459X;
  long new_458X;
  long x_457X;
  long interrupt_456X;
  long id_455X;
  long status_454X;
  long v_453X;
  char v_452X;
  long channel_451X;
  long i_450X;
  char * addr_449X;
  long next_link_448X;
  long new_foo_447X;
  char v_446X;
  char * addr_445X;
  long foo_444X;
  char * addr_443X;
  long l_442X;
  long v_441X;
  long okay_link_440X;
  long foo_link_439X;
  char * addr_438X;
  char * addr_437X;
  char * addr_436X;
  char * addr_435X;
  long val_434X;
  char tracedP_433X;
  long next_432X;
  long thing_431X;
  long pair_430X;
  long alist_429X;
  long l2_428X;
  long goners_427X;
  long okay_426X;
  long alist_425X;
  long foo_link_424X;
  long v_423X;
  long pc_422X;
  long code_421X;
  long i_420X;
  long table_419X;
 {  table_419X = s48_trace_value((Sthe_symbol_tableS));
  arg0K0 = 0;
  goto L29206;}
 L29206: {
  i_420X = arg0K0;
  if ((1024 == i_420X)) {
    Sthe_symbol_tableS = table_419X;
    code_421X = Slast_code_calledS;
    pc_422X = Ssaved_pcS;
    Slast_code_calledS = code_421X;
    Scode_pointerS = ((((char *) (-3 + code_421X))) + pc_422X);
    Slast_code_pointer_resumedS = (Scode_pointerS);
    v_423X = SHARED_REF((Sfinalizer_alistS));
    arg0K0 = v_423X;
    arg0K1 = 25;
    arg0K2 = 25;
    goto L15343;}
  else {
    foo_link_424X = *((long *) ((((char *) (-3 + table_419X))) + (((i_420X)<<2))));
    arg0K0 = foo_link_424X;
    arg0K1 = 1;
    goto L19621;}}
 L15343: {
  alist_425X = arg0K0;
  okay_426X = arg0K1;
  goners_427X = arg0K2;
  if ((25 == alist_425X)) {SHARED_SETB((Sfinalizer_alistS), okay_426X);
    l2_428X = Sfinalize_theseS;
    if ((25 == goners_427X)) {
      arg0K0 = l2_428X;
      goto L15350;}
    else {
      arg0K0 = goners_427X;
      goto L15405;}}
  else {
    alist_429X = s48_trace_value(alist_425X);
    pair_430X = s48_trace_value((*((long *) (((char *) (-3 + alist_429X))))));
    thing_431X = *((long *) (((char *) (-3 + pair_430X))));
    next_432X = *((long *) ((((char *) (-3 + alist_429X))) + 4));
    tracedP_433X = s48_extantP(thing_431X);
    val_434X = s48_trace_value(thing_431X);
    addr_435X = ((char *) (-3 + pair_430X));S48_WRITE_BARRIER(pair_430X, addr_435X, val_434X);
    *((long *) addr_435X) = (long) (val_434X);
    addr_436X = ((char *) (-3 + alist_429X));S48_WRITE_BARRIER(alist_429X, addr_436X, pair_430X);
    *((long *) addr_436X) = (long) (pair_430X);
    if (tracedP_433X) {
      addr_437X = (((char *) (-3 + alist_429X))) + 4;S48_WRITE_BARRIER(alist_429X, addr_437X, okay_426X);
      *((long *) addr_437X) = (long) (okay_426X);
      arg0K0 = next_432X;
      arg0K1 = alist_429X;
      arg0K2 = goners_427X;
      goto L15343;}
    else {
      addr_438X = (((char *) (-3 + alist_429X))) + 4;S48_WRITE_BARRIER(alist_429X, addr_438X, goners_427X);
      *((long *) addr_438X) = (long) (goners_427X);
      arg0K0 = next_432X;
      arg0K1 = okay_426X;
      arg0K2 = alist_429X;
      goto L15343;}}}
 L19621: {
  foo_link_439X = arg0K0;
  okay_link_440X = arg0K1;
  if ((0 == (3 & foo_link_439X))) {
    arg0K0 = (3 + (-4 & foo_link_439X));
    goto L19623;}
  else {
    arg0K0 = foo_link_439X;
    goto L19623;}}
 L15350: {
  v_441X = arg0K0;
  Sfinalize_theseS = v_441X;
  arg0K0 = 0;
  goto L27523;}
 L15405: {
  l_442X = arg0K0;
  if ((25 == (*((long *) ((((char *) (-3 + l_442X))) + 4))))) {
    addr_443X = (((char *) (-3 + l_442X))) + 4;S48_WRITE_BARRIER(l_442X, addr_443X, l2_428X);
    *((long *) addr_443X) = (long) (l2_428X);
    arg0K0 = goners_427X;
    goto L15350;}
  else {
    arg0K0 = (*((long *) ((((char *) (-3 + l_442X))) + 4)));
    goto L15405;}}
 L19623: {
  foo_444X = arg0K0;
  if ((1 == foo_444X)) {
    addr_445X = (((char *) (-3 + table_419X))) + (((i_420X)<<2));S48_WRITE_BARRIER(table_419X, addr_445X, okay_link_440X);
    *((long *) addr_445X) = (long) (okay_link_440X);
    arg0K0 = (1 + i_420X);
    goto L29206;}
  else {
    v_446X = s48_extantP(foo_444X);
    if (v_446X) {
      new_foo_447X = s48_trace_value(foo_444X);
      next_link_448X = *((long *) ((((char *) (-3 + new_foo_447X))) + 4));
      addr_449X = (((char *) (-3 + new_foo_447X))) + 4;S48_WRITE_BARRIER(new_foo_447X, addr_449X, okay_link_440X);
      *((long *) addr_449X) = (long) (okay_link_440X);
      if ((3 == (3 & new_foo_447X))) {
        arg0K0 = next_link_448X;
        arg0K1 = (-4 & new_foo_447X);
        goto L19621;}
      else {
        arg0K0 = next_link_448X;
        arg0K1 = new_foo_447X;
        goto L19621;}}
    else {
      arg0K0 = (*((long *) ((((char *) (-3 + foo_444X))) + 4)));
      arg0K1 = okay_link_440X;
      goto L19621;}}}
 L27523: {
  i_450X = arg0K0;
  if ((i_450X == (Snumber_of_channelsS))) {
    Sgc_in_troublePS = in_troubleP_418X;
    if (majorP_417X) {
      arg0K0 = 3;
      goto L28450;}
    else {
      arg0K0 = 2;
      goto L28450;}}
  else {
    channel_451X = *((Svm_channelsS) + i_450X);
    if ((1 == channel_451X)) {
      goto L27557;}
    else {
      v_452X = s48_extantP(channel_451X);
      if (v_452X) {
        v_453X = s48_trace_value(channel_451X);
        arg0K0 = v_453X;
        goto L27550;}
      else {
        if ((0 == (*((long *) (((char *) (-3 + channel_451X))))))) {
          arg0K0 = 1;
          goto L27550;}
        else {
          status_454X = close_channelB(channel_451X);
          id_455X = *((long *) ((((char *) (-3 + channel_451X))) + 4));
          if ((status_454X == NO_ERRORS)) {
            goto L27581;}
          else {channel_close_error(status_454X, (*((long *) ((((char *) (-3 + channel_451X))) + 8))), id_455X);
            goto L27581;}}}}}}
 L28450: {
  interrupt_456X = arg0K0;
  PS_SHIFT_LEFT(1, interrupt_456X, x_457X)
  Spending_interruptsS = ((Spending_interruptsS) | x_457X);
  if ((0 == ((Spending_interruptsS) & (Senabled_interruptsS)))) {
    s48_Sstack_limitS = (Sreal_stack_limitS);
    if ((s48_Spending_eventsPS)) {
      s48_Sstack_limitS = (((char *) -1));
      return;}
    else {
      return;}}
  else {
    s48_Sstack_limitS = (((char *) -1));
    return;}}
 L27557: {
  arg0K0 = (1 + i_450X);
  goto L27523;}
 L27550: {
  new_458X = arg0K0;
  *((Svm_channelsS) + i_450X) = new_458X;
  goto L27557;}
 L27581: {
  if ((1 == (*((long *) ((((char *) (-3 + channel_451X))) + 12))))) {
    id_459X = *((long *) ((((char *) (-3 + channel_451X))) + 4));
    ps_write_string("Channel closed: ", (stderr));
    if ((0 == (3 & id_459X))) {
      ps_write_integer((((id_459X)>>2)), (stderr));
      goto L23562;}
    else {
      if ((3 == (3 & id_459X))) {
        if ((16 == (31 & ((((*((long *) ((((char *) (-3 + id_459X))) + -4))))>>2))))) {write_vm_string(id_459X, (stderr));
          goto L23562;}
        else {
          goto L23558;}}
      else {
        goto L23558;}}}
  else {
    arg0K0 = 1;
    goto L27550;}}
 L23562: {
  ps_write_string(" ", (stderr));
  ps_write_integer(((((*((long *) ((((char *) (-3 + channel_451X))) + 8))))>>2)), (stderr));
  { long ignoreXX;
  PS_WRITE_CHAR(10, (stderr), ignoreXX) }
  arg0K0 = 1;
  goto L27550;}
 L23558: {
  ps_write_string("<strange id>", (stderr));
  goto L23562;}
}
static void HtopD11616(void)
{
  char * arg3K0;
  long arg0K1;
  long arg0K0;
  long merged_arg0K0;

  int Hentry_tracer964460_return_tag;
  long Hentry_tracer9644600_return_value;
  long foo_link_461X;
  char * addr_530X;
  long next_link_529X;
  long new_foo_528X;
  long foo_527X;
  long done_link_526X;
  long foo_link_525X;
  long v_524X;
  long size_523X;
  char * pointer_522X;
  long v_521X;
  long v_520X;
  long v_519X;
  long cells_518X;
  long size_517X;
  char * pointer_516X;
  char * contents_pointer_515X;
  long new_code_514X;
  long mask_size_513X;
  char * code_pointer_512X;
  long pc_511X;
  char * pointer_510X;
  char * pointer_509X;
  char * cont_508X;
  long unused_507X;
  char * a_506X;
  char * addr_505X;
  long value_504X;
  long i_503X;
  char * addr_502X;
  long val_501X;
  char * addr_500X;
  long value_499X;
  long table_498X;
  long i_497X;
  char x_496X;
  long pair_495X;
  long table_494X;
  long v_493X;
  long v_492X;
  long alist_491X;
  long x2_490X;
  char * cell_489X;
  long i_488X;
  long x2_487X;
  char * cell_486X;
  long v_485X;
  long v_484X;
  long v_483X;
  long v_482X;
  long v_481X;
  long v_480X;
  long v_479X;
  long v_478X;
  long v_477X;
  long v_476X;
  long v_475X;
  long v_474X;
  long v_473X;
  long v_472X;
  long v_471X;
  long v_470X;
  long v_469X;
  long v_468X;
  long v_467X;
  long code_466X;
  char * frame_465X;
  long length_464X;
  char * frame_463X;
  long v_462X;
 {  v_462X = s48_trace_value((Sempty_logS));
  Sempty_logS = v_462X;
  arg3K0 = (Sexternal_root_stackS);
  goto L11584;}
 L11584: {
  frame_463X = arg3K0;
  if ((frame_463X == NULL)) {
    arg3K0 = (Spermanent_external_rootsS);
    goto L11610;}
  else {
    length_464X = *((long *) frame_463X);
    arg0K0 = 0;
    goto L11592;}}
 L11610: {
  frame_465X = arg3K0;
  if ((frame_465X == NULL)) {s48_initializing_gc_root();
    code_466X = current_code_vector();
    Ssaved_pcS = ((Scode_pointerS) - (((char *) (-3 + code_466X))));
    v_467X = s48_trace_value(code_466X);
    Slast_code_calledS = v_467X;
    v_468X = s48_trace_value((SvalS));
    SvalS = v_468X;
    v_469X = s48_trace_value((Scurrent_threadS));
    Scurrent_threadS = v_469X;
    v_470X = s48_trace_value((Sinterrupted_byte_opcode_return_codeS));
    Sinterrupted_byte_opcode_return_codeS = v_470X;
    v_471X = s48_trace_value((Sinterrupted_native_call_return_codeS));
    Sinterrupted_native_call_return_codeS = v_471X;
    v_472X = s48_trace_value((Snative_poll_return_codeS));
    Snative_poll_return_codeS = v_472X;
    v_473X = s48_trace_value((Sexception_return_codeS));
    Sexception_return_codeS = v_473X;
    v_474X = s48_trace_value((Snative_exception_return_codeS));
    Snative_exception_return_codeS = v_474X;
    v_475X = s48_trace_value((Scall_with_values_return_codeS));
    Scall_with_values_return_codeS = v_475X;
    v_476X = s48_trace_value((Sinterrupted_templateS));
    Sinterrupted_templateS = v_476X;
    v_477X = SHARED_REF((Ssession_dataS));
    v_478X = s48_trace_value(v_477X);SHARED_SETB((Ssession_dataS), v_478X);
    v_479X = SHARED_REF((Sexception_handlersS));
    v_480X = s48_trace_value(v_479X);SHARED_SETB((Sexception_handlersS), v_480X);
    v_481X = SHARED_REF((Sinterrupt_handlersS));
    v_482X = s48_trace_value(v_481X);SHARED_SETB((Sinterrupt_handlersS), v_482X);
    v_483X = SHARED_REF((Sfinalize_theseS));
    v_484X = s48_trace_value(v_483X);SHARED_SETB((Sfinalize_theseS), v_484X);
    v_485X = SHARED_REF((Sfinalizer_alistS));
    arg0K0 = v_485X;
    goto L11650;}
  else {
    cell_486X = ((char *) (*((long *) (frame_465X + 8))));
    x2_487X = s48_trace_value((*((long *) cell_486X)));
    *((long *) cell_486X) = (long) (x2_487X);
    arg3K0 = (((char *) (*((long *) frame_465X))));
    goto L11610;}}
 L11592: {
  i_488X = arg0K0;
  if ((i_488X == length_464X)) {
    arg3K0 = (((char *) (*((long *) (frame_463X + 4)))));
    goto L11584;}
  else {
    cell_489X = ((char *) (*((long *) (frame_463X + (8 + (((i_488X)<<2)))))));
    x2_490X = s48_trace_value((*((long *) cell_489X)));
    *((long *) cell_489X) = (long) (x2_490X);
    arg0K0 = (1 + i_488X);
    goto L11592;}}
 L11650: {
  alist_491X = arg0K0;
  if ((25 == alist_491X)) {
    v_492X = s48_trace_value((Spending_channels_headS));
    Spending_channels_headS = v_492X;
    v_493X = s48_trace_value((Spending_channels_tailS));
    Spending_channels_tailS = v_493X;
    table_494X = s48_trace_value((Simported_bindingsS));
    arg0K0 = 0;
    goto L26223;}
  else {
    pair_495X = *((long *) (((char *) (-3 + alist_491X))));
    x_496X = s48_extantP((*((long *) (((char *) (-3 + pair_495X))))));
    if (x_496X) {
      goto L11675;}
    else {s48_trace_stob_contentsB((*((long *) (((char *) (-3 + pair_495X))))));
      goto L11675;}}}
 L26223: {
  i_497X = arg0K0;
  if ((1024 == i_497X)) {
    Simported_bindingsS = table_494X;
    table_498X = s48_trace_value((Sexported_bindingsS));
    arg0K0 = 0;
    goto L26244;}
  else {
    merged_arg0K0 = (*((long *) ((((char *) (-3 + table_494X))) + (((i_497X)<<2)))));
    Hentry_tracer964460_return_tag = 0;
    goto Hentry_tracer964460;
   Hentry_tracer964460_return_0:
    value_499X = Hentry_tracer9644600_return_value;
    addr_500X = (((char *) (-3 + table_494X))) + (((i_497X)<<2));S48_WRITE_BARRIER(table_494X, addr_500X, value_499X);
    *((long *) addr_500X) = (long) (value_499X);
    arg0K0 = (1 + i_497X);
    goto L26223;}}
 L11675: {
  val_501X = s48_trace_value((*((long *) ((((char *) (-3 + pair_495X))) + 4))));
  addr_502X = (((char *) (-3 + pair_495X))) + 4;S48_WRITE_BARRIER(pair_495X, addr_502X, val_501X);
  *((long *) addr_502X) = (long) (val_501X);
  arg0K0 = (*((long *) ((((char *) (-3 + alist_491X))) + 4)));
  goto L11650;}
 L26244: {
  i_503X = arg0K0;
  if ((1024 == i_503X)) {
    Sexported_bindingsS = table_498X;
    if ((Sstack_warningPS)) {
      arg3K0 = (Sstack_beginS);
      goto L8458;}
    else {
      goto L19854;}}
  else {
    merged_arg0K0 = (*((long *) ((((char *) (-3 + table_498X))) + (((i_503X)<<2)))));
    Hentry_tracer964460_return_tag = 1;
    goto Hentry_tracer964460;
   Hentry_tracer964460_return_1:
    value_504X = Hentry_tracer9644600_return_value;
    addr_505X = (((char *) (-3 + table_498X))) + (((i_503X)<<2));S48_WRITE_BARRIER(table_498X, addr_505X, value_504X);
    *((long *) addr_505X) = (long) (value_504X);
    arg0K0 = (1 + i_503X);
    goto L26244;}}
 L8458: {
  a_506X = arg3K0;
  if ((252645135 == (*((long *) a_506X)))) {
    arg3K0 = (a_506X + 4);
    goto L8458;}
  else {
    unused_507X = (((a_506X - (Sstack_beginS)))>>2);
    if ((unused_507X < 30)) {
      { long ignoreXX;
      PS_WRITE_CHAR(10, (stderr), ignoreXX) }
      ps_write_string("[Alert: stack overconsumption (", (stderr));
      ps_write_integer(unused_507X, (stderr));
      ps_write_string("); please inform the Scheme 48 implementors]", (stderr));
      { long ignoreXX;
      PS_WRITE_CHAR(10, (stderr), ignoreXX) }
      Sstack_warningPS = 0;
      goto L19854;}
    else {
      goto L19854;}}}
 L19854: {
s48_trace_locationsB((SstackS), ((SstackS) + (-4 & ((ScontS) - (SstackS)))));
  arg3K0 = (ScontS);
  goto L19864;}
 L19864: {
  cont_508X = arg3K0;
  pointer_509X = ((char *) (*((long *) cont_508X)));
  pointer_510X = pointer_509X + -5;
  pc_511X = ((((*((unsigned char *) pointer_510X)))<<8)) + (*((unsigned char *) (pointer_510X + 1)));
  code_pointer_512X = ((char *) (*((long *) cont_508X)));
  mask_size_513X = *((unsigned char *) (code_pointer_512X + -3));
  new_code_514X = s48_trace_value((3 + (((long) (pointer_509X + (0 - pc_511X))))));
  contents_pointer_515X = cont_508X + 4;
  *((long *) cont_508X) = (long) ((((long) ((((char *) (-3 + new_code_514X))) + pc_511X))));
  if ((0 == mask_size_513X)) {
    pointer_516X = (((char *) (*((long *) cont_508X)))) + -2;
    size_517X = ((((*((unsigned char *) pointer_516X)))<<8)) + (*((unsigned char *) (pointer_516X + 1)));
    if ((65535 == size_517X)) {
      arg0K0 = ((((*((long *) (cont_508X + 4))))>>2));
      goto L16759;}
    else {
      arg0K0 = size_517X;
      goto L16759;}}
  else {s48_trace_continuation_contentsB(contents_pointer_515X, code_pointer_512X, mask_size_513X);
    goto L19874;}}
 L16759: {
  cells_518X = arg0K0;s48_trace_locationsB(contents_pointer_515X, (contents_pointer_515X + (((cells_518X)<<2))));
  goto L19874;}
 L19874: {
  if ((cont_508X == (Sbottom_of_stackS))) {
    v_519X = s48_trace_value((Sheap_continuationS));
    Sheap_continuationS = v_519X;
    v_520X = s48_trace_value((Stemp0S));
    Stemp0S = v_520X;
    v_521X = s48_trace_value((Stemp1S));
    Stemp1S = v_521X;
    return;}
  else {
    pointer_522X = (((char *) (*((long *) cont_508X)))) + -2;
    size_523X = ((((*((unsigned char *) pointer_522X)))<<8)) + (*((unsigned char *) (pointer_522X + 1)));
    if ((65535 == size_523X)) {
      arg0K0 = ((((*((long *) (cont_508X + 4))))>>2));
      goto L19912;}
    else {
      arg0K0 = size_523X;
      goto L19912;}}}
 L19912: {
  v_524X = arg0K0;
  arg3K0 = (cont_508X + (4 + (((v_524X)<<2))));
  goto L19864;}
 Hentry_tracer964460: {
  foo_link_461X = merged_arg0K0;{
  arg0K0 = foo_link_461X;
  arg0K1 = 1;
  goto L19693;}
 L19693: {
  foo_link_525X = arg0K0;
  done_link_526X = arg0K1;
  if ((0 == (3 & foo_link_525X))) {
    arg0K0 = (3 + (-4 & foo_link_525X));
    goto L19695;}
  else {
    arg0K0 = foo_link_525X;
    goto L19695;}}
 L19695: {
  foo_527X = arg0K0;
  if ((1 == foo_527X)) {
    Hentry_tracer9644600_return_value = done_link_526X;
    goto Hentry_tracer964460_return;}
  else {
    new_foo_528X = s48_trace_value(foo_527X);
    next_link_529X = *((long *) ((((char *) (-3 + new_foo_528X))) + 12));
    addr_530X = (((char *) (-3 + new_foo_528X))) + 12;S48_WRITE_BARRIER(new_foo_528X, addr_530X, done_link_526X);
    *((long *) addr_530X) = (long) (done_link_526X);
    if ((3 == (3 & new_foo_528X))) {
      arg0K0 = next_link_529X;
      arg0K1 = (-4 & new_foo_528X);
      goto L19693;}
    else {
      arg0K0 = next_link_529X;
      arg0K1 = new_foo_528X;
      goto L19693;}}}
 Hentry_tracer964460_return:
  switch (Hentry_tracer964460_return_tag) {
  case 0: goto Hentry_tracer964460_return_0;
  default: goto Hentry_tracer964460_return_1;
  }}

}
static long unused_event_type_uid(void)
{
  char v_531X;
 {  goto L65523;}
 L65523: {
  if ((NULL == (Sunused_event_types_headS))) {
    v_531X = add_external_event_types(((((Snumber_of_event_typesS))<<1)));
    if (v_531X) {
      goto L65523;}
    else {
      return -1;}}
  else {
    return ((Sunused_event_types_headS)->uid);}}
}
void s48_set_native_protocolB(long protocol_532X)
{

 {  s48_Snative_protocolS = protocol_532X;
  return;}
}
void s48_set_extension_valueB(long value_533X)
{

 {  s48_Sextension_valueS = value_533X;
  return;}
}
long s48_channel_count(void)
{

 {  return (Snumber_of_channelsS);}
}
long *s48_channels(void)
{

 {  return (Svm_channelsS);}
}
long s48_imported_bindings(void)
{

 {  return (Simported_bindingsS);}
}
long s48_exported_bindings(void)
{

 {  return (Sexported_bindingsS);}
}
char s48_os_signal_pending(void)
{
  long arg0K0;
  long v_534X;
 {  if (((Sos_signal_ring_readyS) == (Sos_signal_ring_endS))) {
    return 0;}
  else {
    if ((31 == (Sos_signal_ring_readyS))) {
      arg0K0 = 0;
      goto L3644;}
    else {
      arg0K0 = (1 + (Sos_signal_ring_readyS));
      goto L3644;}}}
 L3644: {
  v_534X = arg0K0;
  Sos_signal_ring_readyS = v_534X;
  return 1;}
}
long s48_symbol_table(void)
{

 {  return (Sthe_symbol_tableS);}
}
char * s48_set_gc_roots_baseB(void)
{
  char * old_base_535X;
 {  old_base_535X = Sexternal_root_stack_baseS;
  Sexternal_root_stack_baseS = (Sexternal_root_stackS);
  return old_base_535X;}
}
char s48_release_gc_roots_baseB(char * old_base_536X)
{
  char * current_base_537X;
 {  current_base_537X = Sexternal_root_stack_baseS;
  Sexternal_root_stack_baseS = old_base_536X;
  if (((Sexternal_root_stackS) == current_base_537X)) {
    return 1;}
  else {
    Sexternal_root_stackS = current_base_537X;
    return 0;}}
}
void s48_reset_external_rootsB(void)
{

 {  Sexternal_root_stackS = NULL;
  Sexternal_root_stack_baseS = NULL;
  Spermanent_external_rootsS = NULL;
  return;}
}
char s48_external_event_readyPUunsafe(void)
{

 {  if ((NULL == (Spending_event_types_readyS))) {
    return 0;}
  else {
    return 1;}}
}
void s48_note_event(void)
{

 {  s48_Spending_eventsPS = 1;
  s48_Sstack_limitS = (((char *) -1));
  return;}
}
void s48_reset_interruptsB(void)
{

 {  Sos_signal_ring_startS = 0;
  Sos_signal_ring_readyS = 0;
  Sos_signal_ring_endS = 0;
  Senabled_interruptsS = 0;
  Spending_interruptsS = 0;
  s48_Spending_interruptPS = 0;
  return;}
}
void s48_disable_interruptsB(void)
{

 {  s48_Spending_interruptPS = 0;
  Senabled_interruptsS = 0;
  return;}
}
void s48_add_os_signal(long sig_538X)
{
  long arg0K0;
  long v_539X;
 {  if ((31 == (Sos_signal_ring_endS))) {
    arg0K0 = 0;
    goto L4880;}
  else {
    arg0K0 = (1 + (Sos_signal_ring_endS));
    goto L4880;}}
 L4880: {
  v_539X = arg0K0;
  Sos_signal_ring_endS = v_539X;
  if (((Sos_signal_ring_startS) == (Sos_signal_ring_endS))) {
    ps_error("OS signal ring too small, report to Scheme 48 maintainers", 0);
    goto L4882;}
  else {
    goto L4882;}}
 L4882: {
  *(Sos_signal_ringS + (Sos_signal_ring_endS)) = sig_538X;
  return;}
}
void s48_push_gc_rootsB(char * frame_540X, long n_541X)
{

 {  *((long *) frame_540X) = (long) (n_541X);
  *((long *) (frame_540X + 4)) = (long) ((((long) (Sexternal_root_stackS))));
  Sexternal_root_stackS = frame_540X;
  return;}
}
char * s48_register_gc_rootB(char * loc_addr_542X)
{
  char * x_544X;
  char * frame_543X;
 {  frame_543X = (char *)malloc(12);
  if ((frame_543X == NULL)) {
    ps_error("out of memory registering a global root", 0);
    goto L5088;}
  else {
    goto L5088;}}
 L5088: {
  *((long *) frame_543X) = (long) ((((long) (Spermanent_external_rootsS))));
  *((long *) (frame_543X + 4)) = (long) ((((long) NULL)));
  x_544X = Spermanent_external_rootsS;
  if ((x_544X == NULL)) {
    goto L5108;}
  else {
    *((long *) ((Spermanent_external_rootsS) + 4)) = (long) ((((long) frame_543X)));
    goto L5108;}}
 L5108: {
  *((long *) (frame_543X + 8)) = (long) ((((long) loc_addr_542X)));
  Spermanent_external_rootsS = frame_543X;
  return frame_543X;}
}
char s48_external_event_pendingPUunsafe(void)
{

 {  if ((NULL == (Spending_event_types_readyS))) {
    return 0;}
  else {
    Spending_event_types_readyS = ((Spending_event_types_readyS)->next);
    return 1;}}
}
long s48_dequeue_external_eventBUunsafe(char *TT0)
{
  long v_547X;
  struct event_type *next_546X;
  struct event_type *type_545X;
 {  type_545X = Spending_event_types_headS;
  next_546X = type_545X->next;
  Spending_event_types_headS = next_546X;
  type_545X->next = (NULL);
  if ((NULL == next_546X)) {
    Spending_event_types_tailS = (NULL);
    goto L5544;}
  else {
    goto L5544;}}
 L5544: {
  v_547X = type_545X->uid;
  if ((NULL == (Spending_event_types_readyS))) {
    *TT0 = 0;
    return v_547X;}
  else {
    *TT0 = 1;
    return v_547X;}}
}
void s48_unregister_external_event_uid(long index_548X)
{
  struct event_type *type_550X;
  struct event_type *type_549X;
 {  if ((index_548X < (Snumber_of_event_typesS))) {
    goto L6555;}
  else {
    ps_write_string("trying to unregister invalid external event: ", (stderr));
    ps_write_integer(index_548X, (stderr));
    { long ignoreXX;
    PS_WRITE_CHAR(10, (stderr), ignoreXX) }
    ps_error("assertion violation", 0);
    goto L6555;}}
 L6555: {
  type_549X = *((Sevent_typesS) + index_548X);
  if ((type_549X->usedP)) {
    if ((NULL == (type_549X->next))) {
      type_550X = *((Sevent_typesS) + index_548X);
      if ((NULL == (type_550X->next))) {
        type_550X->next = (Sunused_event_types_headS);
        type_550X->usedP = 0;
        Sunused_event_types_headS = type_550X;
        return;}
      else {
        ps_write_string("trying to unregister external event that is still in use : ", (stderr));
        ps_write_integer(index_548X, (stderr));
        { long ignoreXX;
        PS_WRITE_CHAR(10, (stderr), ignoreXX) }
        ps_error("assertion violation", 0);
        return;}}
    else {
      ps_write_string("trying to unregister external event that is still in use : ", (stderr));
      ps_write_integer(index_548X, (stderr));
      { long ignoreXX;
      PS_WRITE_CHAR(10, (stderr), ignoreXX) }
      ps_error("assertion violation", 0);
      return;}}
  else {
    ps_write_string("trying to unregister invalid external event: ", (stderr));
    ps_write_integer(index_548X, (stderr));
    { long ignoreXX;
    PS_WRITE_CHAR(10, (stderr), ignoreXX) }
    ps_error("assertion violation", 0);
    return;}}
}
void s48_note_external_eventBUunsafe(long index_551X)
{
  struct event_type *type_552X;
 {  if ((index_551X < (Snumber_of_event_typesS))) {
    goto L6724;}
  else {
    ps_write_string("invalid external event: ", (stderr));
    ps_write_integer(index_551X, (stderr));
    { long ignoreXX;
    PS_WRITE_CHAR(10, (stderr), ignoreXX) }
    ps_error("assertion-violation", 0);
    goto L6724;}}
 L6724: {
  type_552X = *((Sevent_typesS) + index_551X);
  if ((type_552X->usedP)) {
    if ((NULL == (type_552X->next))) {
      if ((type_552X == (Spending_event_types_headS))) {
        return;}
      else {
        if ((type_552X == (Spending_event_types_tailS))) {
          return;}
        else {
          if ((NULL == (Spending_event_types_headS))) {
            Spending_event_types_headS = type_552X;
            Spending_event_types_tailS = type_552X;
            Spending_event_types_readyS = type_552X;
            return;}
          else {
            (Spending_event_types_tailS)->next = type_552X;
            Spending_event_types_tailS = type_552X;
            return;}}}}
    else {
      return;}}
  else {
    ps_write_string("invalid external event: ", (stderr));
    ps_write_integer(index_551X, (stderr));
    { long ignoreXX;
    PS_WRITE_CHAR(10, (stderr), ignoreXX) }
    ps_error("assertion-violation", 0);
    return;}}
}
void s48_stack_setB(long x_553X, long value_554X)
{

 {  *((long *) ((SstackS) + (((x_553X)<<2)))) = (long) (value_554X);
  return;}
}
long s48_stack_ref(long i_555X)
{

 {  return (*((long *) ((SstackS) + (((i_555X)<<2)))));}
}
void s48_push(long x_556X)
{

 {  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_556X);
  return;}
}
long s48_resetup_external_exception(long new_why_557X, long additional_nargs_558X)
{
  long old_why_560X;
  long old_nargs_559X;
 {  old_nargs_559X = Sexternal_exception_nargsS;
  old_why_560X = *((long *) ((SstackS) + (((old_nargs_559X)<<2))));
  *((long *) ((SstackS) + (((old_nargs_559X)<<2)))) = (long) ((((new_why_557X)<<2)));
  Sexternal_exception_nargsS = (old_nargs_559X + additional_nargs_558X);
  return old_why_560X;}
}
char s48_pop_gc_rootsB(void)
{

 {  if (((Sexternal_root_stackS) == (Sexternal_root_stack_baseS))) {
    return 0;}
  else {
    Sexternal_root_stackS = (((char *) (*((long *) ((Sexternal_root_stackS) + 4)))));
    return 1;}}
}
void s48_unregister_gc_rootB(char * frame_561X)
{
  char * previous_563X;
  char * next_562X;
 {  if ((frame_561X == (Spermanent_external_rootsS))) {
    Spermanent_external_rootsS = (((char *) (*((long *) frame_561X))));
    goto L10086;}
  else {
    next_562X = ((char *) (*((long *) frame_561X)));
    previous_563X = ((char *) (*((long *) (frame_561X + 4))));
    *((long *) previous_563X) = (long) ((((long) next_562X)));
    if ((next_562X == NULL)) {
      goto L10086;}
    else {
      *((long *) (next_562X + 4)) = (long) ((((long) previous_563X)));
      goto L10086;}}}
 L10086: {
  free(frame_561X);
  return;}
}
char * s48_shorten_bignum(char * external_bignum_564X, long number_of_digits_565X)
{
  long waste_size_570X;
  long old_data_size_569X;
  long new_data_size_568X;
  long new_size_567X;
  long bignum_566X;
 {  bignum_566X = 3 + (((long) external_bignum_564X));
  new_size_567X = 4 + (-4 & (7 + (((number_of_digits_565X)<<2))));
  new_data_size_568X = -4 + new_size_567X;
  old_data_size_569X = (long)(((unsigned long)(*((long *) ((((char *) (-3 + bignum_566X))) + -4))))>>8);
  waste_size_570X = old_data_size_569X - new_data_size_568X;
  if ((waste_size_570X < 0)) {
    ps_error("shorten bignum", 2, new_data_size_568X, old_data_size_569X);
    goto L10819;}
  else {
    goto L10819;}}
 L10819: {
  if ((waste_size_570X < 4)) {
    return external_bignum_564X;}
  else {
    *((long *) ((((char *) (-3 + bignum_566X))) + -4)) = (long) ((78 + (((new_data_size_568X)<<8))));
    *((long *) ((((char *) (((long) ((((char *) (-3 + bignum_566X))) + (-4 & (3 + new_size_567X))))))) + -4)) = (long) ((-946 + (((waste_size_570X)<<8))));
    return external_bignum_564X;}}
}
long s48_allocate_string(long len_571X)
{
  long arg0K0;
  long string_574X;
  char * addr_573X;
  long len_572X;
 {  len_572X = ((len_571X)<<2);
  addr_573X = s48_allocate_untracedAgc((4 + len_572X));
  if ((addr_573X == NULL)) {
    arg0K0 = 1;
    goto L13648;}
  else {
    *((long *) addr_573X) = (long) ((66 + (((len_572X)<<8))));
    arg0K0 = (3 + (((long) (addr_573X + 4))));
    goto L13648;}}
 L13648: {
  string_574X = arg0K0;
  if ((1 == string_574X)) {
    ps_error("Out of space, unable to allocate", 0);
    return string_574X;}
  else {
    return string_574X;}}
}
long s48_allocate_bignum(long size_575X)
{
  char * addr_576X;
 {  addr_576X = s48_allocate_small((4 + size_575X));
  *((long *) addr_576X) = (long) ((78 + (((size_575X)<<8))));
  return (3 + (((long) (addr_576X + 4))));}
}
void s48_enable_interruptsB(void)
{

 {  Senabled_interruptsS = -1;
  if ((0 == ((Spending_interruptsS) & (Senabled_interruptsS)))) {
    s48_Sstack_limitS = (Sreal_stack_limitS);
    if ((s48_Spending_eventsPS)) {
      s48_Sstack_limitS = (((char *) -1));
      return;}
    else {
      return;}}
  else {
    s48_Sstack_limitS = (((char *) -1));
    return;}}
}
long s48_set_channel_os_index(long channel_577X, long os_index_578X)
{
  char * addr_585X;
  long val_584X;
  long v_583X;
  long x_582X;
  long old_index_581X;
  char x_580X;
  char temp_579X;
 {  temp_579X = os_index_578X < (Snumber_of_channelsS);
  if (temp_579X) {
    goto L15523;}
  else {
    x_580X = add_more_channels(os_index_578X);
    if (x_580X) {
      goto L15523;}
    else {
      return 36;}}}
 L15523: {
  if ((1 == (*((Svm_channelsS) + os_index_578X)))) {
    old_index_581X = (((*((long *) ((((char *) (-3 + channel_577X))) + 8))))>>2);
    x_582X = *((long *) ((((char *) (-3 + channel_577X))) + 20));
    if ((5 == x_582X)) {
      v_583X = ps_abort_fd_op(old_index_581X);enqueue_channelB(old_index_581X, v_583X, 1);
      goto L15509;}
    else {
      goto L15509;}}
  else {
    return 44;}}
 L15509: {
  *((Svm_channelsS) + old_index_581X) = 1;
  *((Svm_channelsS) + os_index_578X) = channel_577X;
  val_584X = ((os_index_578X)<<2);
  addr_585X = (((char *) (-3 + channel_577X))) + 8;S48_WRITE_BARRIER(channel_577X, addr_585X, val_584X);
  *((long *) addr_585X) = (long) (val_584X);
  return 5;}
}
long s48_enter_string_utf_8(char * p_586X)
{
  long arg0K1;
  long arg0K0;
  long vm_600X;
  long string_599X;
  char * addr_598X;
  long len_597X;
  long decoded_596X;
  long consumed_595X;
  long count_594X;
  long v_593X;
  char incompleteP_592X;
  char v_591X;
  char encoding_okP_590X;
  long target_index_589X;
  long index_588X;
  long size_587X;
 {  size_587X = strlen((char *) (((char *)p_586X)));
  arg0K0 = 0;
  arg0K1 = 0;
  goto L17810;}
 L17810: {
  index_588X = arg0K0;
  target_index_589X = arg0K1;
  if ((index_588X < size_587X)) {
    encoding_okP_590X = decode_scalar_value(2, (p_586X + index_588X), (size_587X - index_588X), &v_591X, &incompleteP_592X, &v_593X, &count_594X);
    if (encoding_okP_590X) {
      if (incompleteP_592X) {
        arg0K0 = index_588X;
        arg0K1 = target_index_589X;
        goto L17787;}
      else {
        arg0K0 = (index_588X + count_594X);
        arg0K1 = (1 + target_index_589X);
        goto L17810;}}
    else {
      arg0K0 = (1 + index_588X);
      arg0K1 = (1 + target_index_589X);
      goto L17810;}}
  else {
    arg0K0 = index_588X;
    arg0K1 = target_index_589X;
    goto L17787;}}
 L17787: {
  consumed_595X = arg0K0;
  decoded_596X = arg0K1;
  len_597X = ((decoded_596X)<<2);
  addr_598X = s48_allocate_untracedAgc((4 + len_597X));
  if ((addr_598X == NULL)) {
    arg0K0 = 1;
    goto L17828;}
  else {
    *((long *) addr_598X) = (long) ((66 + (((len_597X)<<8))));
    arg0K0 = (3 + (((long) (addr_598X + 4))));
    goto L17828;}}
 L17828: {
  string_599X = arg0K0;
  if ((1 == string_599X)) {
    ps_error("Out of space, unable to allocate", 0);
    arg0K0 = string_599X;
    goto L17793;}
  else {
    arg0K0 = string_599X;
    goto L17793;}}
 L17793: {
  vm_600X = arg0K0;decode_utf_8B(p_586X, vm_600X, consumed_595X);
  return vm_600X;}
}
long s48_enter_string_utf_8_n(char * p_601X, long size_602X)
{
  long arg0K1;
  long arg0K0;
  long vm_615X;
  long string_614X;
  char * addr_613X;
  long len_612X;
  long decoded_611X;
  long consumed_610X;
  long count_609X;
  long v_608X;
  char incompleteP_607X;
  char v_606X;
  char encoding_okP_605X;
  long target_index_604X;
  long index_603X;
 {  arg0K0 = 0;
  arg0K1 = 0;
  goto L17870;}
 L17870: {
  index_603X = arg0K0;
  target_index_604X = arg0K1;
  if ((index_603X < size_602X)) {
    encoding_okP_605X = decode_scalar_value(2, (p_601X + index_603X), (size_602X - index_603X), &v_606X, &incompleteP_607X, &v_608X, &count_609X);
    if (encoding_okP_605X) {
      if (incompleteP_607X) {
        arg0K0 = index_603X;
        arg0K1 = target_index_604X;
        goto L17850;}
      else {
        arg0K0 = (index_603X + count_609X);
        arg0K1 = (1 + target_index_604X);
        goto L17870;}}
    else {
      arg0K0 = (1 + index_603X);
      arg0K1 = (1 + target_index_604X);
      goto L17870;}}
  else {
    arg0K0 = index_603X;
    arg0K1 = target_index_604X;
    goto L17850;}}
 L17850: {
  consumed_610X = arg0K0;
  decoded_611X = arg0K1;
  len_612X = ((decoded_611X)<<2);
  addr_613X = s48_allocate_untracedAgc((4 + len_612X));
  if ((addr_613X == NULL)) {
    arg0K0 = 1;
    goto L17888;}
  else {
    *((long *) addr_613X) = (long) ((66 + (((len_612X)<<8))));
    arg0K0 = (3 + (((long) (addr_613X + 4))));
    goto L17888;}}
 L17888: {
  string_614X = arg0K0;
  if ((1 == string_614X)) {
    ps_error("Out of space, unable to allocate", 0);
    arg0K0 = string_614X;
    goto L17856;}
  else {
    arg0K0 = string_614X;
    goto L17856;}}
 L17856: {
  vm_615X = arg0K0;decode_utf_8B(p_601X, vm_615X, consumed_610X);
  return vm_615X;}
}
long s48_integer_or_floanum_L(long x_616X, long y_617X)
{
  long v_620X;
  long v_619X;
  long v_618X;
 {  if ((3 == (3 & x_616X))) {
    if ((18 == (31 & ((((*((long *) ((((char *) (-3 + x_616X))) + -4))))>>2))))) {
      if (((*((double *) (((char *) (-3 + x_616X))))) < (*((double *) (((char *) (-3 + y_617X))))))) {
        return 5;}
      else {
        return 1;}}
    else {
      goto L19069;}}
  else {
    goto L19069;}}
 L19069: {
  if ((0 == (3 & x_616X))) {
    if ((0 == (3 & y_617X))) {
      if ((x_616X < y_617X)) {
        return 5;}
      else {
        return 1;}}
    else {
      v_618X = s48_bignum_test((((char *) (-3 + y_617X))));
      if ((1 == v_618X)) {
        return 5;}
      else {
        return 1;}}}
  else {
    if ((0 == (3 & y_617X))) {
      v_619X = s48_bignum_test((((char *) (-3 + x_616X))));
      if ((1 == v_619X)) {
        return 1;}
      else {
        return 5;}}
    else {
      v_620X = s48_bignum_compare((((char *) (-3 + x_616X))), (((char *) (-3 + y_617X))));
      if ((-1 == v_620X)) {
        return 5;}
      else {
        return 1;}}}}
}
long s48_integer_or_floanum_G(long x_621X, long y_622X)
{
  long v_625X;
  long v_624X;
  long v_623X;
 {  if ((3 == (3 & x_621X))) {
    if ((18 == (31 & ((((*((long *) ((((char *) (-3 + x_621X))) + -4))))>>2))))) {
      if (((*((double *) (((char *) (-3 + y_622X))))) < (*((double *) (((char *) (-3 + x_621X))))))) {
        return 5;}
      else {
        return 1;}}
    else {
      goto L19198;}}
  else {
    goto L19198;}}
 L19198: {
  if ((0 == (3 & y_622X))) {
    if ((0 == (3 & x_621X))) {
      if ((y_622X < x_621X)) {
        return 5;}
      else {
        return 1;}}
    else {
      v_623X = s48_bignum_test((((char *) (-3 + x_621X))));
      if ((1 == v_623X)) {
        return 5;}
      else {
        return 1;}}}
  else {
    if ((0 == (3 & x_621X))) {
      v_624X = s48_bignum_test((((char *) (-3 + y_622X))));
      if ((1 == v_624X)) {
        return 1;}
      else {
        return 5;}}
    else {
      v_625X = s48_bignum_compare((((char *) (-3 + y_622X))), (((char *) (-3 + x_621X))));
      if ((-1 == v_625X)) {
        return 5;}
      else {
        return 1;}}}}
}
long s48_integer_or_floanum_LE(long x_626X, long y_627X)
{
  char b_628X;
 {  if ((3 == (3 & x_626X))) {
    if ((18 == (31 & ((((*((long *) ((((char *) (-3 + x_626X))) + -4))))>>2))))) {
      if (((*((double *) (((char *) (-3 + y_627X))))) < (*((double *) (((char *) (-3 + x_626X))))))) {
        return 1;}
      else {
        return 5;}}
    else {
      goto L19327;}}
  else {
    goto L19327;}}
 L19327: {
  b_628X = integerLE(x_626X, y_627X);
  if (b_628X) {
    return 5;}
  else {
    return 1;}}
}
long s48_integer_or_floanum_GE(long x_629X, long y_630X)
{
  char b_631X;
 {  if ((3 == (3 & x_629X))) {
    if ((18 == (31 & ((((*((long *) ((((char *) (-3 + x_629X))) + -4))))>>2))))) {
      if (((*((double *) (((char *) (-3 + x_629X))))) < (*((double *) (((char *) (-3 + y_630X))))))) {
        return 1;}
      else {
        return 5;}}
    else {
      goto L19404;}}
  else {
    goto L19404;}}
 L19404: {
  b_631X = integerGE(x_629X, y_630X);
  if (b_631X) {
    return 5;}
  else {
    return 1;}}
}
long s48_make_blank_return_code(long protocol_632X, long template_633X, long frame_size_634X, long opcode_count_635X)
{

 {s48_make_availableAgc((4 + (-4 & (18 + opcode_count_635X))));
  return make_blank_return_code(protocol_632X, template_633X, frame_size_634X, opcode_count_635X, 0);}
}
long s48_enter_string_latin_1_n(char *s_636X, long count_637X)
{

 {  return enter_stringAgc_n(s_636X, count_637X);}
}
long s48_integer_or_floanum_E(long x_638X, long y_639X)
{
  char arg4K0;
  char v_641X;
  char b_640X;
 {  if ((3 == (3 & x_638X))) {
    if ((18 == (31 & ((((*((long *) ((((char *) (-3 + x_638X))) + -4))))>>2))))) {
      arg4K0 = ((*((double *) (((char *) (-3 + x_638X))))) == (*((double *) (((char *) (-3 + y_639X))))));
      goto L21963;}
    else {
      goto L21959;}}
  else {
    goto L21959;}}
 L21963: {
  b_640X = arg4K0;
  if (b_640X) {
    return 5;}
  else {
    return 1;}}
 L21959: {
  v_641X = integerE(x_638X, y_639X);
  arg4K0 = v_641X;
  goto L21963;}
}
void s48_close_channel(long os_index_642X)
{
  long obj_643X;
 {  if ((os_index_642X < 0)) {
    return;}
  else {
    if ((os_index_642X < (Snumber_of_channelsS))) {
      obj_643X = *((Svm_channelsS) + os_index_642X);
      if ((3 == (3 & obj_643X))) {
        if ((6 == (31 & ((((*((long *) ((((char *) (-3 + obj_643X))) + -4))))>>2))))) {close_channelB((*((Svm_channelsS) + os_index_642X)));
          return;}
        else {
          return;}}
      else {
        return;}}
    else {
      return;}}}
}
long s48_enter_string_latin_1(char *s_644X)
{

 {  return enter_stringAgc_n(s_644X, (strlen((char *) s_644X)));}
}
void s48_string_set(long s_645X, long i_646X, long c_647X)
{
  long arg0K2;
  long arg0K1;
  long arg0K0;
  long shifted_652X;
  long j_651X;
  long bits_650X;
  long max_649X;
  long v_648X;
 {  if ((3 == (3 & s_645X))) {
    if ((16 == (31 & ((((*((long *) ((((char *) (-3 + s_645X))) + -4))))>>2))))) {
      goto L25444;}
    else {s48_raise_argument_type_error(s_645X);
      goto L25444;}}
  else {s48_raise_argument_type_error(s_645X);
    goto L25444;}}
 L25444: {
  v_648X = ((long)(((unsigned long)(*((long *) ((((char *) (-3 + s_645X))) + -4))))>>8)) / 4;
  max_649X = -1 + v_648X;
  if ((i_646X < 0)) {
    goto L25466;}
  else {
    if ((max_649X < i_646X)) {
      goto L25466;}
    else {
      goto L25446;}}}
 L25466: {
s48_raise_range_error((((i_646X)<<2)), 0, (((max_649X)<<2)));
  goto L25446;}
 L25446: {
  arg0K0 = 0;
  arg0K1 = 0;
  arg0K2 = c_647X;
  goto L25486;}
 L25486: {
  bits_650X = arg0K0;
  j_651X = arg0K1;
  shifted_652X = arg0K2;
  if ((j_651X < 4)) {
    *((unsigned char *) ((((char *) (-3 + s_645X))) + ((((i_646X)<<2)) + j_651X))) = (unsigned char) ((255 & shifted_652X));
    arg0K0 = (8 + bits_650X);
    arg0K1 = (1 + j_651X);
    arg0K2 = ((long)(((unsigned long)shifted_652X)>>8));
    goto L25486;}
  else {
    return;}}
}
long s48_string_ref(long s_653X, long i_654X)
{
  long arg0K2;
  long arg0K1;
  long arg0K0;
  long x_660X;
  long scalar_value_659X;
  long j_658X;
  long bits_657X;
  long max_656X;
  long v_655X;
 {  if ((3 == (3 & s_653X))) {
    if ((16 == (31 & ((((*((long *) ((((char *) (-3 + s_653X))) + -4))))>>2))))) {
      goto L25508;}
    else {s48_raise_argument_type_error(s_653X);
      goto L25508;}}
  else {s48_raise_argument_type_error(s_653X);
    goto L25508;}}
 L25508: {
  v_655X = ((long)(((unsigned long)(*((long *) ((((char *) (-3 + s_653X))) + -4))))>>8)) / 4;
  max_656X = -1 + v_655X;
  if ((i_654X < 0)) {
    goto L25530;}
  else {
    if ((max_656X < i_654X)) {
      goto L25530;}
    else {
      goto L25510;}}}
 L25530: {
s48_raise_range_error((((i_654X)<<2)), 0, (((max_656X)<<2)));
  goto L25510;}
 L25510: {
  arg0K0 = 0;
  arg0K1 = 0;
  arg0K2 = 0;
  goto L25549;}
 L25549: {
  bits_657X = arg0K0;
  j_658X = arg0K1;
  scalar_value_659X = arg0K2;
  if ((j_658X < 4)) {
    PS_SHIFT_LEFT((*((unsigned char *) ((((char *) (-3 + s_653X))) + ((((i_654X)<<2)) + j_658X)))), bits_657X, x_660X)
    arg0K0 = (8 + bits_657X);
    arg0K1 = (1 + j_658X);
    arg0K2 = (x_660X + scalar_value_659X);
    goto L25549;}
  else {
    return scalar_value_659X;}}
}
long s48_string_length(long s_661X)
{

 {  if ((3 == (3 & s_661X))) {
    if ((16 == (31 & ((((*((long *) ((((char *) (-3 + s_661X))) + -4))))>>2))))) {
      goto L25568;}
    else {s48_raise_argument_type_error(s_661X);
      goto L25568;}}
  else {s48_raise_argument_type_error(s_661X);
    goto L25568;}}
 L25568: {
  return (((long)(((unsigned long)(*((long *) ((((char *) (-3 + s_661X))) + -4))))>>8)) / 4);}
}
void s48_copy_latin_1_to_string_n(char *string_662X, long len_663X, long vm_string_664X)
{
  long arg0K2;
  long arg0K1;
  long arg0K0;
  long shifted_670X;
  long j_669X;
  long bits_668X;
  long c_667X;
  long i_666X;
  long max_665X;
 {  if ((3 == (3 & vm_string_664X))) {
    if ((16 == (31 & ((((*((long *) ((((char *) (-3 + vm_string_664X))) + -4))))>>2))))) {
      goto L25596;}
    else {s48_raise_argument_type_error(vm_string_664X);
      goto L25596;}}
  else {s48_raise_argument_type_error(vm_string_664X);
    goto L25596;}}
 L25596: {
  max_665X = ((long)(((unsigned long)(*((long *) ((((char *) (-3 + vm_string_664X))) + -4))))>>8)) / 4;
  if ((len_663X < 0)) {
    goto L25620;}
  else {
    if ((max_665X < len_663X)) {
      goto L25620;}
    else {
      goto L25600;}}}
 L25620: {
s48_raise_range_error((((len_663X)<<2)), 0, (((max_665X)<<2)));
  goto L25600;}
 L25600: {
  arg0K0 = 0;
  goto L25638;}
 L25638: {
  i_666X = arg0K0;
  if ((i_666X < len_663X)) {
    c_667X = ((unsigned char) (*(string_662X + i_666X)));
    arg0K0 = 0;
    arg0K1 = 0;
    arg0K2 = c_667X;
    goto L25649;}
  else {
    return;}}
 L25649: {
  bits_668X = arg0K0;
  j_669X = arg0K1;
  shifted_670X = arg0K2;
  if ((j_669X < 4)) {
    *((unsigned char *) ((((char *) (-3 + vm_string_664X))) + ((((i_666X)<<2)) + j_669X))) = (unsigned char) ((255 & shifted_670X));
    arg0K0 = (8 + bits_668X);
    arg0K1 = (1 + j_669X);
    arg0K2 = ((long)(((unsigned long)shifted_670X)>>8));
    goto L25649;}
  else {
    arg0K0 = (1 + i_666X);
    goto L25638;}}
}
void s48_copy_latin_1_to_string(char *string_671X, long vm_string_672X)
{
  long arg0K2;
  long arg0K1;
  long arg0K0;
  long shifted_679X;
  long j_678X;
  long bits_677X;
  long c_676X;
  long i_675X;
  long i_674X;
  long max_673X;
 {  if ((3 == (3 & vm_string_672X))) {
    if ((16 == (31 & ((((*((long *) ((((char *) (-3 + vm_string_672X))) + -4))))>>2))))) {
      goto L25672;}
    else {s48_raise_argument_type_error(vm_string_672X);
      goto L25672;}}
  else {s48_raise_argument_type_error(vm_string_672X);
    goto L25672;}}
 L25672: {
  max_673X = ((long)(((unsigned long)(*((long *) ((((char *) (-3 + vm_string_672X))) + -4))))>>8)) / 4;
  i_674X = strlen((char *) string_671X);
  if ((i_674X < 0)) {
    goto L25698;}
  else {
    if ((max_673X < i_674X)) {
      goto L25698;}
    else {
      goto L25678;}}}
 L25698: {
s48_raise_range_error((((i_674X)<<2)), 0, (((max_673X)<<2)));
  goto L25678;}
 L25678: {
  arg0K0 = 0;
  goto L25716;}
 L25716: {
  i_675X = arg0K0;
  if ((i_675X < (strlen((char *) string_671X)))) {
    c_676X = ((unsigned char) (*(string_671X + i_675X)));
    arg0K0 = 0;
    arg0K1 = 0;
    arg0K2 = c_676X;
    goto L25727;}
  else {
    return;}}
 L25727: {
  bits_677X = arg0K0;
  j_678X = arg0K1;
  shifted_679X = arg0K2;
  if ((j_678X < 4)) {
    *((unsigned char *) ((((char *) (-3 + vm_string_672X))) + ((((i_675X)<<2)) + j_678X))) = (unsigned char) ((255 & shifted_679X));
    arg0K0 = (8 + bits_677X);
    arg0K1 = (1 + j_678X);
    arg0K2 = ((long)(((unsigned long)shifted_679X)>>8));
    goto L25727;}
  else {
    arg0K0 = (1 + i_675X);
    goto L25716;}}
}
void s48_copy_string_to_latin_1(long vm_string_680X, char *string_681X)
{
  long v_682X;
 {  if ((3 == (3 & vm_string_680X))) {
    if ((16 == (31 & ((((*((long *) ((((char *) (-3 + vm_string_680X))) + -4))))>>2))))) {
      goto L25750;}
    else {s48_raise_argument_type_error(vm_string_680X);
      goto L25750;}}
  else {s48_raise_argument_type_error(vm_string_680X);
    goto L25750;}}
 L25750: {
  v_682X = ((long)(((unsigned long)(*((long *) ((((char *) (-3 + vm_string_680X))) + -4))))>>8)) / 4;
  copy_vm_string_to_stringUlatin_1B(vm_string_680X, 0, v_682X, string_681X);
  return;}
}
void s48_copy_string_to_latin_1_n(long vm_string_683X, long start_684X, long count_685X, char *string_686X)
{
  long max_690X;
  long v_689X;
  long max_688X;
  long v_687X;
 {  if ((3 == (3 & vm_string_683X))) {
    if ((16 == (31 & ((((*((long *) ((((char *) (-3 + vm_string_683X))) + -4))))>>2))))) {
      goto L25781;}
    else {s48_raise_argument_type_error(vm_string_683X);
      goto L25781;}}
  else {s48_raise_argument_type_error(vm_string_683X);
    goto L25781;}}
 L25781: {
  v_687X = ((long)(((unsigned long)(*((long *) ((((char *) (-3 + vm_string_683X))) + -4))))>>8)) / 4;
  max_688X = -1 + v_687X;
  if ((start_684X < 0)) {
    goto L25807;}
  else {
    if ((max_688X < start_684X)) {
      goto L25807;}
    else {
      goto L25783;}}}
 L25807: {
s48_raise_range_error((((start_684X)<<2)), 0, (((max_688X)<<2)));
  goto L25783;}
 L25783: {
  v_689X = ((long)(((unsigned long)(*((long *) ((((char *) (-3 + vm_string_683X))) + -4))))>>8)) / 4;
  max_690X = v_689X - start_684X;
  if ((count_685X < 0)) {
    goto L25824;}
  else {
    if ((max_690X < count_685X)) {
      goto L25824;}
    else {
      copy_vm_string_to_stringUlatin_1B(vm_string_683X, start_684X, count_685X, string_686X);
      return;}}}
 L25824: {
s48_raise_range_error((((count_685X)<<2)), 0, (((max_690X)<<2)));
  copy_vm_string_to_stringUlatin_1B(vm_string_683X, start_684X, count_685X, string_686X);
  return;}
}
long s48_string_utf_8_length(long vm_string_691X)
{
  long arg0K2;
  long arg0K1;
  long arg0K0;
  long count_701X;
  char v_700X;
  char v_699X;
  long x_698X;
  long scalar_value_697X;
  long j_696X;
  long bits_695X;
  long char_index_694X;
  long utf_8_length_693X;
  long count_692X;
 {  if ((3 == (3 & vm_string_691X))) {
    if ((16 == (31 & ((((*((long *) ((((char *) (-3 + vm_string_691X))) + -4))))>>2))))) {
      goto L25853;}
    else {s48_raise_argument_type_error(vm_string_691X);
      goto L25853;}}
  else {s48_raise_argument_type_error(vm_string_691X);
    goto L25853;}}
 L25853: {
  count_692X = ((long)(((unsigned long)(*((long *) ((((char *) (-3 + vm_string_691X))) + -4))))>>8)) / 4;
  arg0K0 = 0;
  arg0K1 = 0;
  goto L25880;}
 L25880: {
  utf_8_length_693X = arg0K0;
  char_index_694X = arg0K1;
  if ((char_index_694X < count_692X)) {
    arg0K0 = 0;
    arg0K1 = 0;
    arg0K2 = 0;
    goto L25889;}
  else {
    return utf_8_length_693X;}}
 L25889: {
  bits_695X = arg0K0;
  j_696X = arg0K1;
  scalar_value_697X = arg0K2;
  if ((j_696X < 4)) {
    PS_SHIFT_LEFT((*((unsigned char *) ((((char *) (-3 + vm_string_691X))) + ((((char_index_694X)<<2)) + j_696X)))), bits_695X, x_698X)
    arg0K0 = (8 + bits_695X);
    arg0K1 = (1 + j_696X);
    arg0K2 = (x_698X + scalar_value_697X);
    goto L25889;}
  else {encode_scalar_value(2, scalar_value_697X, (((char *) 0)), 0, &v_699X, &v_700X, &count_701X);
    arg0K0 = (utf_8_length_693X + count_701X);
    arg0K1 = (1 + char_index_694X);
    goto L25880;}}
}
long s48_string_utf_8_length_n(long vm_string_702X, long start_index_703X, long count_704X)
{
  long arg0K2;
  long arg0K1;
  long arg0K0;
  long count_717X;
  char v_716X;
  char v_715X;
  long x_714X;
  long scalar_value_713X;
  long j_712X;
  long bits_711X;
  long char_index_710X;
  long utf_8_length_709X;
  long max_708X;
  long v_707X;
  long max_706X;
  long v_705X;
 {  if ((3 == (3 & vm_string_702X))) {
    if ((16 == (31 & ((((*((long *) ((((char *) (-3 + vm_string_702X))) + -4))))>>2))))) {
      goto L25912;}
    else {s48_raise_argument_type_error(vm_string_702X);
      goto L25912;}}
  else {s48_raise_argument_type_error(vm_string_702X);
    goto L25912;}}
 L25912: {
  v_705X = ((long)(((unsigned long)(*((long *) ((((char *) (-3 + vm_string_702X))) + -4))))>>8)) / 4;
  max_706X = -1 + v_705X;
  if ((start_index_703X < 0)) {
    goto L25938;}
  else {
    if ((max_706X < start_index_703X)) {
      goto L25938;}
    else {
      goto L25914;}}}
 L25938: {
s48_raise_range_error((((start_index_703X)<<2)), 0, (((max_706X)<<2)));
  goto L25914;}
 L25914: {
  v_707X = ((long)(((unsigned long)(*((long *) ((((char *) (-3 + vm_string_702X))) + -4))))>>8)) / 4;
  max_708X = v_707X - start_index_703X;
  if ((count_704X < 0)) {
    goto L25955;}
  else {
    if ((max_708X < count_704X)) {
      goto L25955;}
    else {
      goto L25918;}}}
 L25955: {
s48_raise_range_error((((count_704X)<<2)), 0, (((max_708X)<<2)));
  goto L25918;}
 L25918: {
  arg0K0 = 0;
  arg0K1 = 0;
  goto L25974;}
 L25974: {
  utf_8_length_709X = arg0K0;
  char_index_710X = arg0K1;
  if ((char_index_710X < count_704X)) {
    arg0K0 = 0;
    arg0K1 = 0;
    arg0K2 = 0;
    goto L25983;}
  else {
    return utf_8_length_709X;}}
 L25983: {
  bits_711X = arg0K0;
  j_712X = arg0K1;
  scalar_value_713X = arg0K2;
  if ((j_712X < 4)) {
    PS_SHIFT_LEFT((*((unsigned char *) ((((char *) (-3 + vm_string_702X))) + (((((start_index_703X + char_index_710X))<<2)) + j_712X)))), bits_711X, x_714X)
    arg0K0 = (8 + bits_711X);
    arg0K1 = (1 + j_712X);
    arg0K2 = (x_714X + scalar_value_713X);
    goto L25983;}
  else {encode_scalar_value(2, scalar_value_713X, (((char *) 0)), 0, &v_715X, &v_716X, &count_717X);
    arg0K0 = (utf_8_length_709X + count_717X);
    arg0K1 = (1 + char_index_710X);
    goto L25974;}}
}
void s48_copy_string_to_utf_8(long vm_string_718X, char * string_719X)
{
  long arg0K2;
  long arg0K1;
  long arg0K0;
  long count_729X;
  char v_728X;
  char v_727X;
  long x_726X;
  long scalar_value_725X;
  long j_724X;
  long bits_723X;
  long target_index_722X;
  long source_index_721X;
  long count_720X;
 {  if ((3 == (3 & vm_string_718X))) {
    if ((16 == (31 & ((((*((long *) ((((char *) (-3 + vm_string_718X))) + -4))))>>2))))) {
      goto L26013;}
    else {s48_raise_argument_type_error(vm_string_718X);
      goto L26013;}}
  else {s48_raise_argument_type_error(vm_string_718X);
    goto L26013;}}
 L26013: {
  count_720X = ((long)(((unsigned long)(*((long *) ((((char *) (-3 + vm_string_718X))) + -4))))>>8)) / 4;
  arg0K0 = 0;
  arg0K1 = 0;
  goto L26041;}
 L26041: {
  source_index_721X = arg0K0;
  target_index_722X = arg0K1;
  if ((source_index_721X < count_720X)) {
    arg0K0 = 0;
    arg0K1 = 0;
    arg0K2 = 0;
    goto L26050;}
  else {
    return;}}
 L26050: {
  bits_723X = arg0K0;
  j_724X = arg0K1;
  scalar_value_725X = arg0K2;
  if ((j_724X < 4)) {
    PS_SHIFT_LEFT((*((unsigned char *) ((((char *) (-3 + vm_string_718X))) + ((((source_index_721X)<<2)) + j_724X)))), bits_723X, x_726X)
    arg0K0 = (8 + bits_723X);
    arg0K1 = (1 + j_724X);
    arg0K2 = (x_726X + scalar_value_725X);
    goto L26050;}
  else {encode_scalar_value(2, scalar_value_725X, (string_719X + target_index_722X), 4, &v_727X, &v_728X, &count_729X);
    arg0K0 = (1 + source_index_721X);
    arg0K1 = (target_index_722X + count_729X);
    goto L26041;}}
}
void s48_copy_string_to_utf_8_n(long vm_string_730X, long start_731X, long count_732X, char * string_733X)
{
  long arg0K2;
  long arg0K1;
  long arg0K0;
  long count_746X;
  char v_745X;
  char v_744X;
  long x_743X;
  long scalar_value_742X;
  long j_741X;
  long bits_740X;
  long target_index_739X;
  long source_index_738X;
  long max_737X;
  long v_736X;
  long max_735X;
  long v_734X;
 {  if ((3 == (3 & vm_string_730X))) {
    if ((16 == (31 & ((((*((long *) ((((char *) (-3 + vm_string_730X))) + -4))))>>2))))) {
      goto L26074;}
    else {s48_raise_argument_type_error(vm_string_730X);
      goto L26074;}}
  else {s48_raise_argument_type_error(vm_string_730X);
    goto L26074;}}
 L26074: {
  v_734X = ((long)(((unsigned long)(*((long *) ((((char *) (-3 + vm_string_730X))) + -4))))>>8)) / 4;
  max_735X = -1 + v_734X;
  if ((start_731X < 0)) {
    goto L26100;}
  else {
    if ((max_735X < start_731X)) {
      goto L26100;}
    else {
      goto L26076;}}}
 L26100: {
s48_raise_range_error((((start_731X)<<2)), 0, (((max_735X)<<2)));
  goto L26076;}
 L26076: {
  v_736X = ((long)(((unsigned long)(*((long *) ((((char *) (-3 + vm_string_730X))) + -4))))>>8)) / 4;
  max_737X = v_736X - start_731X;
  if ((count_732X < 0)) {
    goto L26117;}
  else {
    if ((max_737X < count_732X)) {
      goto L26117;}
    else {
      goto L26080;}}}
 L26117: {
s48_raise_range_error((((count_732X)<<2)), 0, (((max_737X)<<2)));
  goto L26080;}
 L26080: {
  arg0K0 = 0;
  arg0K1 = 0;
  goto L26137;}
 L26137: {
  source_index_738X = arg0K0;
  target_index_739X = arg0K1;
  if ((source_index_738X < count_732X)) {
    arg0K0 = 0;
    arg0K1 = 0;
    arg0K2 = 0;
    goto L26146;}
  else {
    return;}}
 L26146: {
  bits_740X = arg0K0;
  j_741X = arg0K1;
  scalar_value_742X = arg0K2;
  if ((j_741X < 4)) {
    PS_SHIFT_LEFT((*((unsigned char *) ((((char *) (-3 + vm_string_730X))) + (((((start_731X + source_index_738X))<<2)) + j_741X)))), bits_740X, x_743X)
    arg0K0 = (8 + bits_740X);
    arg0K1 = (1 + j_741X);
    arg0K2 = (x_743X + scalar_value_742X);
    goto L26146;}
  else {encode_scalar_value(2, scalar_value_742X, (string_733X + target_index_739X), 4, &v_744X, &v_745X, &count_746X);
    arg0K0 = (1 + source_index_738X);
    arg0K1 = (target_index_739X + count_746X);
    goto L26137;}}
}
void check_stack(void)
{
  char * arg3K0;
  char * arg3K1;
  long arg0K0;
  long v_769X;
  char x_768X;
  long x_767X;
  char * ptr_766X;
  long mask_765X;
  long size_764X;
  char * pointer_763X;
  char x_762X;
  long x_761X;
  char * addr_760X;
  char * trace_ptr_759X;
  char * mask_ptr_758X;
  long v_757X;
  char * mask_pointer_756X;
  long size_755X;
  char * pointer_754X;
  char * contents_pointer_753X;
  long mask_size_752X;
  char * code_pointer_751X;
  char * cont_750X;
  char x_749X;
  long x_748X;
  char * index_747X;
 {  arg3K0 = (SstackS);
  goto L26262;}
 L26262: {
  index_747X = arg3K0;
  if ((index_747X < ((SstackS) + (-4 & ((ScontS) - (SstackS)))))) {
    x_748X = *((long *) index_747X);
    if ((2 == (3 & x_748X))) {
      goto L26324;}
    else {
      if ((3 == (3 & x_748X))) {
        x_749X = s48_stob_in_heapP(x_748X);
        if (x_749X) {
          goto L26271;}
        else {
          goto L26324;}}
      else {
        goto L26271;}}}
  else {
    arg3K0 = (ScontS);
    goto L26366;}}
 L26324: {
  ps_write_string("bad descriptor in stack", (stderr));
  ps_write_integer(x_748X, (stderr));
  ps_write_integer((*((long *) (((char *) 0)))), (stderr));
  goto L26271;}
 L26271: {
  arg3K0 = (index_747X + 4);
  goto L26262;}
 L26366: {
  cont_750X = arg3K0;
  if ((cont_750X == (Sbottom_of_stackS))) {
    return;}
  else {
    code_pointer_751X = ((char *) (*((long *) cont_750X)));
    mask_size_752X = *((unsigned char *) (code_pointer_751X + -3));
    contents_pointer_753X = cont_750X + 4;
    if ((0 == mask_size_752X)) {
      pointer_754X = (((char *) (*((long *) cont_750X)))) + -2;
      size_755X = ((((*((unsigned char *) pointer_754X)))<<8)) + (*((unsigned char *) (pointer_754X + 1)));
      if ((65535 == size_755X)) {
        arg0K0 = ((((*((long *) (cont_750X + 4))))>>2));
        goto L19835;}
      else {
        arg0K0 = size_755X;
        goto L19835;}}
    else {
      mask_pointer_756X = code_pointer_751X + -7;
      arg3K0 = (mask_pointer_756X + (0 - mask_size_752X));
      arg3K1 = contents_pointer_753X;
      goto L8874;}}}
 L19835: {
  v_757X = arg0K0;
  arg3K0 = contents_pointer_753X;
  goto L8815;}
 L8874: {
  mask_ptr_758X = arg3K0;
  trace_ptr_759X = arg3K1;
  if ((mask_ptr_758X == mask_pointer_756X)) {
    goto L22571;}
  else {
    arg0K0 = (*((unsigned char *) mask_ptr_758X));
    arg3K1 = trace_ptr_759X;
    goto L8882;}}
 L8815: {
  addr_760X = arg3K0;
  if ((addr_760X < (cont_750X + (4 + (((v_757X)<<2)))))) {
    x_761X = *((long *) addr_760X);
    if ((2 == (3 & x_761X))) {
      goto L8833;}
    else {
      if ((3 == (3 & x_761X))) {
        x_762X = s48_stob_in_heapP(x_761X);
        if (x_762X) {
          goto L8820;}
        else {
          goto L8833;}}
      else {
        goto L8820;}}}
  else {
    goto L22571;}}
 L22571: {
  pointer_763X = (((char *) (*((long *) cont_750X)))) + -2;
  size_764X = ((((*((unsigned char *) pointer_763X)))<<8)) + (*((unsigned char *) (pointer_763X + 1)));
  if ((65535 == size_764X)) {
    arg0K0 = ((((*((long *) (cont_750X + 4))))>>2));
    goto L22576;}
  else {
    arg0K0 = size_764X;
    goto L22576;}}
 L8882: {
  mask_765X = arg0K0;
  ptr_766X = arg3K1;
  if ((0 == mask_765X)) {
    arg3K0 = (mask_ptr_758X + 1);
    arg3K1 = (trace_ptr_759X + 32);
    goto L8874;}
  else {
    if ((1 == (1 & mask_765X))) {
      x_767X = *((long *) ptr_766X);
      if ((2 == (3 & x_767X))) {
        goto L8939;}
      else {
        if ((3 == (3 & x_767X))) {
          x_768X = s48_stob_in_heapP(x_767X);
          if (x_768X) {
            goto L8898;}
          else {
            goto L8939;}}
        else {
          goto L8898;}}}
    else {
      goto L8898;}}}
 L8833: {
  ps_write_string("bad descriptor in stack", (stderr));
  ps_write_integer(x_761X, (stderr));
  ps_write_integer((*((long *) (((char *) 0)))), (stderr));
  goto L8820;}
 L8820: {
  arg3K0 = (addr_760X + 4);
  goto L8815;}
 L22576: {
  v_769X = arg0K0;
  arg3K0 = (cont_750X + (4 + (((v_769X)<<2))));
  goto L26366;}
 L8939: {
  ps_write_string("bad descriptor in stack", (stderr));
  ps_write_integer(x_767X, (stderr));
  ps_write_integer((*((long *) (((char *) 0)))), (stderr));
  goto L8898;}
 L8898: {
  arg0K0 = (((mask_765X)>>1));
  arg3K1 = (ptr_766X + 4);
  goto L8882;}
}
long s48_really_add_channel(long mode_770X, long id_771X, long os_index_772X)
{
  long arg0K1;
  long arg0K0;
  long status_777X;
  long channel_776X;
  long channel_775X;
  char x_774X;
  char temp_773X;
 {s48_make_availableAgc(32);
  temp_773X = os_index_772X < (Snumber_of_channelsS);
  if (temp_773X) {
    goto L26659;}
  else {
    x_774X = add_more_channels(os_index_772X);
    if (x_774X) {
      goto L26659;}
    else {
      arg0K0 = 1;
      arg0K1 = 9;
      goto L26633;}}}
 L26659: {
  if ((1 == (*((Svm_channelsS) + os_index_772X)))) {
    channel_775X = make_channel((-4 & mode_770X), id_771X, (((os_index_772X)<<2)), 1, 1, 1, 1, 0);
    *((Svm_channelsS) + os_index_772X) = channel_775X;
    arg0K0 = channel_775X;
    arg0K1 = 9;
    goto L26633;}
  else {
    arg0K0 = 1;
    arg0K1 = 11;
    goto L26633;}}
 L26633: {
  channel_776X = arg0K0;
  status_777X = arg0K1;
  if ((3 == (3 & channel_776X))) {
    if ((6 == (31 & ((((*((long *) ((((char *) (-3 + channel_776X))) + -4))))>>2))))) {
      return channel_776X;}
    else {
      goto L26641;}}
  else {
    goto L26641;}}
 L26641: {
  return (((status_777X)<<2));}
}
long s48_integer_bit_count(long x_778X)
{

 {  return integer_bit_count(x_778X);}
}
long s48_enter_integer(long x_779X)
{
  char * v_780X;
 {s48_make_availableAgc(16);
  if ((536870911 < x_779X)) {
    goto L27266;}
  else {
    if ((x_779X < -536870912)) {
      goto L27266;}
    else {
      return (((x_779X)<<2));}}}
 L27266: {
  v_780X = (char *) s48_long_to_bignum(x_779X);
  return enter_bignum(v_780X);}
}
long s48_enter_unsigned_integer(unsigned long x_781X)
{
  char * v_782X;
 {s48_make_availableAgc(16);
  if (((((unsigned long) 536870911)) < x_781X)) {
    v_782X = (char *) s48_ulong_to_bignum(x_781X);
    return enter_bignum(v_782X);}
  else {
    return ((((((long) x_781X)))<<2));}}
}
long s48_integer_or_floanum_add(long x_783X, long y_784X)
{
  long Kdouble_790X;
  char * addr_789X;
  double y_788X;
  long value_787X;
  double x_786X;
  long value_785X;
 {  if ((3 == (3 & x_783X))) {
    if ((18 == (31 & ((((*((long *) ((((char *) (-3 + x_783X))) + -4))))>>2))))) {
      Stemp0S = x_783X;
      Stemp1S = y_784X;s48_make_availableAgc(12);
      value_785X = Stemp0S;
      Stemp0S = 1;
      x_786X = *((double *) (((char *) (-3 + value_785X))));
      value_787X = Stemp1S;
      Stemp1S = 1;
      y_788X = *((double *) (((char *) (-3 + value_787X))));
      addr_789X = s48_allocate_small(12);
      *((long *) addr_789X) = (long) (2122);
      Kdouble_790X = 3 + (((long) (addr_789X + 4)));
      *((double *) (((char *) (-3 + Kdouble_790X)))) = (double) ((x_786X + y_788X));
      return Kdouble_790X;}
    else {
      return integer_add(x_783X, y_784X);}}
  else {
    return integer_add(x_783X, y_784X);}}
}
long s48_integer_or_floanum_sub(long x_791X, long y_792X)
{
  long Kdouble_798X;
  char * addr_797X;
  double y_796X;
  long value_795X;
  double x_794X;
  long value_793X;
 {  if ((3 == (3 & x_791X))) {
    if ((18 == (31 & ((((*((long *) ((((char *) (-3 + x_791X))) + -4))))>>2))))) {
      Stemp0S = x_791X;
      Stemp1S = y_792X;s48_make_availableAgc(12);
      value_793X = Stemp0S;
      Stemp0S = 1;
      x_794X = *((double *) (((char *) (-3 + value_793X))));
      value_795X = Stemp1S;
      Stemp1S = 1;
      y_796X = *((double *) (((char *) (-3 + value_795X))));
      addr_797X = s48_allocate_small(12);
      *((long *) addr_797X) = (long) (2122);
      Kdouble_798X = 3 + (((long) (addr_797X + 4)));
      *((double *) (((char *) (-3 + Kdouble_798X)))) = (double) ((x_794X - y_796X));
      return Kdouble_798X;}
    else {
      return integer_subtract(x_791X, y_792X);}}
  else {
    return integer_subtract(x_791X, y_792X);}}
}
long s48_integer_or_floanum_mul(long x_799X, long y_800X)
{
  long Kdouble_806X;
  char * addr_805X;
  double y_804X;
  long value_803X;
  double x_802X;
  long value_801X;
 {  if ((3 == (3 & x_799X))) {
    if ((18 == (31 & ((((*((long *) ((((char *) (-3 + x_799X))) + -4))))>>2))))) {
      Stemp0S = x_799X;
      Stemp1S = y_800X;s48_make_availableAgc(12);
      value_801X = Stemp0S;
      Stemp0S = 1;
      x_802X = *((double *) (((char *) (-3 + value_801X))));
      value_803X = Stemp1S;
      Stemp1S = 1;
      y_804X = *((double *) (((char *) (-3 + value_803X))));
      addr_805X = s48_allocate_small(12);
      *((long *) addr_805X) = (long) (2122);
      Kdouble_806X = 3 + (((long) (addr_805X + 4)));
      *((double *) (((char *) (-3 + Kdouble_806X)))) = (double) ((x_802X * y_804X));
      return Kdouble_806X;}
    else {
      return integer_multiply(x_799X, y_800X);}}
  else {
    return integer_multiply(x_799X, y_800X);}}
}
long s48_integer_bitwise_not(long x_807X)
{

 {  return integer_bitwise_not(x_807X);}
}
long s48_integer_bitwise_and(long x_808X, long y_809X)
{

 {  return integer_bitwise_and(x_808X, y_809X);}
}
long s48_integer_bitwise_ior(long x_810X, long y_811X)
{

 {  return integer_bitwise_ior(x_810X, y_811X);}
}
long s48_integer_bitwise_xor(long x_812X, long y_813X)
{

 {  return integer_bitwise_xor(x_812X, y_813X);}
}
void s48_setup_external_exception(long why_814X, long nargs_815X)
{

 {push_exception_setupB(why_814X, 1);
  if ((10 < nargs_815X)) {
    ps_error("too many arguments from external exception", 0);
    goto L28329;}
  else {
    goto L28329;}}
 L28329: {
  Sexternal_exception_nargsS = nargs_815X;
  Sexternal_exceptionPS = 1;
  return;}
}
long s48_integer_quotient(long x_816X, long y_817X)
{

 {  return Hinteger_op8281(x_816X, y_817X);}
}
long s48_integer_remainder(long x_818X, long y_819X)
{

 {  return Hinteger_op8212(x_818X, y_819X);}
}
void s48_copy_stack_into_heap(void)
{
  char * arg3K1;
  char * arg3K0;
  char * arg_823X;
  char * loc_822X;
  char * top_821X;
  long arg_count_820X;
 {s48_make_availableAgc(((((-4 & ((Sstack_endS) - (SstackS))))<<2)));
  arg_count_820X = ((((ScontS) - (SstackS)))>>2);
  top_821X = SstackS;
  if ((1 == (((long) (ScontS))))) {
    goto L28379;}
  else {really_preserve_continuation(0);
    goto L28379;}}
 L28379: {
  SstackS = (ScontS);
  arg3K0 = ((SstackS) + -4);
  arg3K1 = (top_821X + (-4 + (((arg_count_820X)<<2))));
  goto L28408;}
 L28408: {
  loc_822X = arg3K0;
  arg_823X = arg3K1;
  if ((arg_823X < top_821X)) {
    SstackS = ((SstackS) + (0 - (((arg_count_820X)<<2))));
    return;}
  else {
    *((long *) loc_822X) = (long) ((*((long *) arg_823X)));
    arg3K0 = (loc_822X + -4);
    arg3K1 = (arg_823X + -4);
    goto L28408;}}
}
long s48_get_imported_binding(char *name_824X)
{
  long value_826X;
  long value_825X;
 {  value_825X = enter_stringAgc_n(name_824X, (strlen((char *) name_824X)));
  Stemp0S = value_825X;s48_make_availableAgc(20);
  value_826X = Stemp0S;
  Stemp0S = 1;
  return Hlookup833((Sexported_bindingsS), value_826X, 0);}
}
void s48_define_exported_binding(char *name_827X, long value_828X)
{
  char * addr_833X;
  long x_832X;
  long value_831X;
  long value_830X;
  long name_829X;
 {  Stemp0S = value_828X;
  name_829X = enter_stringAgc_n(name_827X, (strlen((char *) name_827X)));
  Stemp1S = name_829X;s48_make_availableAgc(20);
  value_830X = Stemp1S;
  Stemp1S = 1;
  value_831X = Stemp0S;
  Stemp0S = 1;
  x_832X = Hlookup814((Simported_bindingsS), value_830X, 0);
  addr_833X = (((char *) (-3 + x_832X))) + 8;S48_WRITE_BARRIER(x_832X, addr_833X, value_831X);
  *((long *) addr_833X) = (long) (value_831X);
  return;}
}
void s48_initialize_vm(char * stack_begin_834X, long stack_size_835X)
{
  char * arg3K0;
  long arg0K1;
  long arg0K0;

  int make_hash_tableAgc_return_tag;
  long make_hash_tableAgc0_return_value;
  char * addr_877X;
  long i_876X;
  long table_875X;
  long vector_874X;
  char * addr_873X;
  char * addr_872X;
  long x_871X;
  long v_870X;
  long vector_869X;
  char * addr_868X;
  long blank_return_code_867X;
  long blank_return_code_866X;
  long blank_return_code_865X;
  long blank_return_code_864X;
  long blank_return_code_863X;
  long blank_return_code_862X;
  long blank_return_code_861X;
  char * a_860X;
  long size_859X;
  char * start_858X;
  char * stack_857X;
  char x_856X;
  long event_types_count_855X;
  char * addr_854X;
  long value_853X;
  char * addr_852X;
  long val_851X;
  long index_850X;
  long v_849X;
  long foo_848X;
  long table_847X;
  long i_846X;
  long v_845X;
  long v_844X;
  long exported_bindings_843X;
  long imported_bindings_842X;
  long n_841X;
  long symbols_840X;
  long maybe_839X;
  long maybe_838X;
  long v_837X;
  long symbol_table_836X;
 {  symbol_table_836X = s48_initial_symbols();
  if ((symbol_table_836X == 1)) {
    make_hash_tableAgc_return_tag = 0;
    goto make_hash_tableAgc;
   make_hash_tableAgc_return_0:
    v_837X = make_hash_tableAgc0_return_value;
    Sthe_symbol_tableS = v_837X;
    maybe_838X = s48_find_all(1);
    if ((maybe_838X == 1)) {s48_collect(1);
      maybe_839X = s48_find_all(1);
      if ((maybe_839X == 1)) {
        ps_error("insufficient heap space to build symbol table", 0);
        arg0K0 = maybe_839X;
        goto L28516;}
      else {
        arg0K0 = maybe_839X;
        goto L28516;}}
    else {
      arg0K0 = maybe_838X;
      goto L28516;}}
  else {
    Sthe_symbol_tableS = symbol_table_836X;
    goto L29233;}}
 L28516: {
  symbols_840X = arg0K0;
  n_841X = (((3 + ((long)(((unsigned long)(*((long *) ((((char *) (-3 + symbols_840X))) + -4))))>>8))))>>2);
  arg0K0 = 0;
  goto L28537;}
 L29233: {
  imported_bindings_842X = s48_initial_imported_bindings();
  exported_bindings_843X = s48_initial_exported_bindings();
  if ((1 == imported_bindings_842X)) {
    make_hash_tableAgc_return_tag = 1;
    goto make_hash_tableAgc;
   make_hash_tableAgc_return_1:
    v_844X = make_hash_tableAgc0_return_value;
    Simported_bindingsS = v_844X;
    make_hash_tableAgc_return_tag = 2;
    goto make_hash_tableAgc;
   make_hash_tableAgc_return_2:
    v_845X = make_hash_tableAgc0_return_value;
    Sexported_bindingsS = v_845X;
    goto L29239;}
  else {
    Simported_bindingsS = imported_bindings_842X;
    Sexported_bindingsS = exported_bindings_843X;
    goto L29239;}}
 L28537: {
  i_846X = arg0K0;
  if ((i_846X == n_841X)) {
    goto L29233;}
  else {
    table_847X = Sthe_symbol_tableS;
    foo_848X = *((long *) ((((char *) (-3 + symbols_840X))) + (((i_846X)<<2))));
    v_849X = Haction4880((*((long *) (((char *) (-3 + foo_848X))))));
    index_850X = 1023 & v_849X;
    val_851X = *((long *) ((((char *) (-3 + table_847X))) + (((index_850X)<<2))));
    addr_852X = (((char *) (-3 + foo_848X))) + 4;S48_WRITE_BARRIER(foo_848X, addr_852X, val_851X);
    *((long *) addr_852X) = (long) (val_851X);
    if ((3 == (3 & foo_848X))) {
      arg0K0 = (-4 & foo_848X);
      goto L27851;}
    else {
      arg0K0 = foo_848X;
      goto L27851;}}}
 L29239: {
  Sevent_typesS = ((struct event_type**)malloc(sizeof(struct event_type*) * (Snumber_of_event_typesS)));
  if ((NULL == (Sevent_typesS))) {
    ps_error("out of memory, unable to continue", 0);
    goto L29273;}
  else {
    goto L29273;}}
 L27851: {
  value_853X = arg0K0;
  addr_854X = (((char *) (-3 + table_847X))) + (((index_850X)<<2));S48_WRITE_BARRIER(table_847X, addr_854X, value_853X);
  *((long *) addr_854X) = (long) (value_853X);
  arg0K0 = (1 + i_846X);
  goto L28537;}
 L29273: {
  event_types_count_855X = Snumber_of_event_typesS;
  Snumber_of_event_typesS = 0;
  Sunused_event_types_headS = (NULL);
  x_856X = add_external_event_types(event_types_count_855X);
  if (x_856X) {
    goto L29280;}
  else {
    ps_error("out of memory, unable to continue", 0);
    goto L29280;}}
 L29280: {
  Spending_event_types_headS = (NULL);
  Spending_event_types_tailS = (NULL);
  Spending_event_types_readyS = (NULL);
  if ((stack_size_835X < 8128)) {
    stack_857X = (char *)malloc(32512);
    if ((stack_857X == NULL)) {
      ps_error("out of memory, unable to continue", 0);
      arg3K0 = stack_857X;
      arg0K1 = 8128;
      goto L23256;}
    else {
      arg3K0 = stack_857X;
      arg0K1 = 8128;
      goto L23256;}}
  else {
    arg3K0 = stack_begin_834X;
    arg0K1 = stack_size_835X;
    goto L23256;}}
 L23256: {
  start_858X = arg3K0;
  size_859X = arg0K1;
  Sstack_beginS = start_858X;
  Sstack_endS = (start_858X + (((size_859X)<<2)));
  Sreal_stack_limitS = ((Sstack_beginS) + 512);
  s48_Sstack_limitS = (Sreal_stack_limitS);
  SstackS = (Sstack_endS);
  ScontS = (((char *) 1));
  arg3K0 = start_858X;
  goto L23286;}
 L23286: {
  a_860X = arg3K0;
  if ((a_860X == (Sstack_endS))) {s48_make_availableAgc(20);
    blank_return_code_861X = make_blank_return_code(71, 65535, 0, 1, 0);
    *((unsigned char *) ((((char *) (-3 + blank_return_code_861X))) + 15)) = (unsigned char) (0);
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) (1);
    ScontS = (SstackS);
    *((long *) (ScontS)) = (long) ((((long) ((((char *) (-3 + blank_return_code_861X))) + 13))));
    Sbottom_of_stackS = (ScontS);
    Sheap_continuationS = 1;s48_make_availableAgc(120);
    blank_return_code_862X = make_blank_return_code(66, 65535, 65535, 1, 0);
    *((unsigned char *) ((((char *) (-3 + blank_return_code_862X))) + 15)) = (unsigned char) (164);
    Sinterrupted_byte_opcode_return_codeS = blank_return_code_862X;
    blank_return_code_863X = make_blank_return_code(66, 65535, 65535, 1, 0);
    *((unsigned char *) ((((char *) (-3 + blank_return_code_863X))) + 15)) = (unsigned char) (165);
    Sinterrupted_native_call_return_codeS = blank_return_code_863X;
    blank_return_code_864X = make_blank_return_code(66, 65535, 65535, 1, 0);
    *((unsigned char *) ((((char *) (-3 + blank_return_code_864X))) + 15)) = (unsigned char) (166);
    Snative_poll_return_codeS = blank_return_code_864X;
    blank_return_code_865X = make_blank_return_code(1, 65535, 65535, 1, 0);
    *((unsigned char *) ((((char *) (-3 + blank_return_code_865X))) + 15)) = (unsigned char) (160);
    Sexception_return_codeS = blank_return_code_865X;
    blank_return_code_866X = make_blank_return_code(1, 65535, 65535, 1, 0);
    *((unsigned char *) ((((char *) (-3 + blank_return_code_866X))) + 15)) = (unsigned char) (161);
    Snative_exception_return_codeS = blank_return_code_866X;
    blank_return_code_867X = make_blank_return_code(70, 65535, 1, 1, 0);
    *((unsigned char *) ((((char *) (-3 + blank_return_code_867X))) + 15)) = (unsigned char) (0);
    Scall_with_values_return_codeS = blank_return_code_867X;s48_make_availableAgc(32);s48_bignum_make_cached_constants();
    addr_868X = s48_allocate_tracedAgc(8);
    if ((addr_868X == NULL)) {
      arg0K0 = 1;
      goto L29318;}
    else {
      *((long *) addr_868X) = (long) (1034);
      arg0K0 = (3 + (((long) (addr_868X + 4))));
      goto L29318;}}
  else {
    *((long *) a_860X) = (long) (252645135);
    arg3K0 = (a_860X + 4);
    goto L23286;}}
 L29318: {
  vector_869X = arg0K0;
  if ((1 == vector_869X)) {
    ps_error("Out of space, unable to allocate", 0);
    arg0K0 = vector_869X;
    goto L29305;}
  else {
    arg0K0 = vector_869X;
    goto L29305;}}
 L29305: {
  v_870X = arg0K0;
  Sempty_logS = v_870X;
  x_871X = Sempty_logS;
  addr_872X = ((char *) (-3 + x_871X));S48_WRITE_BARRIER(x_871X, addr_872X, 1);
  *((long *) addr_872X) = (long) (1);
  return;}
 make_hash_tableAgc: {
{ addr_873X = s48_allocate_tracedAgc(4100);
  if ((addr_873X == NULL)) {
    arg0K0 = 1;
    goto L13678;}
  else {
    *((long *) addr_873X) = (long) (1048586);
    arg0K0 = (3 + (((long) (addr_873X + 4))));
    goto L13678;}}
 L13678: {
  vector_874X = arg0K0;
  if ((1 == vector_874X)) {
    ps_error("Out of space, unable to allocate", 0);
    arg0K0 = vector_874X;
    goto L13666;}
  else {
    arg0K0 = vector_874X;
    goto L13666;}}
 L13666: {
  table_875X = arg0K0;
  arg0K0 = 0;
  goto L13701;}
 L13701: {
  i_876X = arg0K0;
  if ((1024 == i_876X)) {
    make_hash_tableAgc0_return_value = table_875X;
    goto make_hash_tableAgc_return;}
  else {
    addr_877X = (((char *) (-3 + table_875X))) + (((i_876X)<<2));S48_WRITE_BARRIER(table_875X, addr_877X, 1);
    *((long *) addr_877X) = (long) (1);
    arg0K0 = (1 + i_876X);
    goto L13701;}}
 make_hash_tableAgc_return:
  switch (make_hash_tableAgc_return_tag) {
  case 0: goto make_hash_tableAgc_return_0;
  case 1: goto make_hash_tableAgc_return_1;
  default: goto make_hash_tableAgc_return_2;
  }}

}
void s48_post_gc_cleanup(char majorP_878X, char in_troubleP_879X)
{

 {  (Spost_gc_cleanupS)(majorP_878X, in_troubleP_879X);
  return;}
}
void s48_gc_root(void)
{

 {  (Sgc_root_procS)();
  return;}
}
long s48_restart(long proc_880X, long nargs_881X)
{
  char *arg5K0;
  char * arg3K1;
  char * arg3K0;
  char arg4K3;
  char arg4K1;
  char arg4K0;
  char arg4K2;
  long arg0K4;
  long arg0K3;
  long arg0K2;
  long arg0K1;
  long arg0K0;
  char *merged_arg5K0;
  FILE * merged_arg6K2;
  char merged_arg4K1;
  char * merged_arg3K0;
  long merged_arg0K3;
  long merged_arg0K2;
  long merged_arg0K1;
  long merged_arg0K0;

  int move_args_above_contB_return_tag;
  int s48_pop_interrupt_state_return_tag;
  int get_error_string_return_tag;
  long get_error_string0_return_value;
  int copy_continuation_from_heapB_return_tag;
  char * copy_continuation_from_heapB0_return_value;
  int okay_argument_list_return_tag;
  char okay_argument_list0_return_value;
  long okay_argument_list1_return_value;
  int get_current_port_return_tag;
  long get_current_port0_return_value;
  int make_closure_return_tag;
  long make_closure0_return_value;
  int pending_interruptP_return_tag;
  char pending_interruptP0_return_value;
  int proposal_d_read_return_tag;
  long proposal_d_read0_return_value;
  int proposal_d_write_return_tag;
  int shift_space_return_tag;
  long shift_space0_return_value;
  int pop_continuationB_return_tag;
  int copy_listSAgc_return_tag;
  long copy_listSAgc0_return_value;
  int pop_args_GlistSAgc_return_tag;
  long pop_args_GlistSAgc0_return_value;
  int ensure_stack_spaceB_return_tag;
  char ensure_stack_spaceB0_return_value;
  int push_list_return_tag;
  long push_list0_return_value;
  int rest_list_setupAgc_return_tag;
  int find_template_return_tag;
  long find_template0_return_value;
  int maybe_write_template_return_tag;
  char maybe_write_template0_return_value;
  int loseD0_return_tag;
  long nargs_882X;
  long status_883X;
  long cont_884X;
  long stack_arg_count_885X;
  long list_886X;
  long marker_887X;
  long a_888X;
  long b_889X;
  long stob_890X;
  long index_891X;
  long stob_892X;
  long index_893X;
  long value_894X;
  long x_895X;
  long n_896X;
  long list_897X;
  long length_898X;
  long start_899X;
  long count_900X;
  long need_901X;
  long list_902X;
  long count_903X;
  long wants_stack_args_904X;
  long stack_arg_count_905X;
  long list_args_906X;
  long list_arg_count_907X;
  char * start_908X;
  long count_909X;
  long code_vector_910X;
  long template_911X;
  char not_firstP_912X;
  FILE * out_913X;
  char *message_914X;
  char * arg_2436X;
  char * loc_2435X;
  char * top_of_args_2434X;
  char * addr_2433X;
  long x_2432X;
  long proposal_2431X;
  long p_2430X;
  long shifted_2429X;
  long j_2428X;
  long bits_2427X;
  long c_2426X;
  long i_2425X;
  long new_2424X;
  char * addr_2423X;
  long len_2422X;
  long len_2421X;
  long x_2420X;
  char *string_2419X;
  char * new_stack_2418X;
  char * new_cont_2417X;
  long stack_size_2416X;
  char move_slowP_2415X;
  long slow_2414X;
  long len_2413X;
  long fast_2412X;
  char *v_2411X;
  long v_2410X;
  long obj_2409X;
  long env_2408X;
  long thread_2407X;
  long x_2406X;
  char * addr_2405X;
  long interrupt_bit_2404X;
  long status_2403X;
  long channel_2402X;
  long type_2401X;
  long v_2400X;
  long next_stob_2399X;
  long i_2398X;
  long log_2397X;
  char * addr_2396X;
  long next_stob_2395X;
  long i_2394X;
  long log_2393X;
  long v_2392X;
  long v_2391X;
  long n_2390X;
  long extra_2389X;
  long x_size_2388X;
  long v_2387X;
  long v_2386X;
  long size_2385X;
  char * pointer_2384X;
  char * cont_2383X;
  char * addr_2382X;
  long x_2381X;
  char * addr_2380X;
  long a_2379X;
  long last_2378X;
  long l_2377X;
  long x_2376X;
  char * addr_2375X;
  long a_2374X;
  long value_2373X;
  long x_2372X;
  char * addr_2371X;
  long a_2370X;
  long count_2369X;
  long args_2368X;
  long value_2367X;
  char interruptP_2366X;
  long x_2365X;
  long l_2364X;
  long i_2363X;
  long list_2362X;
  char v_2361X;
  long x_2360X;
  long v_2359X;
  long x_2358X;
  long v_2357X;
  long count_2356X;
  long x_2355X;
  long next_2354X;
  long i_2353X;
  long obj_2352X;
  long obj_2351X;
  long name_2350X;
  long v_2349X;
  long why_2348X;
  long size_2347X;
  char * pointer_2346X;
  char v_2345X;
  long v_2344X;
  long v_2343X;
  char v_2342X;
  long v_2341X;
  char not_firstP_2340X;
  long cont_2339X;
  long size_2338X;
  char * pointer_2337X;
  long v_2336X;
  char * pointer_2335X;
  char * code_pointer_2334X;
  long cont_2333X;
  char not_firstP_2332X;
  char * cont_2331X;
  char not_firstP_2330X;
  long template_2329X;
  FILE * out_2328X;
  long current_code_2327X;
  long v_2326X;
  long n_2325X;
  char v_2324X;
  long v_2323X;
  long v_2322X;
  long n_2321X;
  char v_2320X;
  long v_2319X;
  long y_2318X;
  long x_2317X;
  long rem_2316X;
  long quot_2315X;
  char div_by_zeroP_2314X;
  long v_2313X;
  long n_2312X;
  char v_2311X;
  long v_2310X;
  long v_2309X;
  long n_2308X;
  char v_2307X;
  long v_2306X;
  long v_2305X;
  long v_2304X;
  long stob_2303X;
  long v_2302X;
  long stob_2301X;
  char * addr_2300X;
  long x_2299X;
  char * addr_2298X;
  char * addr_2297X;
  long value_2296X;
  char * addr_2295X;
  long value_2294X;
  long copies_2293X;
  long v_2292X;
  long n_2291X;
  char v_2290X;
  long v_2289X;
  long n_2288X;
  char v_2287X;
  char * rem_2286X;
  char * quot_2285X;
  char div_by_zeroP_2284X;
  char * y_2283X;
  char *v_2282X;
  long link_2281X;
  long verify_2280X;
  long value_2279X;
  long copies_2278X;
  long stob_2277X;
  long i_2276X;
  long val_2275X;
  char * v_2274X;
  long value_2273X;
  char * x_2272X;
  long val_2271X;
  long v_2270X;
  char * v_2269X;
  char * addr_2268X;
  long val_2267X;
  char * addr_2266X;
  long value_2265X;
  long len_2264X;
  long s2_2263X;
  long foo_2262X;
  long previous_foo_2261X;
  char * addr_2260X;
  long verify_2259X;
  long value_2258X;
  long log_2257X;
  long stob_2256X;
  long i_2255X;
  long x_2254X;
  long status_2253X;
  long v_2252X;
  char * addr_2251X;
  long value_2250X;
  long val_2249X;
  long val_2248X;
  long n_2247X;
  char v_2246X;
  char * external_bignum_2245X;
  char * v_2244X;
  long value_2243X;
  long extra1_2242X;
  long val_2241X;
  long v_2240X;
  char * v_2239X;
  long val_2238X;
  long v_2237X;
  char * v_2236X;
  long x_2235X;
  long val_2234X;
  long v_2233X;
  char * v_2232X;
  char * addr_2231X;
  long value_2230X;
  long offset_2229X;
  long i_2228X;
  long count_2227X;
  char * addr_2226X;
  long value_2225X;
  long offset_2224X;
  long i_2223X;
  long count_2222X;
  long n_2221X;
  char * addr_2220X;
  long val_2219X;
  char * addr_2218X;
  long shifted_2217X;
  long j_2216X;
  long bits_2215X;
  long bucket_2214X;
  char * addr_2213X;
  char * addr_2212X;
  long value_2211X;
  char * addr_2210X;
  char * addr_2209X;
  char * addr_2208X;
  long value_2207X;
  char * addr_2206X;
  char * addr_2205X;
  long value_2204X;
  long proposal_2203X;
  long entry_2202X;
  long thing_2201X;
  long log_2200X;
  long copies_2199X;
  char * addr_2198X;
  long x_2197X;
  long val_2196X;
  long v_2195X;
  long reason_2194X;
  long channel_2193X;
  long channel_2192X;
  long link_2191X;
  long val_2190X;
  long x_2189X;
  char * addr_2188X;
  long b_2187X;
  long shifted_2186X;
  long j_2185X;
  long bits_2184X;
  long val_2183X;
  long v_2182X;
  long n_2181X;
  char v_2180X;
  char * external_bignum_2179X;
  char * x_2178X;
  char * v_2177X;
  long v_2176X;
  char * x_2175X;
  long val_2174X;
  long v_2173X;
  char * v_2172X;
  long n_2171X;
  long val_2170X;
  long val_2169X;
  long val_2168X;
  long val_2167X;
  long val_2166X;
  long val_2165X;
  long extra0_2164X;
  long length0_2163X;
  long val_2162X;
  long v_2161X;
  char * v_2160X;
  long x_2159X;
  long val_2158X;
  long v_2157X;
  char * v_2156X;
  long val_2155X;
  long val_2154X;
  long val_2153X;
  char * arg_2152X;
  char * loc_2151X;
  long x_2150X;
  long l_2149X;
  long stack_nargs_2148X;
  long x_2147X;
  long v_2146X;
  long x_2145X;
  long v_2144X;
  long v_2143X;
  long v_2142X;
  long bytes_used_2141X;
  long count_2140X;
  long index_2139X;
  long env_2138X;
  long offset_2137X;
  long i_2136X;
  long bytes_used_2135X;
  long count_2134X;
  long env_2133X;
  long offset_2132X;
  long i_2131X;
  long v_2130X;
  long n_2129X;
  long x_2128X;
  long x_2127X;
  long x_2126X;
  long obj_2125X;
  char * addr_2124X;
  long val_2123X;
  long count_2122X;
  char out_of_spaceP_2121X;
  char encoding_okP_2120X;
  char codec_okP_2119X;
  long count_2118X;
  long value_2117X;
  char incompleteP_2116X;
  char okP_2115X;
  char encoding_okP_2114X;
  long l_2113X;
  long codec_2112X;
  long p_2111X;
  long i_2110X;
  char * addr_2109X;
  long val_2108X;
  char * addr_2107X;
  long val_2106X;
  char * addr_2105X;
  char * addr_2104X;
  long val_2103X;
  char * addr_2102X;
  char * addr_2101X;
  long val_2100X;
  long count_2099X;
  long value_2098X;
  char incompleteP_2097X;
  char okP_2096X;
  char encoding_okP_2095X;
  char * addr_2094X;
  long val_2093X;
  long l_2092X;
  long codec_2091X;
  long p_2090X;
  long i_2089X;
  long x_2088X;
  long x_2087X;
  long d_2086X;
  long i_2085X;
  long l_2084X;
  long link_2083X;
  long index_2082X;
  long v_2081X;
  long table_2080X;
  long val_2079X;
  char x_2078X;
  char minutesP_2077X;
  long vector_2076X;
  char * addr_2075X;
  long x_2074X;
  long verify_2073X;
  long value_2072X;
  long copies_2071X;
  long stob_2070X;
  long i_2069X;
  char * addr_2068X;
  long v_2067X;
  char * addr_2066X;
  char * addr_2065X;
  long val_2064X;
  long x_2063X;
  char * addr_2062X;
  char * addr_2061X;
  char * addr_2060X;
  long status_2059X;
  char pendingP_2058X;
  char eofP_2057X;
  long got_2056X;
  char v_2055X;
  long count_2054X;
  long start_2053X;
  char waitP_2052X;
  long status_2051X;
  long channel_2050X;
  long v_2049X;
  long v_2048X;
  char x_2047X;
  char temp_2046X;
  long index_2045X;
  long len_2044X;
  long s2_2043X;
  long foo_2042X;
  long i_2041X;
  long i_2040X;
  char * addr_2039X;
  long i_2038X;
  long rest_list_2037X;
  long i_2036X;
  long v_2035X;
  long n_2034X;
  char v_2033X;
  char * external_bignum_2032X;
  char * x_2031X;
  long val_2030X;
  long v_2029X;
  char * v_2028X;
  char * v_2027X;
  long value_2026X;
  long needed_2025X;
  long y_2024X;
  long y_2023X;
  long x_2022X;
  long val_2021X;
  long v_2020X;
  char * v_2019X;
  long val_2018X;
  long v_2017X;
  char * v_2016X;
  long val_2015X;
  long val_2014X;
  long val_2013X;
  long count_2012X;
  long x_2011X;
  char * v_2010X;
  long value_2009X;
  long extra_2008X;
  long length_2007X;
  long x_2006X;
  long val_2005X;
  long c_2004X;
  long b_2003X;
  long val_2002X;
  long c_2001X;
  long b_2000X;
  long val_1999X;
  char b_1998X;
  long val_1997X;
  char b_1996X;
  long val_1995X;
  long v_1994X;
  long v_1993X;
  long v_1992X;
  long val_1991X;
  long v_1990X;
  long v_1989X;
  long v_1988X;
  long val_1987X;
  char b_1986X;
  char x_1985X;
  long c_1984X;
  long b_1983X;
  long val_1982X;
  long val_1981X;
  long val_1980X;
  long c_1979X;
  long mid_c_1978X;
  long v_1977X;
  long v_1976X;
  long lo_c_1975X;
  long hi_b_1974X;
  long hi_a_1973X;
  long lo_b_1972X;
  long lo_a_1971X;
  long b_1970X;
  long val_1969X;
  long args_1968X;
  char * arg_top_1967X;
  long list_arg_count_1966X;
  long list_args_1965X;
  long stack_nargs_1964X;
  long bytes_used_1963X;
  long count_1962X;
  long v_1961X;
  char * arg_1960X;
  char * loc_1959X;
  long v_1958X;
  long v_1957X;
  long v_1956X;
  long bytes_used_1955X;
  long args_1954X;
  long list_args_1953X;
  long stack_nargs_1952X;
  long v_1951X;
  long x_1950X;
  long v_1949X;
  long cont_1948X;
  long size_1947X;
  char * pointer_1946X;
  char * cont_1945X;
  long protocol_skip_1944X;
  long v_1943X;
  char v_1942X;
  char * addr_1941X;
  long value_1940X;
  long offset_1939X;
  long i_1938X;
  long count_1937X;
  char * addr_1936X;
  long value_1935X;
  long offset_1934X;
  long i_1933X;
  long count_1932X;
  long n_1931X;
  long sig_1930X;
  char x_1929X;
  long channel_1928X;
  long n_1927X;
  long x_1926X;
  long arg_count_1925X;
  long obj_1924X;
  long type_1923X;
  long thing_1922X;
  long stuff_1921X;
  char * addr_1920X;
  long val_1919X;
  long count_1918X;
  char out_of_spaceP_1917X;
  char encoding_okP_1916X;
  long i_1915X;
  long count_1914X;
  char out_of_spaceP_1913X;
  char encoding_okP_1912X;
  char codec_okP_1911X;
  long x_1910X;
  long l_1909X;
  long i_1908X;
  long b_1907X;
  long codec_1906X;
  long port_1905X;
  long Kchar_1904X;
  long b_1903X;
  long port_1902X;
  long b_1901X;
  long port_1900X;
  char * addr_1899X;
  long val_1898X;
  long i_1897X;
  long b_1896X;
  long p_1895X;
  long port_1894X;
  long byte_1893X;
  long i_1892X;
  long p_1891X;
  long p_1890X;
  long b_1889X;
  long port_1888X;
  char * addr_1887X;
  long val_1886X;
  long i_1885X;
  long p_1884X;
  long p_1883X;
  long b_1882X;
  long port_1881X;
  long x_1880X;
  long x_1879X;
  long x_1878X;
  long x_1877X;
  long x_1876X;
  long x_1875X;
  char * addr_1874X;
  long value_1873X;
  long list_1872X;
  long head_1871X;
  char move_slowP_1870X;
  long slow_1869X;
  long list_1868X;
  long obj_1867X;
  char * addr_1866X;
  long len_1865X;
  long x_1864X;
  long val_1863X;
  long mseconds_1862X;
  long seconds_1861X;
  long option_1860X;
  long vector_1859X;
  char firstP_1858X;
  long x_1857X;
  long x_1856X;
  long v_1855X;
  long v_1854X;
  long x_1853X;
  long result_1852X;
  char * args_1851X;
  long proc_1850X;
  long name_1849X;
  long rest_list_1848X;
  long x_1847X;
  long x_1846X;
  long x_1845X;
  long x_1844X;
  long value_1843X;
  long vector_1842X;
  long type_1841X;
  char firstP_1840X;
  long vector_1839X;
  char firstP_1838X;
  long x_1837X;
  long x_1836X;
  long x_1835X;
  long status_1834X;
  long reason_1833X;
  long x_1832X;
  char * addr_1831X;
  long next_stob_1830X;
  long i_1829X;
  long x_1828X;
  long v_1827X;
  long next_stob_1826X;
  long i_1825X;
  long value_1824X;
  long x_1823X;
  char * addr_1822X;
  long count_1821X;
  long to_index_1820X;
  long from_index_1819X;
  long copies_1818X;
  long left_1817X;
  long value_1816X;
  long verify_1815X;
  long value_1814X;
  long log_1813X;
  long stob_1812X;
  long i_1811X;
  char * addr_1810X;
  long old_1809X;
  long x_1808X;
  char * addr_1807X;
  long channel_1806X;
  long res_1805X;
  long i_1804X;
  long x_1803X;
  long y_1802X;
  long n_1801X;
  char * addr_1800X;
  long prev_1799X;
  long ch_1798X;
  long x_1797X;
  long val_1796X;
  long x_1795X;
  long val_1794X;
  long val_1793X;
  long x_1792X;
  long val_1791X;
  long x_1790X;
  long x_1789X;
  long v_1788X;
  long v_1787X;
  char *filename_1786X;
  long val_1785X;
  long x_1784X;
  char * addr_1783X;
  char * addr_1782X;
  long x_1781X;
  long val_1780X;
  long x_1779X;
  long bucket_1778X;
  long x_1777X;
  long x_1776X;
  long shifted_1775X;
  long j_1774X;
  long bits_1773X;
  long x_1772X;
  long x_1771X;
  long scalar_value_1770X;
  long j_1769X;
  long bits_1768X;
  long x_1767X;
  long x_1766X;
  long vector_1765X;
  long x_1764X;
  long x_1763X;
  long x_1762X;
  long vector_1761X;
  long new_1760X;
  char * addr_1759X;
  long value_1758X;
  long value_1757X;
  long x_1756X;
  char * addr_1755X;
  long value_1754X;
  long i_1753X;
  long value_1752X;
  long i_1751X;
  long value_1750X;
  long val_1749X;
  long val_1748X;
  long x_1747X;
  long val_1746X;
  long x_1745X;
  long val_1744X;
  long val_1743X;
  char * v_1742X;
  long value_1741X;
  long needed_1740X;
  long y_1739X;
  long x_1738X;
  long result_1737X;
  long x_1736X;
  long x_1735X;
  long x_1734X;
  long count_1733X;
  long value_1732X;
  long val_1731X;
  long val_1730X;
  long val_1729X;
  long x_1728X;
  long val_1727X;
  long x_1726X;
  long n_1725X;
  long x_1724X;
  long x_1723X;
  long v_1722X;
  long x_1721X;
  long n_1720X;
  long a_1719X;
  long a_1718X;
  long val_1717X;
  long val_1716X;
  char b_1715X;
  long val_1714X;
  char b_1713X;
  long val_1712X;
  char b_1711X;
  long val_1710X;
  long Kdouble_1709X;
  char * addr_1708X;
  double value_1707X;
  long value_1706X;
  double x_1705X;
  long value_1704X;
  long a_1703X;
  long Kdouble_1702X;
  char * addr_1701X;
  double y_1700X;
  long value_1699X;
  double x_1698X;
  long value_1697X;
  long val_1696X;
  long v_1695X;
  char * v_1694X;
  long Kdouble_1693X;
  char * addr_1692X;
  double y_1691X;
  long value_1690X;
  double x_1689X;
  long value_1688X;
  long a_1687X;
  long Kdouble_1686X;
  char * addr_1685X;
  double y_1684X;
  long value_1683X;
  double x_1682X;
  long value_1681X;
  long val_1680X;
  long v_1679X;
  char * v_1678X;
  long n_1677X;
  long val_1676X;
  long val_1675X;
  long delta_1674X;
  long delta_1673X;
  long offset_1672X;
  long index_1671X;
  long v_1670X;
  char * arg_top_1669X;
  long args_1668X;
  long count_1667X;
  long size_1666X;
  char * pointer_1665X;
  char * cont_1664X;
  long offset_1663X;
  long cont_1662X;
  long args_1661X;
  long args_1660X;
  long v_1659X;
  long v_1658X;
  long protocol_1657X;
  char * code_pointer_1656X;
  long list_arg_count_1655X;
  long list_args_1654X;
  long stack_nargs_1653X;
  long args_1652X;
  long x_1651X;
  long args_1650X;
  long x_1649X;
  long x_1648X;
  long x_1647X;
  char * addr_1646X;
  long a_1645X;
  long wants_stack_args_1644X;
  long size_1643X;
  char * pointer_1642X;
  char * cont_1641X;
  long proc_1640X;
  long offset_1639X;
  long cont_1638X;
  long protocol_1637X;
  char * code_pointer_1636X;
  long obj_1635X;
  char * addr_1634X;
  long list_args_1633X;
  long follower_1632X;
  long list_1631X;
  long x_1630X;
  long args_1629X;
  long list_arg_count_1628X;
  char okayP_1627X;
  long stack_nargs_1626X;
  long list_args_1625X;
  long obj_1624X;
  long obj_1623X;
  long list_arg_count_1622X;
  long list_args_1621X;
  long stack_arg_count_1620X;
  long obj_1619X;
  char interruptP_1618X;
  long protocol_1617X;
  long code_1616X;
  long template_1615X;
  long obj_1614X;
  long stack_arg_count_1613X;
  long value_1612X;
  long index_1611X;
  long value_1610X;
  long index_1609X;
  long value_1608X;
  long move_1607X;
  long index_1606X;
  long value_1605X;
  long move_1604X;
  long n_1603X;
  long value_1602X;
  long i_1601X;
  char * addr_1600X;
  long value_1599X;
  long offset_1598X;
  long i_1597X;
  long count_1596X;
  long total_count_1595X;
  long offset_1594X;
  long i_1593X;
  long new_env_1592X;
  char * addr_1591X;
  long value_1590X;
  long offset_1589X;
  long i_1588X;
  long count_1587X;
  long total_count_1586X;
  long offset_1585X;
  long i_1584X;
  long new_env_1583X;
  long v_1582X;
  long x_1581X;
  long x_1580X;
  long args_1579X;
  long length_1578X;
  char okayP_1577X;
  long list_args_1576X;
  long stack_nargs_1575X;
  long maybe_cont_1574X;
  long v_1573X;
  long v_1572X;
  long code_1571X;
  long n_1570X;
  char * addr_1569X;
  long x_1568X;
  long x_1567X;
  long x_1566X;
  char v_1565X;
  long return_address_1564X;
  long template_1563X;
  long obj_1562X;
  long stack_arg_count_1561X;
  long tag_1560X;
  long n_1559X;
  char still_readyP_1558X;
  long uid_1557X;
  char v_1556X;
  char * addr_1555X;
  long next_1554X;
  long channel_1553X;
  long n_1552X;
  long x_1551X;
  long handlers_1550X;
  long m_1549X;
  long i_1548X;
  FILE * out_1547X;
  long x_1546X;
  long x_1545X;
  long val_1544X;
  long v_1543X;
  long v_1542X;
  long v_1541X;
  long v_1540X;
  long v_1539X;
  long v_1538X;
  long v_1537X;
  long v_1536X;
  long v_1535X;
  long v_1534X;
  long v_1533X;
  long v_1532X;
  long v_1531X;
  long v_1530X;
  long count_1529X;
  long value_1528X;
  char incompleteP_1527X;
  char okP_1526X;
  char encoding_okP_1525X;
  long count_1524X;
  long start_1523X;
  long encoding_1522X;
  long arg4_1521X;
  long arg3_1520X;
  long arg2_1519X;
  long count_1518X;
  long value_1517X;
  char incompleteP_1516X;
  char okP_1515X;
  char encoding_okP_1514X;
  long count_1513X;
  long start_1512X;
  long encoding_1511X;
  long arg4_1510X;
  long arg3_1509X;
  long arg2_1508X;
  long count_1507X;
  char out_of_spaceP_1506X;
  char okP_1505X;
  char encoding_okP_1504X;
  long count_1503X;
  long start_1502X;
  long value_1501X;
  long encoding_1500X;
  long arg5_1499X;
  long arg4_1498X;
  long arg3_1497X;
  long arg2_1496X;
  long count_1495X;
  char out_of_spaceP_1494X;
  char okP_1493X;
  char encoding_okP_1492X;
  long count_1491X;
  long start_1490X;
  long value_1489X;
  long encoding_1488X;
  long arg5_1487X;
  long arg4_1486X;
  long arg3_1485X;
  long arg2_1484X;
  long x_1483X;
  long v_1482X;
  long len_1481X;
  long value_1480X;
  long index_1479X;
  long arg4_1478X;
  long arg3_1477X;
  long arg2_1476X;
  long x_1475X;
  long v_1474X;
  long v_1473X;
  long len_1472X;
  long index_1471X;
  long arg3_1470X;
  long arg2_1469X;
  long list_1468X;
  long arg2_1467X;
  long x_1466X;
  long n_1465X;
  long arg2_1464X;
  long len_1463X;
  long x_1462X;
  long obj_1461X;
  long arg2_1460X;
  long x_1459X;
  long arg2_1458X;
  long x_1457X;
  long status_1456X;
  long value_1455X;
  long key_1454X;
  long arg2_1453X;
  long x_1452X;
  long val_1451X;
  char *string_1450X;
  long val_1449X;
  long key_1448X;
  long x_1447X;
  long mseconds_1446X;
  long seconds_1445X;
  long mseconds_1444X;
  long seconds_1443X;
  long mseconds_1442X;
  long seconds_1441X;
  long x_1440X;
  long other_1439X;
  long option_1438X;
  long arg2_1437X;
  long x_1436X;
  long arg2_1435X;
  long x_1434X;
  long arg2_1433X;
  long x_1432X;
  long rest_list_1431X;
  long p_1430X;
  long nargs_1429X;
  long p_1428X;
  long x_1427X;
  long arg2_1426X;
  long x_1425X;
  long p_1424X;
  long v_1423X;
  long v_1422X;
  long template_1421X;
  long return_address_1420X;
  long v_1419X;
  long p_1418X;
  long v_1417X;
  long v_1416X;
  long code_1415X;
  long pc_1414X;
  long p_1413X;
  long old_1412X;
  long temp_1411X;
  long obj_1410X;
  long opcode_1409X;
  long exception_1408X;
  long code_1407X;
  long data_1406X;
  long opcode_1405X;
  long pc_1404X;
  long size_1403X;
  long exception_1402X;
  long code_1401X;
  long data_1400X;
  long temp_1399X;
  long obj_1398X;
  long val_1397X;
  long x_1396X;
  long x_1395X;
  long type_1394X;
  long x_1393X;
  long x_1392X;
  long x_1391X;
  long bytes_1390X;
  long x_1389X;
  long other_1388X;
  long key_1387X;
  long arg2_1386X;
  long x_1385X;
  char * addr_1384X;
  long b_1383X;
  long x_1382X;
  char * addr_1381X;
  long proc_1380X;
  long arg2_1379X;
  long x_1378X;
  long obj_1377X;
  long status_1376X;
  long status_1375X;
  long status_1374X;
  long status_1373X;
  long status_1372X;
  long status_1371X;
  FILE * port_1370X;
  long undumpables_1369X;
  long obj_1368X;
  long arg4_1367X;
  long arg3_1366X;
  long arg2_1365X;
  long x_1364X;
  long log_1363X;
  long index_1362X;
  long x_1361X;
  long len_1360X;
  long byte_1359X;
  long index_1358X;
  long arg3_1357X;
  long arg2_1356X;
  long log_1355X;
  long index_1354X;
  long x_1353X;
  long len_1352X;
  long index_1351X;
  long arg2_1350X;
  long v_1349X;
  long count_1348X;
  long to_index_1347X;
  long from_index_1346X;
  long arg5_1345X;
  long arg4_1344X;
  long arg3_1343X;
  long arg2_1342X;
  long v_1341X;
  long x_1340X;
  long offset_1339X;
  long type_1338X;
  long stob_1337X;
  long log_1336X;
  long proposal_1335X;
  long proposal_1334X;
  long weak_pointer_1333X;
  char * addr_1332X;
  long x_1331X;
  char * addr_1330X;
  long next_1329X;
  long channel_1328X;
  long n_1327X;
  char * addr_1326X;
  long head_1325X;
  long channel_1324X;
  long obj_1323X;
  long x_1322X;
  long status_1321X;
  char readyP_1320X;
  long channel_1319X;
  long obj_1318X;
  long x_1317X;
  char x_1316X;
  long x_1315X;
  long param_1314X;
  long x_1313X;
  char * addr_1312X;
  char * addr_1311X;
  long status_1310X;
  char pendingP_1309X;
  long got_1308X;
  char v_1307X;
  long count_1306X;
  long start_1305X;
  long arg4_1304X;
  long arg3_1303X;
  long arg2_1302X;
  long x_1301X;
  long arg5_1300X;
  long arg4_1299X;
  long arg3_1298X;
  long arg2_1297X;
  long x_1296X;
  long status_1295X;
  long channel_1294X;
  long obj_1293X;
  long x_1292X;
  long close_silentlyP_1291X;
  long mode_1290X;
  long arg4_1289X;
  long arg3_1288X;
  long arg2_1287X;
  long x_1286X;
  long x_1285X;
  long x_1284X;
  long arg2_1283X;
  long descriptor_1282X;
  long x_1281X;
  long obj_1280X;
  long link_1279X;
  long index_1278X;
  long v_1277X;
  long string_1276X;
  long table_1275X;
  long obj_1274X;
  long y_1273X;
  long y_1272X;
  long count_1271X;
  long to_index_1270X;
  long from_index_1269X;
  long arg5_1268X;
  long arg4_1267X;
  long arg3_1266X;
  long arg2_1265X;
  long len_1264X;
  long Kchar_1263X;
  long index_1262X;
  long arg3_1261X;
  long arg2_1260X;
  long len_1259X;
  long index_1258X;
  long arg2_1257X;
  long x_1256X;
  long obj_1255X;
  char * addr_1254X;
  long len_1253X;
  long init_1252X;
  long len_1251X;
  long arg2_1250X;
  long len_1249X;
  long Kchar_1248X;
  long index_1247X;
  long arg3_1246X;
  long arg2_1245X;
  long len_1244X;
  long index_1243X;
  long arg2_1242X;
  long obj_1241X;
  long x_1240X;
  char * addr_1239X;
  long init_1238X;
  long len_1237X;
  long arg2_1236X;
  char * addr_1235X;
  long v_1234X;
  long index_1233X;
  long len_1232X;
  long type_1231X;
  long value_1230X;
  long arg3_1229X;
  long arg2_1228X;
  long v_1227X;
  long v_1226X;
  long index_1225X;
  long len_1224X;
  long type_1223X;
  long index_1222X;
  long arg2_1221X;
  char * addr_1220X;
  long len_1219X;
  long len_1218X;
  long type_1217X;
  long init_1216X;
  long arg2_1215X;
  long v_1214X;
  long offset_1213X;
  long type_1212X;
  long value_1211X;
  long arg2_1210X;
  long offset_1209X;
  long type_1208X;
  long stob_1207X;
  long rest_list_1206X;
  long stack_nargs_1205X;
  long p_1204X;
  long new_1203X;
  char * addr_1202X;
  long len_1201X;
  long type_1200X;
  long len_1199X;
  long p_1198X;
  long new_1197X;
  char * addr_1196X;
  long len_1195X;
  long type_1194X;
  long len_1193X;
  long type_1192X;
  long stob_1191X;
  long type_1190X;
  long x_1189X;
  long x_1188X;
  long x_1187X;
  long x_1186X;
  long x_1185X;
  long x_1184X;
  long x_1183X;
  long x_1182X;
  long arg2_1181X;
  long x_1180X;
  long arg2_1179X;
  long x_1178X;
  long v_1177X;
  long v_1176X;
  long y_1175X;
  long arg2_1174X;
  long y_1173X;
  long arg2_1172X;
  long y_1171X;
  long arg2_1170X;
  long y_1169X;
  long arg2_1168X;
  long x_1167X;
  long x_1166X;
  long x_1165X;
  long x_1164X;
  long arg2_1163X;
  long x_1162X;
  long arg2_1161X;
  long x_1160X;
  long arg2_1159X;
  long x_1158X;
  long x_1157X;
  long x_1156X;
  long x_1155X;
  long x_1154X;
  long x_1153X;
  long x_1152X;
  long x_1151X;
  long x_1150X;
  long x_1149X;
  long x_1148X;
  long n_1147X;
  long n_1146X;
  long n_1145X;
  long n_1144X;
  long n_1143X;
  long a_1142X;
  long val_1141X;
  long y_1140X;
  long arg2_1139X;
  long b_1138X;
  long a_1137X;
  long val_1136X;
  long y_1135X;
  long arg2_1134X;
  long y_1133X;
  long arg2_1132X;
  long y_1131X;
  long arg2_1130X;
  long y_1129X;
  long arg2_1128X;
  long y_1127X;
  long arg2_1126X;
  long y_1125X;
  long arg2_1124X;
  long b_1123X;
  long a_1122X;
  long y_1121X;
  long arg2_1120X;
  long x_1119X;
  long y_1118X;
  long arg2_1117X;
  long b_1116X;
  long a_1115X;
  long y_1114X;
  long arg2_1113X;
  long x_1112X;
  long y_1111X;
  long arg2_1110X;
  long x_1109X;
  long x_1108X;
  long n_1107X;
  long n_1106X;
  long x_1105X;
  long x_1104X;
  long arg2_1103X;
  long rest_list_1102X;
  long x_1101X;
  long rest_list_1100X;
  long stack_nargs_1099X;
  long arg1_1098X;
  long arg0_1097X;
  long arg0_1096X;
  long rest_list_1095X;
  long stack_nargs_1094X;
  long x_1093X;
  long index_1092X;
  long val_1091X;
  long max_1090X;
  long p_1089X;
  char * code_pointer_1088X;
  long return_pointer_offset_1087X;
  long nargs_1086X;
  long code_1085X;
  long template_1084X;
  long rest_list_1083X;
  long stack_nargs_1082X;
  long p_1081X;
  long p_1080X;
  long cont_1079X;
  long v_1078X;
  long rest_list_1077X;
  long stack_nargs_1076X;
  long p_1075X;
  long x_1074X;
  long args_1073X;
  char * code_pointer_1072X;
  long return_pointer_offset_1071X;
  long length_1070X;
  char okayP_1069X;
  long stack_nargs_1068X;
  long list_args_1067X;
  char v_1066X;
  char v_1065X;
  char * code_pointer_1064X;
  long return_pointer_offset_1063X;
  long stack_arg_count_1062X;
  char * code_pointer_1061X;
  long stack_arg_count_1060X;
  long v_1059X;
  long n_moves_1058X;
  long x_1057X;
  long n_moves_1056X;
  long x_1055X;
  long x_1054X;
  long x_1053X;
  long x_1052X;
  long x_1051X;
  long value_1050X;
  long x_1049X;
  long closure_1048X;
  char * addr_1047X;
  long len_1046X;
  long size_1045X;
  long free_count_1044X;
  char * addr_1043X;
  long x_1042X;
  long value_1041X;
  char * addr_1040X;
  long x_1039X;
  long x_1038X;
  long template_1037X;
  long new_env_1036X;
  char * addr_1035X;
  long len_1034X;
  long closures_1033X;
  long total_count_1032X;
  long template_1031X;
  long new_env_1030X;
  char * addr_1029X;
  long len_1028X;
  long closures_1027X;
  long total_count_1026X;
  char * addr_1025X;
  long val_1024X;
  long x_1023X;
  long location_1022X;
  long index_1021X;
  long template_1020X;
  long location_1019X;
  long index_1018X;
  long template_1017X;
  long x_1016X;
  long x_1015X;
  long n_1014X;
  char * code_pointer_1013X;
  long v_1012X;
  long code_1011X;
  long n_1010X;
  char * addr_1009X;
  long x_1008X;
  long x_1007X;
  long pc_1006X;
  long code_1005X;
  long x_1004X;
  char v_1003X;
  char v_1002X;
  long tag_1001X;
  long n_1000X;
  long v_999X;
  char v_998X;
  long x_997X;
  long x_996X;
  long x_995X;
  long x_994X;
  long x_993X;
  long x_992X;
  long x_991X;
  long x_990X;
  long spec_989X;
  long needed_stack_space_988X;
  long template_987X;
  long used_986X;
  long code_985X;
  long v_984X;
  long v_983X;
  long code_982X;
  long n_981X;
  char * addr_980X;
  long x_979X;
  long x_978X;
  long x_977X;
  long protocol_skip_976X;
  long final_stack_arg_count_975X;
  char interruptP_974X;
  long obj_973X;
  long template_972X;
  char v_971X;
  char v_970X;
  long skip_969X;
  long skip_968X;
  long x_967X;
  long x_966X;
  long x_965X;
  long x_964X;
  long x_963X;
  long x_962X;
  long x_961X;
  long x_960X;
  long spec_959X;
  long template_958X;
  long used_957X;
  long envUtemp_offset_956X;
  long code_955X;
  long retval_954X;
  long handlers_953X;
  long opcode_952X;
  long nargs_951X;
  long v_950X;
  long v_949X;
  long v_948X;
  long v_947X;
  long index_946X;
  long length_945X;
  long v_944X;
  long v_943X;
  long v_942X;
  long v_941X;
  long v_940X;
  long v_939X;
  long wants_stack_args_938X;
  long v_937X;
  long v_936X;
  long v_935X;
  long v_934X;
  long skip_933X;
  char nativeP_932X;
  long stack_space_931X;
  long protocol_930X;
  long v_929X;
  long x_928X;
  long args_927X;
  long v_926X;
  long list_arg_count_925X;
  long list_args_924X;
  long stack_arg_count_923X;
  long exception_922X;
  long total_arg_count_921X;
  long code_920X;
  long handler_tag_919X;
  long list_arg_count_918X;
  long list_args_917X;
  long stack_arg_count_916X;
  long obj_915X;
 {  if ((3 == (3 & proc_880X))) {
    if ((3 == (31 & ((((*((long *) ((((char *) (-3 + proc_880X))) + -4))))>>2))))) {
      SvalS = proc_880X;
      obj_915X = SvalS;
      if ((3 == (3 & obj_915X))) {
        if ((3 == (31 & ((((*((long *) ((((char *) (-3 + obj_915X))) + -4))))>>2))))) {
          arg0K0 = nargs_881X;
          arg0K1 = 25;
          arg0K2 = 0;
          arg0K3 = -1;
          goto L60809;}
        else {
          arg0K0 = 3;
          arg0K1 = nargs_881X;
          arg0K2 = 25;
          arg0K3 = 0;
          goto L30300;}}
      else {
        arg0K0 = 3;
        arg0K1 = nargs_881X;
        arg0K2 = 25;
        arg0K3 = 0;
        goto L30300;}}
    else {
      goto L30460;}}
  else {
    goto L30460;}}
 L60809: {
  stack_arg_count_916X = arg0K0;
  list_args_917X = arg0K1;
  list_arg_count_918X = arg0K2;
  handler_tag_919X = arg0K3;
  code_920X = *((long *) (((char *) (-3 + (*((long *) (((char *) (-3 + (SvalS))))))))));
  total_arg_count_921X = stack_arg_count_916X + list_arg_count_918X;
  arg0K0 = (*((unsigned char *) ((((char *) (-3 + code_920X))) + 1)));
  arg0K1 = 64;
  arg4K2 = 0;
  goto L60835;}
 L30300: {
  exception_922X = arg0K0;
  stack_arg_count_923X = arg0K1;
  list_args_924X = arg0K2;
  list_arg_count_925X = arg0K3;
  merged_arg0K0 = list_args_924X;
  merged_arg0K1 = list_arg_count_925X;
  copy_listSAgc_return_tag = 0;
  goto copy_listSAgc;
 copy_listSAgc_return_0:
  v_926X = copy_listSAgc0_return_value;
  merged_arg0K0 = v_926X;
  merged_arg0K1 = stack_arg_count_923X;
  pop_args_GlistSAgc_return_tag = 0;
  goto pop_args_GlistSAgc;
 pop_args_GlistSAgc_return_0:
  args_927X = pop_args_GlistSAgc0_return_value;push_exception_setupB(exception_922X, 0);
  x_928X = SvalS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_928X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (args_927X);
  arg0K0 = 2;
  goto L30610;}
 L30460: {
  ps_error("s48-restart called with non-procedure", 1, proc_880X);
  return v_929X;}
 L60835: {
  protocol_930X = arg0K0;
  stack_space_931X = arg0K1;
  nativeP_932X = arg4K2;
  if ((69 == protocol_930X)) {
    if ((total_arg_count_921X < 3)) {
      skip_933X = *((unsigned char *) ((((char *) (-3 + code_920X))) + (3 + total_arg_count_921X)));
      if ((0 == skip_933X)) {
        if ((-1 == handler_tag_919X)) {
          arg0K0 = 4;
          arg0K1 = stack_arg_count_916X;
          arg0K2 = list_args_917X;
          arg0K3 = list_arg_count_918X;
          goto L30300;}
        else {
          if ((handler_tag_919X < 0)) {
            ps_error("wrong number of arguments to interrupt handler", 1, (-2 - handler_tag_919X));
            arg0K0 = v_934X;
            goto L65498;}
          else {
            ps_error("wrong number of arguments to exception handler", 1, handler_tag_919X);
            arg0K0 = v_935X;
            goto L65498;}}}
      else {
        merged_arg0K0 = list_args_917X;
        merged_arg0K1 = list_arg_count_918X;
        push_list_return_tag = 0;
        goto push_list;
       push_list_return_0:
        arg0K0 = code_920X;
        arg0K1 = 6;
        arg0K2 = skip_933X;
        arg0K3 = (*((long *) (((char *) (-3 + (SvalS))))));
        goto L29426;}}
    else {
      if ((0 == (*((unsigned char *) ((((char *) (-3 + code_920X))) + 2))))) {
        if ((-1 == handler_tag_919X)) {
          arg0K0 = 4;
          arg0K1 = stack_arg_count_916X;
          arg0K2 = list_args_917X;
          arg0K3 = list_arg_count_918X;
          goto L30300;}
        else {
          if ((handler_tag_919X < 0)) {
            ps_error("wrong number of arguments to interrupt handler", 1, (-2 - handler_tag_919X));
            arg0K0 = v_936X;
            goto L65498;}
          else {
            ps_error("wrong number of arguments to exception handler", 1, handler_tag_919X);
            arg0K0 = v_937X;
            goto L65498;}}}
      else {
        arg0K0 = 6;
        goto L60878;}}}
  else {
    if ((63 < protocol_930X)) {
      if ((65 == protocol_930X)) {
        wants_stack_args_938X = ((((*((unsigned char *) ((((char *) (-3 + code_920X))) + 2))))<<8)) + (*((unsigned char *) ((((char *) (-3 + code_920X))) + 3)));
        if ((total_arg_count_921X < wants_stack_args_938X)) {
          if ((-1 == handler_tag_919X)) {
            arg0K0 = 4;
            arg0K1 = stack_arg_count_916X;
            arg0K2 = list_args_917X;
            arg0K3 = list_arg_count_918X;
            goto L30300;}
          else {
            if ((handler_tag_919X < 0)) {
              ps_error("wrong number of arguments to interrupt handler", 1, (-2 - handler_tag_919X));
              arg0K0 = v_939X;
              goto L65498;}
            else {
              ps_error("wrong number of arguments to exception handler", 1, handler_tag_919X);
              arg0K0 = v_940X;
              goto L65498;}}}
        else {
          merged_arg0K0 = wants_stack_args_938X;
          merged_arg0K1 = stack_arg_count_916X;
          merged_arg0K2 = list_args_917X;
          merged_arg0K3 = list_arg_count_918X;
          rest_list_setupAgc_return_tag = 0;
          goto rest_list_setupAgc;
         rest_list_setupAgc_return_0:
          arg0K0 = 4;
          goto L60839;}}
      else {
        if ((68 == protocol_930X)) {
          if ((total_arg_count_921X < (*((unsigned char *) ((((char *) (-3 + code_920X))) + 2))))) {
            if ((-1 == handler_tag_919X)) {
              arg0K0 = 4;
              arg0K1 = stack_arg_count_916X;
              arg0K2 = list_args_917X;
              arg0K3 = list_arg_count_918X;
              goto L30300;}
            else {
              if ((handler_tag_919X < 0)) {
                ps_error("wrong number of arguments to interrupt handler", 1, (-2 - handler_tag_919X));
                arg0K0 = v_941X;
                goto L65498;}
              else {
                ps_error("wrong number of arguments to exception handler", 1, handler_tag_919X);
                arg0K0 = v_942X;
                goto L65498;}}}
          else {
            arg0K0 = 3;
            goto L60878;}}
        else {
          if ((127 < protocol_930X)) {
            arg0K0 = (127 & protocol_930X);
            arg0K1 = stack_space_931X;
            arg4K2 = 1;
            goto L60835;}
          else {
            if ((64 == protocol_930X)) {
              if (((((((*((unsigned char *) ((((char *) (-3 + code_920X))) + 2))))<<8)) + (*((unsigned char *) ((((char *) (-3 + code_920X))) + 3)))) == total_arg_count_921X)) {
                if ((0 == list_arg_count_918X)) {
                  arg0K0 = 4;
                  goto L60839;}
                else {
                  merged_arg0K0 = list_args_917X;
                  merged_arg0K1 = list_arg_count_918X;
                  push_list_return_tag = 1;
                  goto push_list;
                 push_list_return_1:
                  arg0K0 = 4;
                  goto L60839;}}
              else {
                if ((-1 == handler_tag_919X)) {
                  arg0K0 = 4;
                  arg0K1 = stack_arg_count_916X;
                  arg0K2 = list_args_917X;
                  arg0K3 = list_arg_count_918X;
                  goto L30300;}
                else {
                  if ((handler_tag_919X < 0)) {
                    ps_error("wrong number of arguments to interrupt handler", 1, (-2 - handler_tag_919X));
                    arg0K0 = v_943X;
                    goto L65498;}
                  else {
                    ps_error("wrong number of arguments to exception handler", 1, handler_tag_919X);
                    arg0K0 = v_944X;
                    goto L65498;}}}}
            else {
              if ((67 == protocol_930X)) {
                length_945X = (long)(((unsigned long)(*((long *) ((((char *) (-3 + code_920X))) + -4))))>>8);
                index_946X = -2 + length_945X;
                arg0K0 = (*((unsigned char *) ((((char *) (-3 + code_920X))) + (-3 + length_945X))));
                arg0K1 = (((((*((unsigned char *) ((((char *) (-3 + code_920X))) + index_946X))))<<8)) + (*((unsigned char *) ((((char *) (-3 + code_920X))) + (1 + index_946X)))));
                arg4K2 = nativeP_932X;
                goto L60835;}
              else {
                ps_error("unknown protocol", 1, protocol_930X);
                if ((-1 == handler_tag_919X)) {
                  arg0K0 = 4;
                  arg0K1 = stack_arg_count_916X;
                  arg0K2 = list_args_917X;
                  arg0K3 = list_arg_count_918X;
                  goto L30300;}
                else {
                  if ((handler_tag_919X < 0)) {
                    ps_error("wrong number of arguments to interrupt handler", 1, (-2 - handler_tag_919X));
                    arg0K0 = v_947X;
                    goto L65498;}
                  else {
                    ps_error("wrong number of arguments to exception handler", 1, handler_tag_919X);
                    arg0K0 = v_948X;
                    goto L65498;}}}}}}}}
    else {
      if ((protocol_930X == total_arg_count_921X)) {
        if ((0 == list_arg_count_918X)) {
          arg0K0 = 2;
          goto L60839;}
        else {
          merged_arg0K0 = list_args_917X;
          merged_arg0K1 = list_arg_count_918X;
          push_list_return_tag = 2;
          goto push_list;
         push_list_return_2:
          arg0K0 = 2;
          goto L60839;}}
      else {
        if ((-1 == handler_tag_919X)) {
          arg0K0 = 4;
          arg0K1 = stack_arg_count_916X;
          arg0K2 = list_args_917X;
          arg0K3 = list_arg_count_918X;
          goto L30300;}
        else {
          if ((handler_tag_919X < 0)) {
            ps_error("wrong number of arguments to interrupt handler", 1, (-2 - handler_tag_919X));
            arg0K0 = v_949X;
            goto L65498;}
          else {
            ps_error("wrong number of arguments to exception handler", 1, handler_tag_919X);
            arg0K0 = v_950X;
            goto L65498;}}}}}}
 L30610: {
  nargs_951X = arg0K0;
  opcode_952X = (((*((long *) ((SstackS) + (4 + (((nargs_951X)<<2)))))))>>2);
  handlers_953X = SHARED_REF((Sexception_handlersS));
  if ((3 == (3 & handlers_953X))) {
    if ((2 == (31 & ((((*((long *) ((((char *) (-3 + handlers_953X))) + -4))))>>2))))) {
      goto L30675;}
    else {
      goto L30758;}}
  else {
    goto L30758;}}
 L65498: {
  retval_954X = arg0K0;
  SstackS = (ScontS);
  return retval_954X;}
 L29426: {
  code_955X = arg0K0;
  envUtemp_offset_956X = arg0K1;
  used_957X = arg0K2;
  template_958X = arg0K3;
  spec_959X = *((unsigned char *) ((((char *) (-3 + code_955X))) + envUtemp_offset_956X));
  if ((3 == spec_959X)) {
    x_960X = *((long *) ((((char *) (-3 + (SvalS)))) + 4));
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) (x_960X);
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) (template_958X);
    goto L29430;}
  else {
    if ((1 == spec_959X)) {
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (template_958X);
      goto L29430;}
    else {
      if ((2 == spec_959X)) {
        x_961X = *((long *) ((((char *) (-3 + (SvalS)))) + 4));
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (x_961X);
        goto L29430;}
      else {
        if ((4 == spec_959X)) {
          x_962X = SvalS;
          SstackS = ((SstackS) + -4);
          *((long *) (SstackS)) = (long) (x_962X);
          goto L29430;}
        else {
          if ((6 == spec_959X)) {
            x_963X = SvalS;
            SstackS = ((SstackS) + -4);
            *((long *) (SstackS)) = (long) (x_963X);
            x_964X = *((long *) ((((char *) (-3 + (SvalS)))) + 4));
            SstackS = ((SstackS) + -4);
            *((long *) (SstackS)) = (long) (x_964X);
            goto L29430;}
          else {
            if ((5 == spec_959X)) {
              x_965X = SvalS;
              SstackS = ((SstackS) + -4);
              *((long *) (SstackS)) = (long) (x_965X);
              SstackS = ((SstackS) + -4);
              *((long *) (SstackS)) = (long) (template_958X);
              goto L29430;}
            else {
              if ((7 == spec_959X)) {
                x_966X = SvalS;
                SstackS = ((SstackS) + -4);
                *((long *) (SstackS)) = (long) (x_966X);
                x_967X = *((long *) ((((char *) (-3 + (SvalS)))) + 4));
                SstackS = ((SstackS) + -4);
                *((long *) (SstackS)) = (long) (x_967X);
                SstackS = ((SstackS) + -4);
                *((long *) (SstackS)) = (long) (template_958X);
                goto L29430;}
              else {
                goto L29430;}}}}}}}}
 L60878: {
  skip_968X = arg0K0;
  if ((total_arg_count_921X < 3)) {
    arg0K0 = total_arg_count_921X;
    goto L60886;}
  else {
    if ((2 < stack_arg_count_916X)) {
      arg0K0 = stack_arg_count_916X;
      goto L60886;}
    else {
      arg0K0 = 2;
      goto L60886;}}}
 L60839: {
  skip_969X = arg0K0;
  if (nativeP_932X) {
    merged_arg0K0 = stack_space_931X;
    ensure_stack_spaceB_return_tag = 0;
    goto ensure_stack_spaceB;
   ensure_stack_spaceB_return_0:
    v_970X = ensure_stack_spaceB0_return_value;
    if (v_970X) {
      pending_interruptP_return_tag = 0;
      goto pending_interruptP;
     pending_interruptP_return_0:
      v_971X = pending_interruptP0_return_value;
      if (v_971X) {
        arg0K0 = skip_969X;
        goto L29898;}
      else {
        goto L61006;}}
    else {
      goto L61006;}}
  else {
    template_972X = *((long *) (((char *) (-3 + (SvalS)))));
    arg0K0 = (*((long *) (((char *) (-3 + template_972X)))));
    arg0K1 = skip_969X;
    arg0K2 = template_972X;
    arg0K3 = stack_space_931X;
    goto L33347;}}
 L30675: {
  SvalS = (*((long *) ((((char *) (-3 + handlers_953X))) + (((opcode_952X)<<2)))));
  obj_973X = SvalS;
  if ((3 == (3 & obj_973X))) {
    if ((3 == (31 & ((((*((long *) ((((char *) (-3 + obj_973X))) + -4))))>>2))))) {
      goto L30692;}
    else {
      goto L30772;}}
  else {
    goto L30772;}}
 L30758: {
  merged_arg5K0 = "exception-handlers is not a vector";
  loseD0_return_tag = 0;
  goto loseD0;
 loseD0_return_0:
  goto L30675;}
 L29430: {
  Slast_code_calledS = code_955X;
  Scode_pointerS = ((((char *) (-3 + code_955X))) + used_957X);
  if (((SstackS) < (s48_Sstack_limitS))) {
    interruptP_974X = (s48_Sstack_limitS) == (((char *) -1));
    s48_Sstack_limitS = (Sreal_stack_limitS);
    if (((SstackS) < (Sreal_stack_limitS))) {s48_copy_stack_into_heap();
      if (((SstackS) < (Sreal_stack_limitS))) {
        ps_error("VM's stack is too small (how can this happen?)", 0);
        if (interruptP_974X) {
          goto L29437;}
        else {
          goto L29444;}}
      else {
        if (interruptP_974X) {
          goto L29437;}
        else {
          goto L29444;}}}
    else {
      if (interruptP_974X) {
        goto L29437;}
      else {
        goto L29444;}}}
  else {
    goto L29444;}}
 L60886: {
  final_stack_arg_count_975X = arg0K0;
  if ((stack_arg_count_916X < final_stack_arg_count_975X)) {
    arg0K0 = final_stack_arg_count_975X;
    goto L60890;}
  else {
    arg0K0 = stack_arg_count_916X;
    goto L60890;}}
 L29898: {
  protocol_skip_976X = arg0K0;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((protocol_skip_976X)<<2)));
  x_977X = SvalS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_977X);
  x_978X = *((long *) ((((char *) (-3 + (Scurrent_threadS)))) + 12));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_978X);
  x_979X = Scurrent_threadS;
  addr_980X = (((char *) (-3 + x_979X))) + 12;S48_WRITE_BARRIER(x_979X, addr_980X, 1);
  *((long *) addr_980X) = (long) (1);
  n_981X = Senabled_interruptsS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((n_981X)<<2)));
  code_982X = Sinterrupted_native_call_return_codeS;
  v_983X = ((((ScontS) - (SstackS)))>>2);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((4 + (((v_983X)<<2))));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((long) ((((char *) (-3 + code_982X))) + 13))));
  ScontS = (SstackS);
  goto L29632;}
 L61006: {
  v_984X = s48_call_native_procedure((SvalS), skip_969X);
  arg0K0 = v_984X;
  goto L60019;}
 L33347: {
  code_985X = arg0K0;
  used_986X = arg0K1;
  template_987X = arg0K2;
  needed_stack_space_988X = arg0K3;
  spec_989X = *((unsigned char *) ((((char *) (-3 + code_985X))) + used_986X));
  if ((3 == spec_989X)) {
    x_990X = *((long *) ((((char *) (-3 + (SvalS)))) + 4));
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) (x_990X);
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) (template_987X);
    goto L33351;}
  else {
    if ((1 == spec_989X)) {
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (template_987X);
      goto L33351;}
    else {
      if ((2 == spec_989X)) {
        x_991X = *((long *) ((((char *) (-3 + (SvalS)))) + 4));
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (x_991X);
        goto L33351;}
      else {
        if ((4 == spec_989X)) {
          x_992X = SvalS;
          SstackS = ((SstackS) + -4);
          *((long *) (SstackS)) = (long) (x_992X);
          goto L33351;}
        else {
          if ((6 == spec_989X)) {
            x_993X = SvalS;
            SstackS = ((SstackS) + -4);
            *((long *) (SstackS)) = (long) (x_993X);
            x_994X = *((long *) ((((char *) (-3 + (SvalS)))) + 4));
            SstackS = ((SstackS) + -4);
            *((long *) (SstackS)) = (long) (x_994X);
            goto L33351;}
          else {
            if ((5 == spec_989X)) {
              x_995X = SvalS;
              SstackS = ((SstackS) + -4);
              *((long *) (SstackS)) = (long) (x_995X);
              SstackS = ((SstackS) + -4);
              *((long *) (SstackS)) = (long) (template_987X);
              goto L33351;}
            else {
              if ((7 == spec_989X)) {
                x_996X = SvalS;
                SstackS = ((SstackS) + -4);
                *((long *) (SstackS)) = (long) (x_996X);
                x_997X = *((long *) ((((char *) (-3 + (SvalS)))) + 4));
                SstackS = ((SstackS) + -4);
                *((long *) (SstackS)) = (long) (x_997X);
                SstackS = ((SstackS) + -4);
                *((long *) (SstackS)) = (long) (template_987X);
                goto L33351;}
              else {
                goto L33351;}}}}}}}}
 L30692: {
  arg0K0 = (2 + nargs_951X);
  arg0K1 = 25;
  arg0K2 = 0;
  arg0K3 = opcode_952X;
  goto L60809;}
 L30772: {
  merged_arg5K0 = "exception handler is not a closure";
  loseD0_return_tag = 1;
  goto loseD0;
 loseD0_return_1:
  goto L30692;}
 L29437: {
  pending_interruptP_return_tag = 1;
  goto pending_interruptP;
 pending_interruptP_return_1:
  v_998X = pending_interruptP0_return_value;
  if (v_998X) {
    goto L29809;}
  else {
    goto L29444;}}
 L29444: {
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L60890: {
  v_999X = arg0K0;
  merged_arg0K0 = v_999X;
  merged_arg0K1 = stack_arg_count_916X;
  merged_arg0K2 = list_args_917X;
  merged_arg0K3 = list_arg_count_918X;
  rest_list_setupAgc_return_tag = 1;
  goto rest_list_setupAgc;
 rest_list_setupAgc_return_1:
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((final_stack_arg_count_975X)<<2)));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((total_arg_count_921X)<<2)));
  arg0K0 = skip_968X;
  goto L60839;}
 L29632: {
  n_1000X = (Spending_interruptsS) & (Senabled_interruptsS);
  arg0K0 = 0;
  arg0K1 = 1;
  goto L29685;}
 L60019: {
  tag_1001X = arg0K0;
  arg0K0 = tag_1001X;
  goto L60023;}
 L33351: {
  Slast_code_calledS = code_985X;
  Scode_pointerS = ((((char *) (-3 + code_985X))) + (1 + used_986X));
  merged_arg0K0 = needed_stack_space_988X;
  ensure_stack_spaceB_return_tag = 1;
  goto ensure_stack_spaceB;
 ensure_stack_spaceB_return_1:
  v_1002X = ensure_stack_spaceB0_return_value;
  if (v_1002X) {
    pending_interruptP_return_tag = 2;
    goto pending_interruptP;
   pending_interruptP_return_2:
    v_1003X = pending_interruptP0_return_value;
    if (v_1003X) {
      goto L29809;}
    else {
      goto L33365;}}
  else {
    goto L33365;}}
 L29809: {
  x_1004X = SvalS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1004X);
  code_1005X = current_code_vector();
  pc_1006X = (Scode_pointerS) - (((char *) (-3 + code_1005X)));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (code_1005X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((pc_1006X)<<2)));
  x_1007X = *((long *) ((((char *) (-3 + (Scurrent_threadS)))) + 12));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1007X);
  x_1008X = Scurrent_threadS;
  addr_1009X = (((char *) (-3 + x_1008X))) + 12;S48_WRITE_BARRIER(x_1008X, addr_1009X, 1);
  *((long *) addr_1009X) = (long) (1);
  n_1010X = Senabled_interruptsS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((n_1010X)<<2)));
  code_1011X = Sinterrupted_byte_opcode_return_codeS;
  v_1012X = ((((ScontS) - (SstackS)))>>2);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((4 + (((v_1012X)<<2))));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((long) ((((char *) (-3 + code_1011X))) + 13))));
  ScontS = (SstackS);
  goto L29632;}
 L32913: {
  code_pointer_1013X = arg3K0;
  switch ((*((unsigned char *) code_pointer_1013X))) {
    case 0 : 
    case 31 : 
    case 42 : {push_exception_setupB(14, 1);
      n_1014X = *((unsigned char *) (Scode_pointerS));
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) ((((n_1014X)<<2)));
      arg0K0 = 1;
      goto L30610;}
      break;
    case 1 : {
      SvalS = (-512 + ((((*((unsigned char *) ((Scode_pointerS) + 1))))<<2)));
      Scode_pointerS = ((Scode_pointerS) + 2);
      arg3K0 = (Scode_pointerS);
      goto L32913;}
      break;
    case 2 : {
      x_1015X = SvalS;
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (x_1015X);
      SvalS = (-512 + ((((*((unsigned char *) ((Scode_pointerS) + 1))))<<2)));
      Scode_pointerS = ((Scode_pointerS) + 2);
      arg3K0 = (Scode_pointerS);
      goto L32913;}
      break;
    case 3 : {
      x_1016X = -512 + ((((*((unsigned char *) ((Scode_pointerS) + 1))))<<2));
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (x_1016X);
      Scode_pointerS = ((Scode_pointerS) + 2);
      arg3K0 = (Scode_pointerS);
      goto L32913;}
      break;
    case 4 : {
      template_1017X = *((long *) ((SstackS) + ((((((((*((unsigned char *) ((Scode_pointerS) + 1))))<<8)) + (*((unsigned char *) ((Scode_pointerS) + 2)))))<<2))));
      index_1018X = ((((*((unsigned char *) ((Scode_pointerS) + 3))))<<8)) + (*((unsigned char *) ((Scode_pointerS) + 4)));
      location_1019X = *((long *) ((((char *) (-3 + template_1017X))) + (((index_1018X)<<2))));
      SvalS = (*((long *) ((((char *) (-3 + location_1019X))) + 4)));
      if ((17 == (255 & (SvalS)))) {push_exception_setupB(1, 5);
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (location_1019X);
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (template_1017X);
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) ((((index_1018X)<<2)));
        arg0K0 = 3;
        goto L30610;}
      else {
        Scode_pointerS = ((Scode_pointerS) + 5);
        arg3K0 = (Scode_pointerS);
        goto L32913;}}
      break;
    case 5 : {
      template_1020X = *((long *) ((SstackS) + ((((((((*((unsigned char *) ((Scode_pointerS) + 1))))<<8)) + (*((unsigned char *) ((Scode_pointerS) + 2)))))<<2))));
      index_1021X = ((((*((unsigned char *) ((Scode_pointerS) + 3))))<<8)) + (*((unsigned char *) ((Scode_pointerS) + 4)));
      location_1022X = *((long *) ((((char *) (-3 + template_1020X))) + (((index_1021X)<<2))));
      if ((273 == (*((long *) ((((char *) (-3 + location_1022X))) + 4))))) {push_exception_setupB(1, 5);
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (location_1022X);
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (template_1020X);
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) ((((index_1021X)<<2)));
        x_1023X = SvalS;
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (x_1023X);
        arg0K0 = 4;
        goto L30610;}
      else {
        val_1024X = SvalS;
        addr_1025X = (((char *) (-3 + location_1022X))) + 4;S48_WRITE_BARRIER(location_1022X, addr_1025X, val_1024X);
        *((long *) addr_1025X) = (long) (val_1024X);
        SvalS = 13;
        Scode_pointerS = ((Scode_pointerS) + 5);
        arg3K0 = (Scode_pointerS);
        goto L32913;}}
      break;
    case 6 : {
      total_count_1026X = *((unsigned char *) ((Scode_pointerS) + 1));
      closures_1027X = *((unsigned char *) ((Scode_pointerS) + 2));s48_make_availableAgc((((((1 + total_count_1026X) + (3 * closures_1027X)))<<2)));
      len_1028X = ((total_count_1026X)<<2);
      addr_1029X = s48_allocate_small((4 + len_1028X));
      *((long *) addr_1029X) = (long) ((10 + (((len_1028X)<<8))));
      new_env_1030X = 3 + (((long) (addr_1029X + 4)));
      if ((0 == closures_1027X)) {
        arg0K0 = new_env_1030X;
        arg0K1 = 0;
        arg0K2 = 2;
        arg0K3 = total_count_1026X;
        goto L12300;}
      else {
        template_1031X = *((long *) ((SstackS) + ((((*((unsigned char *) ((Scode_pointerS) + 3))))<<2))));
        arg0K0 = closures_1027X;
        arg0K1 = 0;
        arg0K2 = 3;
        goto L22869;}}
      break;
    case 7 : {
      total_count_1032X = ((((*((unsigned char *) ((Scode_pointerS) + 1))))<<8)) + (*((unsigned char *) ((Scode_pointerS) + 2)));
      closures_1033X = ((((*((unsigned char *) ((Scode_pointerS) + 3))))<<8)) + (*((unsigned char *) ((Scode_pointerS) + 4)));s48_make_availableAgc((((((1 + total_count_1032X) + (3 * closures_1033X)))<<2)));
      len_1034X = ((total_count_1032X)<<2);
      addr_1035X = s48_allocate_small((4 + len_1034X));
      *((long *) addr_1035X) = (long) ((10 + (((len_1034X)<<8))));
      new_env_1036X = 3 + (((long) (addr_1035X + 4)));
      if ((0 == closures_1033X)) {
        arg0K0 = new_env_1036X;
        arg0K1 = 0;
        arg0K2 = 4;
        arg0K3 = total_count_1032X;
        goto L15050;}
      else {
        template_1037X = *((long *) ((SstackS) + ((((((((*((unsigned char *) ((Scode_pointerS) + 5))))<<8)) + (*((unsigned char *) ((Scode_pointerS) + 6)))))<<2))));
        arg0K0 = closures_1033X;
        arg0K1 = 0;
        arg0K2 = 6;
        goto L22930;}}
      break;
    case 8 : {
      x_1038X = SvalS;
      x_1039X = *((long *) ((SstackS) + ((((*((unsigned char *) ((Scode_pointerS) + 1))))<<2))));
      addr_1040X = (((char *) (-3 + x_1039X))) + ((((*((unsigned char *) ((Scode_pointerS) + 2))))<<2));S48_WRITE_BARRIER(x_1039X, addr_1040X, x_1038X);
      *((long *) addr_1040X) = (long) (x_1038X);
      SvalS = 13;
      Scode_pointerS = ((Scode_pointerS) + 3);
      arg3K0 = (Scode_pointerS);
      goto L32913;}
      break;
    case 9 : {
      value_1041X = SvalS;
      x_1042X = *((long *) ((SstackS) + ((((((((*((unsigned char *) ((Scode_pointerS) + 1))))<<8)) + (*((unsigned char *) ((Scode_pointerS) + 2)))))<<2))));
      addr_1043X = (((char *) (-3 + x_1042X))) + ((((((((*((unsigned char *) ((Scode_pointerS) + 2))))<<8)) + (*((unsigned char *) ((Scode_pointerS) + 3)))))<<2));S48_WRITE_BARRIER(x_1042X, addr_1043X, value_1041X);
      *((long *) addr_1043X) = (long) (value_1041X);
      SvalS = 13;
      Scode_pointerS = ((Scode_pointerS) + 5);
      arg3K0 = (Scode_pointerS);
      goto L32913;}
      break;
    case 10 : {
      SvalS = (*((long *) ((((char *) (-3 + (*((long *) ((SstackS) + ((((*((unsigned char *) ((Scode_pointerS) + 1))))<<2)))))))) + ((((*((unsigned char *) ((Scode_pointerS) + 2))))<<2)))));
      Scode_pointerS = ((Scode_pointerS) + 3);
      arg3K0 = (Scode_pointerS);
      goto L32913;}
      break;
    case 11 : {
      SvalS = (*((long *) ((((char *) (-3 + (*((long *) ((SstackS) + ((((((((*((unsigned char *) ((Scode_pointerS) + 1))))<<8)) + (*((unsigned char *) ((Scode_pointerS) + 2)))))<<2)))))))) + ((((((((*((unsigned char *) ((Scode_pointerS) + 3))))<<8)) + (*((unsigned char *) ((Scode_pointerS) + 4)))))<<2)))));
      Scode_pointerS = ((Scode_pointerS) + 5);
      arg3K0 = (Scode_pointerS);
      goto L32913;}
      break;
    case 12 : {
      free_count_1044X = ((((*((unsigned char *) ((Scode_pointerS) + 1))))<<8)) + (*((unsigned char *) ((Scode_pointerS) + 2)));
      size_1045X = 1 + free_count_1044X;s48_make_availableAgc((4 + (((size_1045X)<<2))));
      len_1046X = ((size_1045X)<<2);
      addr_1047X = s48_allocate_small((4 + len_1046X));
      *((long *) addr_1047X) = (long) ((14 + (((len_1046X)<<8))));
      closure_1048X = 3 + (((long) (addr_1047X + 4)));
      *((long *) (((char *) (-3 + closure_1048X)))) = (long) ((SvalS));
      arg0K0 = free_count_1044X;
      goto L35554;}
      break;
    case 13 : {
      x_1049X = SvalS;
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (x_1049X);
      Scode_pointerS = ((Scode_pointerS) + 1);
      arg3K0 = (Scode_pointerS);
      goto L32913;}
      break;
    case 14 : {
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (1);
      Scode_pointerS = ((Scode_pointerS) + 1);
      arg3K0 = (Scode_pointerS);
      goto L32913;}
      break;
    case 15 : {
      value_1050X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      SvalS = value_1050X;
      Scode_pointerS = ((Scode_pointerS) + 1);
      arg3K0 = (Scode_pointerS);
      goto L32913;}
      break;
    case 16 : {
      SstackS = ((SstackS) + (0 - ((((0 - (((((*((unsigned char *) ((Scode_pointerS) + 1))))<<8)) + (*((unsigned char *) ((Scode_pointerS) + 2))))))<<2))));
      Scode_pointerS = ((Scode_pointerS) + 3);
      arg3K0 = (Scode_pointerS);
      goto L32913;}
      break;
    case 17 : {
      arg0K0 = (((((*((unsigned char *) ((Scode_pointerS) + 1))))<<8)) + (*((unsigned char *) ((Scode_pointerS) + 2))));
      goto L61734;}
      break;
    case 18 : {
      SvalS = (*((long *) ((SstackS) + ((((*((unsigned char *) ((Scode_pointerS) + 1))))<<2)))));
      Scode_pointerS = ((Scode_pointerS) + 2);
      arg3K0 = (Scode_pointerS);
      goto L32913;}
      break;
    case 19 : {
      x_1051X = SvalS;
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (x_1051X);
      SvalS = (*((long *) ((SstackS) + ((((*((unsigned char *) ((Scode_pointerS) + 1))))<<2)))));
      Scode_pointerS = ((Scode_pointerS) + 2);
      arg3K0 = (Scode_pointerS);
      goto L32913;}
      break;
    case 20 : {
      x_1052X = *((long *) ((SstackS) + ((((*((unsigned char *) ((Scode_pointerS) + 1))))<<2))));
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (x_1052X);
      Scode_pointerS = ((Scode_pointerS) + 2);
      arg3K0 = (Scode_pointerS);
      goto L32913;}
      break;
    case 21 : {
      SvalS = (*((long *) ((SstackS) + ((((((((*((unsigned char *) ((Scode_pointerS) + 1))))<<8)) + (*((unsigned char *) ((Scode_pointerS) + 2)))))<<2)))));
      Scode_pointerS = ((Scode_pointerS) + 3);
      arg3K0 = (Scode_pointerS);
      goto L32913;}
      break;
    case 22 : {
      *((long *) ((SstackS) + ((((*((unsigned char *) ((Scode_pointerS) + 1))))<<2)))) = (long) ((SvalS));
      Scode_pointerS = ((Scode_pointerS) + 2);
      arg3K0 = (Scode_pointerS);
      goto L32913;}
      break;
    case 23 : {
      *((long *) ((SstackS) + ((((((((*((unsigned char *) ((Scode_pointerS) + 1))))<<8)) + (*((unsigned char *) ((Scode_pointerS) + 2)))))<<2)))) = (long) ((SvalS));
      Scode_pointerS = ((Scode_pointerS) + 3);
      arg3K0 = (Scode_pointerS);
      goto L32913;}
      break;
    case 24 : {
      SvalS = (*((long *) ((((char *) (-3 + (*((long *) ((SstackS) + ((((*((unsigned char *) ((Scode_pointerS) + 1))))<<2)))))))) + ((((*((unsigned char *) ((Scode_pointerS) + 2))))<<2)))));
      Scode_pointerS = ((Scode_pointerS) + 3);
      arg3K0 = (Scode_pointerS);
      goto L32913;}
      break;
    case 25 : {
      x_1053X = SvalS;
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (x_1053X);
      SvalS = (*((long *) ((((char *) (-3 + (*((long *) ((SstackS) + ((((*((unsigned char *) ((Scode_pointerS) + 1))))<<2)))))))) + ((((*((unsigned char *) ((Scode_pointerS) + 2))))<<2)))));
      Scode_pointerS = ((Scode_pointerS) + 3);
      arg3K0 = (Scode_pointerS);
      goto L32913;}
      break;
    case 26 : {
      x_1054X = *((long *) ((((char *) (-3 + (*((long *) ((SstackS) + ((((*((unsigned char *) ((Scode_pointerS) + 1))))<<2)))))))) + ((((*((unsigned char *) ((Scode_pointerS) + 2))))<<2))));
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (x_1054X);
      Scode_pointerS = ((Scode_pointerS) + 3);
      arg3K0 = (Scode_pointerS);
      goto L32913;}
      break;
    case 27 : {
      SvalS = (*((long *) ((((char *) (-3 + (*((long *) ((SstackS) + ((((((((*((unsigned char *) ((Scode_pointerS) + 1))))<<8)) + (*((unsigned char *) ((Scode_pointerS) + 2)))))<<2)))))))) + ((((((((*((unsigned char *) ((Scode_pointerS) + 3))))<<8)) + (*((unsigned char *) ((Scode_pointerS) + 4)))))<<2)))));
      Scode_pointerS = ((Scode_pointerS) + 5);
      arg3K0 = (Scode_pointerS);
      goto L32913;}
      break;
    case 28 : {
      x_1055X = SvalS;
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (x_1055X);
      n_moves_1056X = *((unsigned char *) ((Scode_pointerS) + 1));
      arg0K0 = 0;
      goto L34888;}
      break;
    case 29 : {
      x_1057X = SvalS;
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (x_1057X);
      n_moves_1058X = ((((*((unsigned char *) ((Scode_pointerS) + 1))))<<8)) + (*((unsigned char *) ((Scode_pointerS) + 2)));
      arg0K0 = 0;
      goto L34805;}
      break;
    case 30 : {s48_make_availableAgc(((((-4 & ((Sstack_endS) - (SstackS))))<<2)));
      if ((1 == (((long) (ScontS))))) {
        arg0K0 = 1;
        goto L61803;}
      else {
        v_1059X = really_preserve_continuation(0);
        arg0K0 = v_1059X;
        goto L61803;}}
      break;
    case 32 : {
      stack_arg_count_1060X = *((unsigned char *) ((Scode_pointerS) + 3));
      code_pointer_1061X = (Scode_pointerS) + (((((*((unsigned char *) ((Scode_pointerS) + 1))))<<8)) + (*((unsigned char *) ((Scode_pointerS) + 2))));
      ScontS = ((SstackS) + (((stack_arg_count_1060X)<<2)));
      *((long *) (ScontS)) = (long) ((((long) code_pointer_1061X)));
      arg0K0 = stack_arg_count_1060X;
      goto L60736;}
      break;
    case 33 : {
      merged_arg0K0 = (*((unsigned char *) ((Scode_pointerS) + 1)));
      move_args_above_contB_return_tag = 0;
      goto move_args_above_contB;
     move_args_above_contB_return_0:
      arg0K0 = (*((unsigned char *) ((Scode_pointerS) + 1)));
      goto L60736;}
      break;
    case 34 : {
      stack_arg_count_1062X = ((((*((unsigned char *) ((Scode_pointerS) + 3))))<<8)) + (*((unsigned char *) ((Scode_pointerS) + 4)));
      return_pointer_offset_1063X = ((((*((unsigned char *) ((Scode_pointerS) + 1))))<<8)) + (*((unsigned char *) ((Scode_pointerS) + 2)));
      if ((0 == return_pointer_offset_1063X)) {
        merged_arg0K0 = stack_arg_count_1062X;
        move_args_above_contB_return_tag = 1;
        goto move_args_above_contB;
       move_args_above_contB_return_1:
        goto L30413;}
      else {
        code_pointer_1064X = (Scode_pointerS) + return_pointer_offset_1063X;
        ScontS = ((SstackS) + (((stack_arg_count_1062X)<<2)));
        *((long *) (ScontS)) = (long) ((((long) code_pointer_1064X)));
        goto L30413;}}
      break;
    case 35 : {
      v_1065X = (s48_Sstack_limitS) == (((char *) -1));
      if (v_1065X) {
        pending_interruptP_return_tag = 3;
        goto pending_interruptP;
       pending_interruptP_return_3:
        v_1066X = pending_interruptP0_return_value;
        if (v_1066X) {
          goto L29809;}
        else {
          goto L61829;}}
      else {
        goto L61829;}}
      break;
    case 36 : {
      list_args_1067X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      stack_nargs_1068X = ((((*((unsigned char *) ((Scode_pointerS) + 3))))<<8)) + (*((unsigned char *) ((Scode_pointerS) + 4)));
      merged_arg0K0 = list_args_1067X;
      okay_argument_list_return_tag = 0;
      goto okay_argument_list;
     okay_argument_list_return_0:
      okayP_1069X = okay_argument_list0_return_value;
      length_1070X = okay_argument_list1_return_value;
      if (okayP_1069X) {
        return_pointer_offset_1071X = ((((*((unsigned char *) ((Scode_pointerS) + 1))))<<8)) + (*((unsigned char *) ((Scode_pointerS) + 2)));
        if ((0 == return_pointer_offset_1071X)) {
          merged_arg0K0 = stack_nargs_1068X;
          move_args_above_contB_return_tag = 2;
          goto move_args_above_contB;
         move_args_above_contB_return_2:
          arg0K0 = stack_nargs_1068X;
          arg0K1 = list_args_1067X;
          arg0K2 = length_1070X;
          goto L59760;}
        else {
          code_pointer_1072X = (Scode_pointerS) + return_pointer_offset_1071X;
          ScontS = ((SstackS) + (((stack_nargs_1068X)<<2)));
          *((long *) (ScontS)) = (long) ((((long) code_pointer_1072X)));
          arg0K0 = stack_nargs_1068X;
          arg0K1 = list_args_1067X;
          arg0K2 = length_1070X;
          goto L59760;}}
      else {
        merged_arg0K0 = list_args_1067X;
        merged_arg0K1 = stack_nargs_1068X;
        pop_args_GlistSAgc_return_tag = 1;
        goto pop_args_GlistSAgc;
       pop_args_GlistSAgc_return_1:
        args_1073X = pop_args_GlistSAgc0_return_value;push_exception_setupB(5, 0);
        x_1074X = SvalS;
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (x_1074X);
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (args_1073X);
        arg0K0 = 2;
        goto L30610;}}
      break;
    case 37 : {
      SstackS = ((SstackS) + 4);
      p_1075X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      stack_nargs_1076X = ((p_1075X)>>2);
      SvalS = (*((long *) ((SstackS) + (((stack_nargs_1076X)<<2)))));
      merged_arg0K0 = stack_nargs_1076X;
      move_args_above_contB_return_tag = 3;
      goto move_args_above_contB;
     move_args_above_contB_return_3:
      rest_list_1077X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      if ((25 == rest_list_1077X)) {
        v_1078X = *((long *) (SstackS));
        SstackS = ((SstackS) + 4);
        arg0K0 = v_1078X;
        arg0K1 = (-2 + stack_nargs_1076X);
        goto L21835;}
      else {
        if ((25 == (*((long *) ((((char *) (-3 + rest_list_1077X))) + 4))))) {
          arg0K0 = (*((long *) (((char *) (-3 + rest_list_1077X)))));
          arg0K1 = (-1 + stack_nargs_1076X);
          goto L21835;}
        else {
          arg0K0 = (*((long *) ((((char *) (-3 + (*((long *) ((((char *) (-3 + rest_list_1077X))) + 4)))))) + 4)));
          arg0K1 = rest_list_1077X;
          goto L21880;}}}
      break;
    case 38 : {
      cont_1079X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      if ((3 == (3 & cont_1079X))) {
        if ((10 == (31 & ((((*((long *) ((((char *) (-3 + cont_1079X))) + -4))))>>2))))) {
          merged_arg0K0 = cont_1079X;
          merged_arg0K1 = 0;
          copy_continuation_from_heapB_return_tag = 0;
          goto copy_continuation_from_heapB;
         copy_continuation_from_heapB_return_0:
          goto L30371;}
        else {
          goto L30380;}}
      else {
        goto L30380;}}
      break;
    case 39 : {
      goto L60347;}
      break;
    case 40 : {
      arg0K0 = (((((*((unsigned char *) ((Scode_pointerS) + 1))))<<8)) + (*((unsigned char *) ((Scode_pointerS) + 2))));
      arg0K1 = 25;
      arg0K2 = 0;
      goto L30038;}
      break;
    case 41 : {
      p_1080X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      p_1081X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      stack_nargs_1082X = ((p_1081X)>>2);
      rest_list_1083X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      arg0K0 = stack_nargs_1082X;
      arg0K1 = rest_list_1083X;
      arg0K2 = ((((p_1080X)>>2)) - stack_nargs_1082X);
      goto L30038;}
      break;
    case 43 : {
      template_1084X = *((long *) ((((char *) (-3 + (*((long *) ((SstackS) + ((((((((*((unsigned char *) ((Scode_pointerS) + 3))))<<8)) + (*((unsigned char *) ((Scode_pointerS) + 4)))))<<2)))))))) + ((((((((*((unsigned char *) ((Scode_pointerS) + 5))))<<8)) + (*((unsigned char *) ((Scode_pointerS) + 6)))))<<2))));
      code_1085X = *((long *) (((char *) (-3 + template_1084X))));
      nargs_1086X = *((unsigned char *) ((Scode_pointerS) + 7));
      return_pointer_offset_1087X = ((((*((unsigned char *) ((Scode_pointerS) + 1))))<<8)) + (*((unsigned char *) ((Scode_pointerS) + 2)));
      if ((0 == return_pointer_offset_1087X)) {
        merged_arg0K0 = nargs_1086X;
        move_args_above_contB_return_tag = 4;
        goto move_args_above_contB;
       move_args_above_contB_return_4:
        goto L34539;}
      else {
        code_pointer_1088X = (Scode_pointerS) + return_pointer_offset_1087X;
        ScontS = ((SstackS) + (((nargs_1086X)<<2)));
        *((long *) (ScontS)) = (long) ((((long) code_pointer_1088X)));
        goto L34539;}}
      break;
    case 44 : {
      if ((1 == (SvalS))) {
        Scode_pointerS = ((Scode_pointerS) + (((((*((unsigned char *) ((Scode_pointerS) + 1))))<<8)) + (*((unsigned char *) ((Scode_pointerS) + 2)))));
        arg3K0 = (Scode_pointerS);
        goto L32913;}
      else {
        Scode_pointerS = ((Scode_pointerS) + 3);
        arg3K0 = (Scode_pointerS);
        goto L32913;}}
      break;
    case 45 : {
      Scode_pointerS = ((Scode_pointerS) + (((((*((unsigned char *) ((Scode_pointerS) + 1))))<<8)) + (*((unsigned char *) ((Scode_pointerS) + 2)))));
      arg3K0 = (Scode_pointerS);
      goto L32913;}
      break;
    case 46 : {
      Scode_pointerS = ((Scode_pointerS) + (0 - (((((*((unsigned char *) ((Scode_pointerS) + 1))))<<8)) + (*((unsigned char *) ((Scode_pointerS) + 2))))));
      arg3K0 = (Scode_pointerS);
      goto L32913;}
      break;
    case 47 : {
      if ((0 == (3 & (SvalS)))) {
        p_1089X = SvalS;
        max_1090X = *((unsigned char *) ((Scode_pointerS) + 1));
        val_1091X = ((p_1089X)>>2);
        if ((val_1091X < 0)) {
          goto L33222;}
        else {
          if ((val_1091X < max_1090X)) {
            index_1092X = 1 + (((val_1091X)<<1));
            arg0K0 = (((((*((unsigned char *) ((Scode_pointerS) + (1 + index_1092X)))))<<8)) + (*((unsigned char *) ((Scode_pointerS) + (2 + index_1092X)))));
            goto L33224;}
          else {
            goto L33222;}}}
      else {push_exception_setupB(5, 0);
        x_1093X = SvalS;
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (x_1093X);
        arg0K0 = 1;
        goto L30610;}}
      break;
    case 48 : {
      stack_nargs_1094X = (((*((long *) (SstackS))))>>2);
      if ((0 == stack_nargs_1094X)) {
        rest_list_1095X = *((long *) ((SstackS) + 4));
        arg0_1096X = *((long *) ((SstackS) + 8));
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (arg0_1096X);
        SvalS = (*((long *) (((char *) (-3 + rest_list_1095X)))));
        goto L33811;}
      else {
        arg0_1097X = *((long *) ((SstackS) + (4 + (((stack_nargs_1094X)<<2)))));
        arg1_1098X = *((long *) ((SstackS) + (((stack_nargs_1094X)<<2))));
        *((long *) ((SstackS) + (4 + (((stack_nargs_1094X)<<2))))) = (long) (1);
        *((long *) (SstackS)) = (long) ((-4 + (((stack_nargs_1094X)<<2))));
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (arg0_1097X);
        SvalS = arg1_1098X;
        goto L33811;}}
      break;
    case 49 : {
      stack_nargs_1099X = (((*((long *) (SstackS))))>>2);
      if ((stack_nargs_1099X == 0)) {
        rest_list_1100X = *((long *) ((SstackS) + 4));
        if ((25 == (*((long *) ((((char *) (-3 + rest_list_1100X))) + 4))))) {
          arg0K0 = 1;
          goto L33120;}
        else {
          *((long *) ((SstackS) + 4)) = (long) ((*((long *) ((((char *) (-3 + rest_list_1100X))) + 4))));
          *((long *) ((SstackS) + 8)) = (long) ((SvalS));
          arg0K0 = -2;
          goto L33120;}}
      else {
        if ((stack_nargs_1099X == 1)) {
          if ((25 == (*((long *) ((SstackS) + 4))))) {
            arg0K0 = 1;
            goto L33120;}
          else {
            *((long *) (SstackS)) = (long) (0);
            *((long *) ((SstackS) + 8)) = (long) ((SvalS));
            arg0K0 = -2;
            goto L33120;}}
        else {
          *((long *) ((SstackS) + (4 + (((stack_nargs_1099X)<<2))))) = (long) ((SvalS));
          arg0K0 = -2;
          goto L33120;}}}
      break;
    case 50 : {
      if ((1 == (SvalS))) {
        Scode_pointerS = ((Scode_pointerS) + 1);
        arg3K0 = (Scode_pointerS);
        goto L32913;}
      else {
        x_1101X = (((*((long *) (SstackS))))>>2);
        if ((x_1101X == 0)) {
          rest_list_1102X = *((long *) ((SstackS) + 4));
          if ((25 == (*((long *) ((((char *) (-3 + rest_list_1102X))) + 4))))) {
            arg0K0 = 1;
            goto L33702;}
          else {
            *((long *) ((SstackS) + 4)) = (long) ((*((long *) ((((char *) (-3 + rest_list_1102X))) + 4))));
            *((long *) ((SstackS) + 8)) = (long) ((*((long *) (((char *) (-3 + rest_list_1102X))))));
            arg0K0 = -2;
            goto L33702;}}
        else {
          if ((x_1101X == 1)) {
            if ((25 == (*((long *) ((SstackS) + 4))))) {
              arg0K0 = 1;
              goto L33702;}
            else {
              *((long *) (SstackS)) = (long) (0);
              arg0K0 = -2;
              goto L33702;}}
          else {
            arg0K0 = -2;
            goto L33702;}}}}
      break;
    case 51 : {
      arg2_1103X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      x_1104X = SvalS;
      if ((arg2_1103X == x_1104X)) {
        arg0K0 = 5;
        goto L61874;}
      else {
        arg0K0 = 1;
        goto L61874;}}
      break;
    case 52 : {
      x_1105X = SvalS;
      if ((0 == (3 & x_1105X))) {
        arg0K0 = 5;
        goto L61886;}
      else {
        if ((3 == (3 & x_1105X))) {
          if ((19 == (31 & ((((*((long *) ((((char *) (-3 + x_1105X))) + -4))))>>2))))) {
            arg0K0 = 5;
            goto L61886;}
          else {
            goto L19484;}}
        else {
          goto L19484;}}}
      break;
    case 53 : {
      n_1106X = SvalS;
      if ((0 == (3 & n_1106X))) {
        goto L51217;}
      else {
        if ((3 == (3 & n_1106X))) {
          if ((19 == (31 & ((((*((long *) ((((char *) (-3 + n_1106X))) + -4))))>>2))))) {
            goto L51217;}
          else {
            goto L51218;}}
        else {
          goto L51218;}}}
      break;
    case 54 : {
      arg0K0 = (SvalS);
      goto L51351;}
      break;
    case 55 : {
      arg0K0 = (SvalS);
      goto L51351;}
      break;
    case 56 : {
      arg0K0 = (SvalS);
      goto L51351;}
      break;
    case 57 : {
      n_1107X = SvalS;
      if ((0 == (3 & n_1107X))) {
        goto L43771;}
      else {
        if ((3 == (3 & n_1107X))) {
          if ((19 == (31 & ((((*((long *) ((((char *) (-3 + n_1107X))) + -4))))>>2))))) {
            goto L43771;}
          else {
            goto L43772;}}
        else {
          goto L43772;}}}
      break;
    case 58 : {
      x_1108X = SvalS;push_exception_setupB(5, 1);
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (x_1108X);
      arg0K0 = 1;
      goto L30610;}
      break;
    case 59 : {
      x_1109X = SvalS;push_exception_setupB(5, 1);
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (x_1109X);
      arg0K0 = 1;
      goto L30610;}
      break;
    case 60 : {
      arg2_1110X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      y_1111X = SvalS;
      if ((0 == (3 & (arg2_1110X | y_1111X)))) {s48_make_availableAgc(16);
        x_1112X = (((arg2_1110X)>>2)) + (((y_1111X)>>2));
        if ((536870911 < x_1112X)) {
          goto L43897;}
        else {
          if ((x_1112X < -536870912)) {
            goto L43897;}
          else {
            arg0K0 = (((x_1112X)<<2));
            goto L43843;}}}
      else {
        if ((0 == (3 & arg2_1110X))) {
          goto L43849;}
        else {
          if ((3 == (3 & arg2_1110X))) {
            if ((19 == (31 & ((((*((long *) ((((char *) (-3 + arg2_1110X))) + -4))))>>2))))) {
              goto L43849;}
            else {
              goto L43858;}}
          else {
            goto L43858;}}}}
      break;
    case 61 : {
      arg2_1113X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      y_1114X = SvalS;
      if ((0 == (3 & (arg2_1113X | y_1114X)))) {
        a_1115X = ((arg2_1113X)>>2);
        b_1116X = ((y_1114X)>>2);
        if ((a_1115X < 0)) {
          arg0K0 = (0 - a_1115X);
          goto L12549;}
        else {
          arg0K0 = a_1115X;
          goto L12549;}}
      else {
        if ((0 == (3 & arg2_1113X))) {
          goto L53124;}
        else {
          if ((3 == (3 & arg2_1113X))) {
            if ((19 == (31 & ((((*((long *) ((((char *) (-3 + arg2_1113X))) + -4))))>>2))))) {
              goto L53124;}
            else {
              goto L53133;}}
          else {
            goto L53133;}}}}
      break;
    case 62 : {
      arg2_1117X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      y_1118X = SvalS;
      if ((0 == (3 & (arg2_1117X | y_1118X)))) {s48_make_availableAgc(16);
        x_1119X = (((arg2_1117X)>>2)) - (((y_1118X)>>2));
        if ((536870911 < x_1119X)) {
          goto L44186;}
        else {
          if ((x_1119X < -536870912)) {
            goto L44186;}
          else {
            arg0K0 = (((x_1119X)<<2));
            goto L44132;}}}
      else {
        if ((0 == (3 & arg2_1117X))) {
          goto L44138;}
        else {
          if ((3 == (3 & arg2_1117X))) {
            if ((19 == (31 & ((((*((long *) ((((char *) (-3 + arg2_1117X))) + -4))))>>2))))) {
              goto L44138;}
            else {
              goto L44147;}}
          else {
            goto L44147;}}}}
      break;
    case 63 : {
      arg2_1120X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      y_1121X = SvalS;
      if ((0 == y_1121X)) {push_exception_setupB(5, 1);
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (arg2_1120X);
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (y_1121X);
        arg0K0 = 2;
        goto L30610;}
      else {
        if ((0 == (3 & (arg2_1120X | y_1121X)))) {
          if ((0 == y_1121X)) {push_exception_setupB(5, 1);
            SstackS = ((SstackS) + -4);
            *((long *) (SstackS)) = (long) (arg2_1120X);
            SstackS = ((SstackS) + -4);
            *((long *) (SstackS)) = (long) (y_1121X);
            arg0K0 = 2;
            goto L30610;}
          else {
            a_1122X = ((arg2_1120X)>>2);
            b_1123X = ((y_1121X)>>2);
            if ((a_1122X < 0)) {
              arg0K0 = (0 - a_1122X);
              goto L12807;}
            else {
              arg0K0 = a_1122X;
              goto L12807;}}}
        else {
          if ((0 == (3 & arg2_1120X))) {
            goto L53377;}
          else {
            if ((3 == (3 & arg2_1120X))) {
              if ((19 == (31 & ((((*((long *) ((((char *) (-3 + arg2_1120X))) + -4))))>>2))))) {
                goto L53377;}
              else {
                goto L53414;}}
            else {
              goto L53414;}}}}}
      break;
    case 64 : {
      arg2_1124X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      y_1125X = SvalS;
      if ((0 == (3 & (arg2_1124X | y_1125X)))) {
        if ((arg2_1124X == y_1125X)) {
          arg0K0 = 5;
          goto L44417;}
        else {
          arg0K0 = 1;
          goto L44417;}}
      else {
        if ((0 == (3 & arg2_1124X))) {
          goto L44423;}
        else {
          if ((3 == (3 & arg2_1124X))) {
            if ((19 == (31 & ((((*((long *) ((((char *) (-3 + arg2_1124X))) + -4))))>>2))))) {
              goto L44423;}
            else {
              goto L44434;}}
          else {
            goto L44434;}}}}
      break;
    case 65 : {
      arg2_1126X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      y_1127X = SvalS;
      if ((0 == (3 & (arg2_1126X | y_1127X)))) {
        if ((arg2_1126X < y_1127X)) {
          arg0K0 = 5;
          goto L44677;}
        else {
          arg0K0 = 1;
          goto L44677;}}
      else {
        if ((0 == (3 & arg2_1126X))) {
          goto L44683;}
        else {
          if ((3 == (3 & arg2_1126X))) {
            if ((19 == (31 & ((((*((long *) ((((char *) (-3 + arg2_1126X))) + -4))))>>2))))) {
              goto L44683;}
            else {
              goto L44694;}}
          else {
            goto L44694;}}}}
      break;
    case 66 : {
      arg2_1128X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      y_1129X = SvalS;
      if ((0 == (3 & (arg2_1128X | y_1129X)))) {
        if ((y_1129X < arg2_1128X)) {
          arg0K0 = 5;
          goto L45000;}
        else {
          arg0K0 = 1;
          goto L45000;}}
      else {
        if ((0 == (3 & arg2_1128X))) {
          goto L45006;}
        else {
          if ((3 == (3 & arg2_1128X))) {
            if ((19 == (31 & ((((*((long *) ((((char *) (-3 + arg2_1128X))) + -4))))>>2))))) {
              goto L45006;}
            else {
              goto L45017;}}
          else {
            goto L45017;}}}}
      break;
    case 67 : {
      arg2_1130X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      y_1131X = SvalS;
      if ((0 == (3 & (arg2_1130X | y_1131X)))) {
        if ((y_1131X < arg2_1130X)) {
          arg0K0 = 1;
          goto L45323;}
        else {
          arg0K0 = 5;
          goto L45323;}}
      else {
        if ((0 == (3 & arg2_1130X))) {
          goto L45329;}
        else {
          if ((3 == (3 & arg2_1130X))) {
            if ((19 == (31 & ((((*((long *) ((((char *) (-3 + arg2_1130X))) + -4))))>>2))))) {
              goto L45329;}
            else {
              goto L45340;}}
          else {
            goto L45340;}}}}
      break;
    case 68 : {
      arg2_1132X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      y_1133X = SvalS;
      if ((0 == (3 & (arg2_1132X | y_1133X)))) {
        if ((arg2_1132X < y_1133X)) {
          arg0K0 = 1;
          goto L45617;}
        else {
          arg0K0 = 5;
          goto L45617;}}
      else {
        if ((0 == (3 & arg2_1132X))) {
          goto L45623;}
        else {
          if ((3 == (3 & arg2_1132X))) {
            if ((19 == (31 & ((((*((long *) ((((char *) (-3 + arg2_1132X))) + -4))))>>2))))) {
              goto L45623;}
            else {
              goto L45634;}}
          else {
            goto L45634;}}}}
      break;
    case 69 : {
      arg2_1134X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      y_1135X = SvalS;
      if ((0 == y_1135X)) {push_exception_setupB(5, 1);
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (arg2_1134X);
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (y_1135X);
        arg0K0 = 2;
        goto L30610;}
      else {
        if ((0 == (3 & (arg2_1134X | y_1135X)))) {
          if ((0 == y_1135X)) {
            val_1136X = Hinteger_op8281(arg2_1134X, y_1135X);
            SvalS = val_1136X;
            Scode_pointerS = ((Scode_pointerS) + 1);
            arg3K0 = (Scode_pointerS);
            goto L32913;}
          else {
            a_1137X = ((arg2_1134X)>>2);
            b_1138X = ((y_1135X)>>2);
            if ((a_1137X < 0)) {
              arg0K0 = (0 - a_1137X);
              goto L13421;}
            else {
              arg0K0 = a_1137X;
              goto L13421;}}}
        else {
          if ((0 == (3 & arg2_1134X))) {
            goto L45923;}
          else {
            if ((3 == (3 & arg2_1134X))) {
              if ((19 == (31 & ((((*((long *) ((((char *) (-3 + arg2_1134X))) + -4))))>>2))))) {
                goto L45923;}
              else {
                goto L45932;}}
            else {
              goto L45932;}}}}}
      break;
    case 70 : {
      arg2_1139X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      y_1140X = SvalS;
      if ((0 == y_1140X)) {push_exception_setupB(5, 1);
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (arg2_1139X);
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (y_1140X);
        arg0K0 = 2;
        goto L30610;}
      else {
        if ((0 == (3 & (arg2_1139X | y_1140X)))) {
          if ((0 == y_1140X)) {
            val_1141X = Hinteger_op8212(arg2_1139X, y_1140X);
            SvalS = val_1141X;
            Scode_pointerS = ((Scode_pointerS) + 1);
            arg3K0 = (Scode_pointerS);
            goto L32913;}
          else {
            a_1142X = ((arg2_1139X)>>2);
            if ((a_1142X < 0)) {
              arg0K0 = (0 - a_1142X);
              goto L46137;}
            else {
              arg0K0 = a_1142X;
              goto L46137;}}}
        else {
          if ((0 == (3 & arg2_1139X))) {
            goto L46099;}
          else {
            if ((3 == (3 & arg2_1139X))) {
              if ((19 == (31 & ((((*((long *) ((((char *) (-3 + arg2_1139X))) + -4))))>>2))))) {
                goto L46099;}
              else {
                goto L46108;}}
            else {
              goto L46108;}}}}}
      break;
    case 71 : {
      n_1143X = SvalS;
      if ((0 == (3 & n_1143X))) {
        goto L46286;}
      else {
        if ((3 == (3 & n_1143X))) {
          if ((19 == (31 & ((((*((long *) ((((char *) (-3 + n_1143X))) + -4))))>>2))))) {
            goto L46286;}
          else {
            goto L46287;}}
        else {
          goto L46287;}}}
      break;
    case 72 : {
      n_1144X = SvalS;
      if ((0 == (3 & n_1144X))) {
        goto L46341;}
      else {
        if ((3 == (3 & n_1144X))) {
          if ((19 == (31 & ((((*((long *) ((((char *) (-3 + n_1144X))) + -4))))>>2))))) {
            goto L46341;}
          else {
            goto L46342;}}
        else {
          goto L46342;}}}
      break;
    case 73 : {
      n_1145X = SvalS;
      if ((0 == (3 & n_1145X))) {
        goto L46396;}
      else {
        if ((3 == (3 & n_1145X))) {
          if ((19 == (31 & ((((*((long *) ((((char *) (-3 + n_1145X))) + -4))))>>2))))) {
            goto L46396;}
          else {
            goto L46399;}}
        else {
          goto L46399;}}}
      break;
    case 74 : {
      n_1146X = SvalS;
      if ((0 == (3 & n_1146X))) {
        goto L46456;}
      else {
        if ((3 == (3 & n_1146X))) {
          if ((19 == (31 & ((((*((long *) ((((char *) (-3 + n_1146X))) + -4))))>>2))))) {
            goto L46456;}
          else {
            goto L46457;}}
        else {
          goto L46457;}}}
      break;
    case 75 : {
      n_1147X = SvalS;
      if ((0 == (3 & n_1147X))) {
        goto L46511;}
      else {
        if ((3 == (3 & n_1147X))) {
          if ((19 == (31 & ((((*((long *) ((((char *) (-3 + n_1147X))) + -4))))>>2))))) {
            goto L46511;}
          else {
            goto L46514;}}
        else {
          goto L46514;}}}
      break;
    case 76 : {
      x_1148X = SvalS;push_exception_setupB(5, 1);
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (x_1148X);
      arg0K0 = 1;
      goto L30610;}
      break;
    case 77 : {
      x_1149X = SvalS;push_exception_setupB(5, 1);
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (x_1149X);
      arg0K0 = 1;
      goto L30610;}
      break;
    case 78 : {
      x_1150X = SvalS;push_exception_setupB(5, 1);
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (x_1150X);
      arg0K0 = 1;
      goto L30610;}
      break;
    case 79 : {
      x_1151X = SvalS;push_exception_setupB(5, 1);
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (x_1151X);
      arg0K0 = 1;
      goto L30610;}
      break;
    case 80 : {
      x_1152X = SvalS;push_exception_setupB(5, 1);
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (x_1152X);
      arg0K0 = 1;
      goto L30610;}
      break;
    case 81 : {
      x_1153X = SvalS;push_exception_setupB(5, 1);
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (x_1153X);
      arg0K0 = 1;
      goto L30610;}
      break;
    case 82 : {
      x_1154X = SvalS;push_exception_setupB(5, 1);
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (x_1154X);
      arg0K0 = 1;
      goto L30610;}
      break;
    case 83 : {
      x_1155X = SvalS;push_exception_setupB(5, 1);
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (x_1155X);
      arg0K0 = 1;
      goto L30610;}
      break;
    case 84 : {
      x_1156X = SvalS;
      if ((0 == (3 & x_1156X))) {
        goto L54704;}
      else {
        if ((3 == (3 & x_1156X))) {
          if ((19 == (31 & ((((*((long *) ((((char *) (-3 + x_1156X))) + -4))))>>2))))) {
            goto L54704;}
          else {
            goto L54707;}}
        else {
          goto L54707;}}}
      break;
    case 85 : {
      x_1157X = SvalS;
      if ((0 == (3 & x_1157X))) {
        goto L58096;}
      else {
        if ((3 == (3 & x_1157X))) {
          if ((19 == (31 & ((((*((long *) ((((char *) (-3 + x_1157X))) + -4))))>>2))))) {
            goto L58096;}
          else {
            goto L58099;}}
        else {
          goto L58099;}}}
      break;
    case 86 : {
      x_1158X = SvalS;push_exception_setupB(5, 1);
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (x_1158X);
      arg0K0 = 1;
      goto L30610;}
      break;
    case 87 : {
      arg2_1159X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      x_1160X = SvalS;push_exception_setupB(5, 1);
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (arg2_1159X);
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (x_1160X);
      arg0K0 = 2;
      goto L30610;}
      break;
    case 88 : {
      arg2_1161X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      x_1162X = SvalS;push_exception_setupB(5, 1);
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (arg2_1161X);
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (x_1162X);
      arg0K0 = 2;
      goto L30610;}
      break;
    case 89 : {
      arg2_1163X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      x_1164X = SvalS;push_exception_setupB(5, 1);
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (arg2_1163X);
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (x_1164X);
      arg0K0 = 2;
      goto L30610;}
      break;
    case 90 : {
      x_1165X = SvalS;
      if ((0 == (3 & x_1165X))) {
        SvalS = (~ (3 | x_1165X));
        Scode_pointerS = ((Scode_pointerS) + 1);
        arg3K0 = (Scode_pointerS);
        goto L32913;}
      else {
        if ((0 == (3 & x_1165X))) {
          goto L46657;}
        else {
          if ((3 == (3 & x_1165X))) {
            if ((19 == (31 & ((((*((long *) ((((char *) (-3 + x_1165X))) + -4))))>>2))))) {
              goto L46657;}
            else {
              goto L46660;}}
          else {
            goto L46660;}}}}
      break;
    case 91 : {
      x_1166X = SvalS;
      if ((0 == (3 & x_1166X))) {
        x_1167X = ((x_1166X)>>2);
        if ((x_1167X < 0)) {
          arg0K0 = (~ x_1167X);
          goto L46748;}
        else {
          arg0K0 = x_1167X;
          goto L46748;}}
      else {
        if ((0 == (3 & x_1166X))) {
          goto L46731;}
        else {
          if ((3 == (3 & x_1166X))) {
            if ((19 == (31 & ((((*((long *) ((((char *) (-3 + x_1166X))) + -4))))>>2))))) {
              goto L46731;}
            else {
              goto L46734;}}
          else {
            goto L46734;}}}}
      break;
    case 92 : {
      arg2_1168X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      y_1169X = SvalS;
      if ((0 == (3 & (arg2_1168X | y_1169X)))) {
        SvalS = (arg2_1168X & y_1169X);
        Scode_pointerS = ((Scode_pointerS) + 1);
        arg3K0 = (Scode_pointerS);
        goto L32913;}
      else {
        if ((0 == (3 & arg2_1168X))) {
          goto L46833;}
        else {
          if ((3 == (3 & arg2_1168X))) {
            if ((19 == (31 & ((((*((long *) ((((char *) (-3 + arg2_1168X))) + -4))))>>2))))) {
              goto L46833;}
            else {
              goto L46842;}}
          else {
            goto L46842;}}}}
      break;
    case 93 : {
      arg2_1170X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      y_1171X = SvalS;
      if ((0 == (3 & (arg2_1170X | y_1171X)))) {
        SvalS = (arg2_1170X | y_1171X);
        Scode_pointerS = ((Scode_pointerS) + 1);
        arg3K0 = (Scode_pointerS);
        goto L32913;}
      else {
        if ((0 == (3 & arg2_1170X))) {
          goto L46996;}
        else {
          if ((3 == (3 & arg2_1170X))) {
            if ((19 == (31 & ((((*((long *) ((((char *) (-3 + arg2_1170X))) + -4))))>>2))))) {
              goto L46996;}
            else {
              goto L47005;}}
          else {
            goto L47005;}}}}
      break;
    case 94 : {
      arg2_1172X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      y_1173X = SvalS;
      if ((0 == (3 & (arg2_1172X | y_1173X)))) {
        SvalS = (arg2_1172X ^ y_1173X);
        Scode_pointerS = ((Scode_pointerS) + 1);
        arg3K0 = (Scode_pointerS);
        goto L32913;}
      else {
        if ((0 == (3 & arg2_1172X))) {
          goto L47159;}
        else {
          if ((3 == (3 & arg2_1172X))) {
            if ((19 == (31 & ((((*((long *) ((((char *) (-3 + arg2_1172X))) + -4))))>>2))))) {
              goto L47159;}
            else {
              goto L47168;}}
          else {
            goto L47168;}}}}
      break;
    case 95 : {
      arg2_1174X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      y_1175X = SvalS;
      if ((3 == (3 & y_1175X))) {
        if ((19 == (31 & ((((*((long *) ((((char *) (-3 + y_1175X))) + -4))))>>2))))) {
          v_1176X = s48_bignum_test((((char *) (-3 + y_1175X))));
          if ((1 == v_1176X)) {push_exception_setupB(6, 1);
            SstackS = ((SstackS) + -4);
            *((long *) (SstackS)) = (long) (arg2_1174X);
            SstackS = ((SstackS) + -4);
            *((long *) (SstackS)) = (long) (y_1175X);
            arg0K0 = 2;
            goto L30610;}
          else {
            if ((0 == (3 & arg2_1174X))) {
              if ((arg2_1174X < 0)) {
                arg0K0 = -4;
                goto L43551;}
              else {
                arg0K0 = 0;
                goto L43551;}}
            else {
              if ((3 == (3 & arg2_1174X))) {
                if ((19 == (31 & ((((*((long *) ((((char *) (-3 + arg2_1174X))) + -4))))>>2))))) {
                  v_1177X = s48_bignum_test((((char *) (-3 + arg2_1174X))));
                  if ((1 == v_1177X)) {
                    arg0K0 = 0;
                    goto L43567;}
                  else {
                    arg0K0 = -4;
                    goto L43567;}}
                else {
                  goto L43568;}}
              else {
                goto L43568;}}}}
        else {
          goto L53764;}}
      else {
        goto L53764;}}
      break;
    case 96 : {
      x_1178X = SvalS;
      if ((9 == (255 & x_1178X))) {
        arg0K0 = 5;
        goto L62145;}
      else {
        arg0K0 = 1;
        goto L62145;}}
      break;
    case 97 : {
      arg2_1179X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      if ((9 == (255 & arg2_1179X))) {
        if ((9 == (255 & (SvalS)))) {
          x_1180X = SvalS;
          if ((arg2_1179X == x_1180X)) {
            arg0K0 = 5;
            goto L51018;}
          else {
            arg0K0 = 1;
            goto L51018;}}
        else {
          goto L50989;}}
      else {
        goto L50989;}}
      break;
    case 98 : {
      arg2_1181X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      if ((9 == (255 & arg2_1181X))) {
        if ((9 == (255 & (SvalS)))) {
          x_1182X = SvalS;
          if ((arg2_1181X < x_1182X)) {
            arg0K0 = 5;
            goto L50926;}
          else {
            arg0K0 = 1;
            goto L50926;}}
        else {
          goto L50897;}}
      else {
        goto L50897;}}
      break;
    case 99 : {
      if ((9 == (255 & (SvalS)))) {
        SvalS = (-4 & ((((SvalS))>>6)));
        Scode_pointerS = ((Scode_pointerS) + 1);
        arg3K0 = (Scode_pointerS);
        goto L32913;}
      else {push_exception_setupB(5, 1);
        x_1183X = SvalS;
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (x_1183X);
        arg0K0 = 1;
        goto L30610;}}
      break;
    case 100 : {
      if ((0 == (3 & (SvalS)))) {
        x_1184X = (((SvalS))>>2);
        if ((x_1184X < 0)) {
          goto L55013;}
        else {
          if ((55295 < x_1184X)) {
            if ((x_1184X < 57344)) {
              goto L55013;}
            else {
              if ((1114111 < x_1184X)) {
                goto L55013;}
              else {
                goto L55019;}}}
          else {
            goto L55019;}}}
      else {push_exception_setupB(5, 1);
        x_1185X = SvalS;
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (x_1185X);
        arg0K0 = 1;
        goto L30610;}}
      break;
    case 101 : {
      if ((0 == (3 & (SvalS)))) {
        x_1186X = (((SvalS))>>2);
        if ((x_1186X < 0)) {
          arg0K0 = 1;
          goto L50824;}
        else {
          if ((55295 < x_1186X)) {
            if ((x_1186X < 57344)) {
              arg0K0 = 1;
              goto L50824;}
            else {
              if ((1114111 < x_1186X)) {
                arg0K0 = 1;
                goto L50824;}
              else {
                arg0K0 = 5;
                goto L50824;}}}
          else {
            arg0K0 = 5;
            goto L50824;}}}
      else {push_exception_setupB(5, 1);
        x_1187X = SvalS;
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (x_1187X);
        arg0K0 = 1;
        goto L30610;}}
      break;
    case 102 : {
      x_1188X = SvalS;
      if ((21 == x_1188X)) {
        arg0K0 = 5;
        goto L62178;}
      else {
        arg0K0 = 1;
        goto L62178;}}
      break;
    case 103 : {
      x_1189X = SvalS;
      type_1190X = *((unsigned char *) ((Scode_pointerS) + 1));
      if ((3 == (3 & x_1189X))) {
        if (((31 & ((((*((long *) ((((char *) (-3 + x_1189X))) + -4))))>>2))) == type_1190X)) {
          arg0K0 = 5;
          goto L62192;}
        else {
          arg0K0 = 1;
          goto L62192;}}
      else {
        arg0K0 = 1;
        goto L62192;}}
      break;
    case 104 : {
      stob_1191X = SvalS;
      type_1192X = *((unsigned char *) ((Scode_pointerS) + 1));
      if ((3 == (3 & stob_1191X))) {
        if (((31 & ((((*((long *) ((((char *) (-3 + stob_1191X))) + -4))))>>2))) == type_1192X)) {
          SvalS = (-4 & (3 + ((long)(((unsigned long)(*((long *) ((((char *) (-3 + stob_1191X))) + -4))))>>8))));
          Scode_pointerS = ((Scode_pointerS) + 2);
          arg3K0 = (Scode_pointerS);
          goto L32913;}
        else {
          goto L35684;}}
      else {
        goto L35684;}}
      break;
    case 105 : {
      len_1193X = *((unsigned char *) ((Scode_pointerS) + 1));s48_make_availableAgc((4 + (((len_1193X)<<2))));
      type_1194X = *((unsigned char *) ((Scode_pointerS) + 2));
      len_1195X = ((len_1193X)<<2);
      addr_1196X = s48_allocate_small((4 + len_1195X));
      *((long *) addr_1196X) = (long) ((2 + (((((((len_1195X)<<6)) + type_1194X))<<2))));
      new_1197X = 3 + (((long) (addr_1196X + 4)));
      if ((len_1193X < 1)) {
        goto L35789;}
      else {
        *((long *) ((((char *) (-3 + new_1197X))) + (-4 + (((len_1193X)<<2))))) = (long) ((SvalS));
        arg0K0 = (-2 + len_1193X);
        goto L35773;}}
      break;
    case 106 : {
      p_1198X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      len_1199X = ((p_1198X)>>2);s48_make_availableAgc((4 + (((len_1199X)<<2))));
      type_1200X = *((unsigned char *) ((Scode_pointerS) + 1));
      len_1201X = ((len_1199X)<<2);
      addr_1202X = s48_allocate_small((4 + len_1201X));
      *((long *) addr_1202X) = (long) ((2 + (((((((len_1201X)<<6)) + type_1200X))<<2))));
      new_1203X = 3 + (((long) (addr_1202X + 4)));
      p_1204X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      stack_nargs_1205X = ((p_1204X)>>2);
      rest_list_1206X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      arg0K0 = (-1 + stack_nargs_1205X);
      goto L35907;}
      break;
    case 107 : {
      stob_1207X = SvalS;
      type_1208X = *((unsigned char *) ((Scode_pointerS) + 1));
      offset_1209X = *((unsigned char *) ((Scode_pointerS) + 2));
      if ((3 == (3 & stob_1207X))) {
        if (((31 & ((((*((long *) ((((char *) (-3 + stob_1207X))) + -4))))>>2))) == type_1208X)) {
          SvalS = (*((long *) ((((char *) (-3 + stob_1207X))) + (((offset_1209X)<<2)))));
          Scode_pointerS = ((Scode_pointerS) + 3);
          arg3K0 = (Scode_pointerS);
          goto L32913;}
        else {
          goto L36075;}}
      else {
        goto L36075;}}
      break;
    case 108 : {
      arg2_1210X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      value_1211X = SvalS;
      type_1212X = *((unsigned char *) ((Scode_pointerS) + 1));
      offset_1213X = *((unsigned char *) ((Scode_pointerS) + 2));
      if ((3 == (3 & arg2_1210X))) {
        if (((31 & ((((*((long *) ((((char *) (-3 + arg2_1210X))) + -4))))>>2))) == type_1212X)) {
          if ((3 == (3 & arg2_1210X))) {
            if ((0 == (128 & (*((long *) ((((char *) (-3 + arg2_1210X))) + -4)))))) {
              v_1214X = *((unsigned char *) ((Scode_pointerS) + 3));
              if ((0 == v_1214X)) {
                goto L36192;}
              else {
                if ((1 == (*((long *) ((((char *) (-3 + (Scurrent_threadS)))) + 12))))) {
                  goto L36192;}
                else {
                  merged_arg0K0 = arg2_1210X;
                  merged_arg0K1 = (((offset_1213X)<<2));
                  merged_arg0K2 = value_1211X;
                  proposal_d_write_return_tag = 0;
                  goto proposal_d_write;
                 proposal_d_write_return_0:
                  goto L36201;}}}
            else {
              goto L36202;}}
          else {
            goto L36202;}}
        else {
          goto L36202;}}
      else {
        goto L36202;}}
      break;
    case 109 : {
      arg2_1215X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      init_1216X = SvalS;
      type_1217X = *((unsigned char *) ((Scode_pointerS) + 1));
      if ((0 == (3 & arg2_1215X))) {
        len_1218X = ((arg2_1215X)>>2);
        if ((len_1218X < 0)) {
          goto L36419;}
        else {
          if ((4194304 < len_1218X)) {
            goto L36419;}
          else {
            Stemp0S = init_1216X;
            len_1219X = ((len_1218X)<<2);
            addr_1220X = s48_allocate_tracedAgc((4 + len_1219X));
            if ((addr_1220X == NULL)) {
              arg0K0 = 1;
              goto L36436;}
            else {
              *((long *) addr_1220X) = (long) ((2 + (((((((len_1219X)<<6)) + type_1217X))<<2))));
              arg0K0 = (3 + (((long) (addr_1220X + 4))));
              goto L36436;}}}}
      else {push_exception_setupB(5, 2);
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) ((((type_1217X)<<2)));
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (arg2_1215X);
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (init_1216X);
        arg0K0 = 3;
        goto L30610;}}
      break;
    case 110 : {
      arg2_1221X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      index_1222X = SvalS;
      type_1223X = *((unsigned char *) ((Scode_pointerS) + 1));
      if ((0 == (3 & index_1222X))) {
        if ((3 == (3 & arg2_1221X))) {
          if (((31 & ((((*((long *) ((((char *) (-3 + arg2_1221X))) + -4))))>>2))) == type_1223X)) {
            len_1224X = (((3 + ((long)(((unsigned long)(*((long *) ((((char *) (-3 + arg2_1221X))) + -4))))>>8))))>>2);
            index_1225X = ((index_1222X)>>2);
            if ((index_1225X < 0)) {
              goto L36709;}
            else {
              if ((index_1225X < len_1224X)) {
                v_1226X = *((unsigned char *) ((Scode_pointerS) + 2));
                if ((0 == v_1226X)) {
                  goto L36699;}
                else {
                  if ((1 == (*((long *) ((((char *) (-3 + (Scurrent_threadS)))) + 12))))) {
                    goto L36699;}
                  else {
                    merged_arg0K0 = arg2_1221X;
                    merged_arg0K1 = index_1222X;
                    proposal_d_read_return_tag = 0;
                    goto proposal_d_read;
                   proposal_d_read_return_0:
                    v_1227X = proposal_d_read0_return_value;
                    arg0K0 = v_1227X;
                    goto L36708;}}}
              else {
                goto L36709;}}}
          else {
            goto L36664;}}
        else {
          goto L36664;}}
      else {
        goto L36664;}}
      break;
    case 111 : {
      arg2_1228X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      arg3_1229X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      value_1230X = SvalS;
      type_1231X = *((unsigned char *) ((Scode_pointerS) + 1));
      if ((0 == (3 & arg2_1228X))) {
        if ((3 == (3 & arg3_1229X))) {
          if (((31 & ((((*((long *) ((((char *) (-3 + arg3_1229X))) + -4))))>>2))) == type_1231X)) {
            if ((3 == (3 & arg3_1229X))) {
              if ((0 == (128 & (*((long *) ((((char *) (-3 + arg3_1229X))) + -4)))))) {
                len_1232X = (((3 + ((long)(((unsigned long)(*((long *) ((((char *) (-3 + arg3_1229X))) + -4))))>>8))))>>2);
                index_1233X = ((arg2_1228X)>>2);
                if ((index_1233X < 0)) {
                  goto L36996;}
                else {
                  if ((index_1233X < len_1232X)) {
                    v_1234X = *((unsigned char *) ((Scode_pointerS) + 2));
                    if ((0 == v_1234X)) {
                      goto L36986;}
                    else {
                      if ((1 == (*((long *) ((((char *) (-3 + (Scurrent_threadS)))) + 12))))) {
                        goto L36986;}
                      else {
                        merged_arg0K0 = arg3_1229X;
                        merged_arg0K1 = arg2_1228X;
                        merged_arg0K2 = value_1230X;
                        proposal_d_write_return_tag = 1;
                        goto proposal_d_write;
                       proposal_d_write_return_1:
                        goto L36995;}}}
                  else {
                    goto L36996;}}}
              else {
                goto L36949;}}
            else {
              goto L36949;}}
          else {
            goto L36949;}}
        else {
          goto L36949;}}
      else {
        goto L36949;}}
      break;
    case 112 : {
      addr_1235X = s48_allocate_untracedAgc(12);
      if ((addr_1235X == NULL)) {
        arg0K0 = 1;
        goto L62235;}
      else {
        *((long *) addr_1235X) = (long) (2122);
        arg0K0 = (3 + (((long) (addr_1235X + 4))));
        goto L62235;}}
      break;
    case 113 : {
      arg2_1236X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      if ((0 == (3 & (arg2_1236X | (SvalS))))) {
        len_1237X = ((arg2_1236X)>>2);
        init_1238X = (((SvalS))>>2);
        if ((len_1237X < 0)) {
          goto L47441;}
        else {
          if ((4194304 < ((((3 + len_1237X))>>2)))) {
            goto L47441;}
          else {
            addr_1239X = s48_allocate_untracedAgc((4 + len_1237X));
            if ((addr_1239X == NULL)) {
              arg0K0 = 1;
              goto L47456;}
            else {
              *((long *) addr_1239X) = (long) ((70 + (((len_1237X)<<8))));
              arg0K0 = (3 + (((long) (addr_1239X + 4))));
              goto L47456;}}}}
      else {push_exception_setupB(5, 1);
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (arg2_1236X);
        x_1240X = SvalS;
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (x_1240X);
        arg0K0 = 2;
        goto L30610;}}
      break;
    case 114 : {
      obj_1241X = SvalS;
      if ((3 == (3 & obj_1241X))) {
        if ((17 == (31 & ((((*((long *) ((((char *) (-3 + obj_1241X))) + -4))))>>2))))) {
          SvalS = (((((long)(((unsigned long)(*((long *) ((((char *) (-3 + (SvalS)))) + -4))))>>8)))<<2));
          Scode_pointerS = ((Scode_pointerS) + 1);
          arg3K0 = (Scode_pointerS);
          goto L32913;}
        else {
          goto L59361;}}
      else {
        goto L59361;}}
      break;
    case 115 : {
      arg2_1242X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      if ((3 == (3 & arg2_1242X))) {
        if ((17 == (31 & ((((*((long *) ((((char *) (-3 + arg2_1242X))) + -4))))>>2))))) {
          if ((0 == (3 & (SvalS)))) {
            index_1243X = (((SvalS))>>2);
            len_1244X = (long)(((unsigned long)(*((long *) ((((char *) (-3 + arg2_1242X))) + -4))))>>8);
            if ((index_1243X < 0)) {
              goto L55156;}
            else {
              if ((index_1243X < len_1244X)) {
                SvalS = ((((*((unsigned char *) ((((char *) (-3 + arg2_1242X))) + index_1243X))))<<2));
                Scode_pointerS = ((Scode_pointerS) + 1);
                arg3K0 = (Scode_pointerS);
                goto L32913;}
              else {
                goto L55156;}}}
          else {
            goto L58777;}}
        else {
          goto L58777;}}
      else {
        goto L58777;}}
      break;
    case 116 : {
      arg2_1245X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      arg3_1246X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      if ((3 == (3 & arg3_1246X))) {
        if ((17 == (31 & ((((*((long *) ((((char *) (-3 + arg3_1246X))) + -4))))>>2))))) {
          if ((0 == (3 & (arg2_1245X | (SvalS))))) {
            index_1247X = ((arg2_1245X)>>2);
            Kchar_1248X = (((SvalS))>>2);
            if ((3 == (3 & arg3_1246X))) {
              if ((0 == (128 & (*((long *) ((((char *) (-3 + arg3_1246X))) + -4)))))) {
                len_1249X = (long)(((unsigned long)(*((long *) ((((char *) (-3 + arg3_1246X))) + -4))))>>8);
                if ((index_1247X < 0)) {
                  goto L52336;}
                else {
                  if ((index_1247X < len_1249X)) {
                    *((unsigned char *) ((((char *) (-3 + arg3_1246X))) + index_1247X)) = (unsigned char) (Kchar_1248X);
                    SvalS = 13;
                    Scode_pointerS = ((Scode_pointerS) + 1);
                    arg3K0 = (Scode_pointerS);
                    goto L32913;}
                  else {
                    goto L52336;}}}
              else {
                goto L52315;}}
            else {
              goto L52315;}}
          else {
            goto L57416;}}
        else {
          goto L57416;}}
      else {
        goto L57416;}}
      break;
    case 117 : {
      arg2_1250X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      if ((0 == (3 & arg2_1250X))) {
        if ((9 == (255 & (SvalS)))) {
          len_1251X = ((arg2_1250X)>>2);
          init_1252X = (((SvalS))>>8);
          if ((len_1251X < 0)) {
            goto L47626;}
          else {
            if ((4194304 < ((((3 + (((len_1251X)<<2))))>>2)))) {
              goto L47626;}
            else {
              len_1253X = ((len_1251X)<<2);
              addr_1254X = s48_allocate_untracedAgc((4 + len_1253X));
              if ((addr_1254X == NULL)) {
                arg0K0 = 1;
                goto L47641;}
              else {
                *((long *) addr_1254X) = (long) ((66 + (((len_1253X)<<8))));
                arg0K0 = (3 + (((long) (addr_1254X + 4))));
                goto L47641;}}}}
        else {
          goto L55237;}}
      else {
        goto L55237;}}
      break;
    case 118 : {
      obj_1255X = SvalS;
      if ((3 == (3 & obj_1255X))) {
        if ((16 == (31 & ((((*((long *) ((((char *) (-3 + obj_1255X))) + -4))))>>2))))) {
          x_1256X = ((long)(((unsigned long)(*((long *) ((((char *) (-3 + (SvalS)))) + -4))))>>8)) / 4;
          SvalS = (((x_1256X)<<2));
          Scode_pointerS = ((Scode_pointerS) + 1);
          arg3K0 = (Scode_pointerS);
          goto L32913;}
        else {
          goto L59411;}}
      else {
        goto L59411;}}
      break;
    case 119 : {
      arg2_1257X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      if ((3 == (3 & arg2_1257X))) {
        if ((16 == (31 & ((((*((long *) ((((char *) (-3 + arg2_1257X))) + -4))))>>2))))) {
          if ((0 == (3 & (SvalS)))) {
            index_1258X = (((SvalS))>>2);
            len_1259X = ((long)(((unsigned long)(*((long *) ((((char *) (-3 + arg2_1257X))) + -4))))>>8)) / 4;
            if ((index_1258X < 0)) {
              goto L55302;}
            else {
              if ((index_1258X < len_1259X)) {
                arg0K0 = 0;
                arg0K1 = 0;
                arg0K2 = 0;
                goto L55330;}
              else {
                goto L55302;}}}
          else {
            goto L58875;}}
        else {
          goto L58875;}}
      else {
        goto L58875;}}
      break;
    case 120 : {
      arg2_1260X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      arg3_1261X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      if ((3 == (3 & arg3_1261X))) {
        if ((16 == (31 & ((((*((long *) ((((char *) (-3 + arg3_1261X))) + -4))))>>2))))) {
          if ((0 == (3 & arg2_1260X))) {
            if ((9 == (255 & (SvalS)))) {
              index_1262X = ((arg2_1260X)>>2);
              Kchar_1263X = (((SvalS))>>8);
              if ((3 == (3 & arg3_1261X))) {
                if ((0 == (128 & (*((long *) ((((char *) (-3 + arg3_1261X))) + -4)))))) {
                  len_1264X = ((long)(((unsigned long)(*((long *) ((((char *) (-3 + arg3_1261X))) + -4))))>>8)) / 4;
                  if ((index_1262X < 0)) {
                    goto L52491;}
                  else {
                    if ((index_1262X < len_1264X)) {
                      arg0K0 = 0;
                      arg0K1 = 0;
                      arg0K2 = Kchar_1263X;
                      goto L52555;}
                    else {
                      goto L52491;}}}
                else {
                  goto L52470;}}
              else {
                goto L52470;}}
            else {
              goto L57546;}}
          else {
            goto L57546;}}
        else {
          goto L57546;}}
      else {
        goto L57546;}}
      break;
    case 121 : {
      arg2_1265X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      arg3_1266X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      arg4_1267X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      arg5_1268X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      if ((3 == (3 & arg5_1268X))) {
        if ((16 == (31 & ((((*((long *) ((((char *) (-3 + arg5_1268X))) + -4))))>>2))))) {
          if ((0 == (3 & arg4_1267X))) {
            if ((3 == (3 & arg3_1266X))) {
              if ((16 == (31 & ((((*((long *) ((((char *) (-3 + arg3_1266X))) + -4))))>>2))))) {
                if ((0 == (3 & (arg2_1265X | (SvalS))))) {
                  from_index_1269X = ((arg4_1267X)>>2);
                  to_index_1270X = ((arg2_1265X)>>2);
                  count_1271X = (((SvalS))>>2);
                  if ((from_index_1269X < 0)) {
                    goto L37331;}
                  else {
                    y_1272X = ((long)(((unsigned long)(*((long *) ((((char *) (-3 + arg5_1268X))) + -4))))>>8)) / 4;
                    if ((y_1272X < (from_index_1269X + count_1271X))) {
                      goto L37331;}
                    else {
                      if ((to_index_1270X < 0)) {
                        goto L37331;}
                      else {
                        y_1273X = ((long)(((unsigned long)(*((long *) ((((char *) (-3 + arg3_1266X))) + -4))))>>8)) / 4;
                        if ((y_1273X < (to_index_1270X + count_1271X))) {
                          goto L37331;}
                        else {
                          if ((3 == (3 & arg3_1266X))) {
                            if ((0 == (128 & (*((long *) ((((char *) (-3 + arg3_1266X))) + -4)))))) {
                              if ((count_1271X < 0)) {
                                goto L37331;}
                              else {
                                memmove((void *)((((char *) (-3 + arg3_1266X))) + (((to_index_1270X)<<2))), (void *)((((char *) (-3 + arg5_1268X))) + (((from_index_1269X)<<2))),(((count_1271X)<<2)));
                                SvalS = 13;
                                Scode_pointerS = ((Scode_pointerS) + 1);
                                arg3K0 = (Scode_pointerS);
                                goto L32913;}}
                            else {
                              goto L37331;}}
                          else {
                            goto L37331;}}}}}}
                else {
                  goto L42504;}}
              else {
                goto L42504;}}
            else {
              goto L42504;}}
          else {
            goto L42504;}}
        else {
          goto L42504;}}
      else {
        goto L42504;}}
      break;
    case 122 : {s48_make_availableAgc(12);
      obj_1274X = SvalS;
      if ((3 == (3 & obj_1274X))) {
        if ((16 == (31 & ((((*((long *) ((((char *) (-3 + obj_1274X))) + -4))))>>2))))) {
          table_1275X = Sthe_symbol_tableS;
          string_1276X = SvalS;
          v_1277X = Haction4880(string_1276X);
          index_1278X = 1023 & v_1277X;
          link_1279X = *((long *) ((((char *) (-3 + table_1275X))) + (((index_1278X)<<2))));
          if ((0 == (3 & link_1279X))) {
            arg0K0 = (3 + (-4 & link_1279X));
            goto L28187;}
          else {
            arg0K0 = link_1279X;
            goto L28187;}}
        else {
          goto L43713;}}
      else {
        goto L43713;}}
      break;
    case 123 : {
      obj_1280X = SvalS;
      if ((3 == (3 & obj_1280X))) {
        if ((4 == (31 & ((((*((long *) ((((char *) (-3 + obj_1280X))) + -4))))>>2))))) {
          x_1281X = SvalS;
          descriptor_1282X = *((long *) ((((char *) (-3 + x_1281X))) + 4));
          if ((17 == (255 & descriptor_1282X))) {
            if ((529 == (*((long *) ((((char *) (-3 + x_1281X))) + 4))))) {
              arg0K0 = 5;
              goto L57110;}
            else {
              arg0K0 = 1;
              goto L57110;}}
          else {
            arg0K0 = 5;
            goto L57110;}}
        else {
          goto L57091;}}
      else {
        goto L57091;}}
      break;
    case 124 : {
      arg2_1283X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      if ((3 == (3 & arg2_1283X))) {
        if ((4 == (31 & ((((*((long *) ((((char *) (-3 + arg2_1283X))) + -4))))>>2))))) {
          x_1284X = SvalS;
          if ((1 == x_1284X)) {
            goto L52093;}
          else {
            if ((5 == x_1284X)) {
              goto L52093;}
            else {
              goto L52100;}}}
        else {
          goto L52100;}}
      else {
        goto L52100;}}
      break;
    case 125 : {
      x_1285X = SvalS;
      if ((3 == (3 & x_1285X))) {
        if ((0 == (128 & (*((long *) ((((char *) (-3 + x_1285X))) + -4)))))) {
          arg0K0 = 1;
          goto L62297;}
        else {
          arg0K0 = 5;
          goto L62297;}}
      else {
        arg0K0 = 5;
        goto L62297;}}
      break;
    case 126 : {
      x_1286X = SvalS;
      if ((3 == (3 & x_1286X))) {
        if ((0 == (128 & (*((long *) ((((char *) (-3 + x_1286X))) + -4)))))) {
          *((long *) ((((char *) (-3 + x_1286X))) + -4)) = (long) ((128 | (*((long *) ((((char *) (-3 + x_1286X))) + -4)))));
          goto L55394;}
        else {
          goto L55394;}}
      else {
        goto L55394;}}
      break;
    case 127 : {s48_make_availableAgc(32);
      arg2_1287X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      arg3_1288X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      arg4_1289X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      if ((0 == (3 & arg2_1287X))) {
        mode_1290X = ((arg2_1287X)>>2);
        close_silentlyP_1291X = SvalS;
        if ((1 == mode_1290X)) {
          goto L48065;}
        else {
          if ((2 == mode_1290X)) {
            goto L48065;}
          else {
            if ((3 == mode_1290X)) {
              goto L48065;}
            else {
              if ((4 == mode_1290X)) {
                goto L48065;}
              else {push_exception_setupB(5, 1);
                SstackS = ((SstackS) + -4);
                *((long *) (SstackS)) = (long) (arg4_1289X);
                SstackS = ((SstackS) + -4);
                *((long *) (SstackS)) = (long) ((((mode_1290X)<<2)));
                arg0K0 = 2;
                goto L30610;}}}}}
      else {push_exception_setupB(5, 1);
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (arg4_1289X);
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (arg3_1288X);
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (arg2_1287X);
        x_1292X = SvalS;
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (x_1292X);
        arg0K0 = 4;
        goto L30610;}}
      break;
    case 128 : {s48_make_availableAgc(2052);
      obj_1293X = SvalS;
      if ((3 == (3 & obj_1293X))) {
        if ((6 == (31 & ((((*((long *) ((((char *) (-3 + obj_1293X))) + -4))))>>2))))) {
          channel_1294X = SvalS;
          if ((0 == (*((long *) (((char *) (-3 + channel_1294X))))))) {push_exception_setupB(5, 1);
            SstackS = ((SstackS) + -4);
            *((long *) (SstackS)) = (long) (channel_1294X);
            arg0K0 = 1;
            goto L30610;}
          else {
            status_1295X = close_channelB(channel_1294X);
            if ((status_1295X == NO_ERRORS)) {
              SvalS = 13;
              Scode_pointerS = ((Scode_pointerS) + 1);
              arg3K0 = (Scode_pointerS);
              goto L32913;}
            else {push_exception_setupB(24, 1);
              SstackS = ((SstackS) + -4);
              *((long *) (SstackS)) = (long) (channel_1294X);
              merged_arg0K0 = status_1295X;
              merged_arg0K1 = 0;
              get_error_string_return_tag = 0;
              goto get_error_string;
             get_error_string_return_0:
              x_1296X = get_error_string0_return_value;
              SstackS = ((SstackS) + -4);
              *((long *) (SstackS)) = (long) (x_1296X);
              arg0K0 = 2;
              goto L30610;}}}
        else {
          goto L62316;}}
      else {
        goto L62316;}}
      break;
    case 129 : {s48_make_availableAgc(8);
      arg2_1297X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      arg3_1298X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      arg4_1299X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      arg5_1300X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      if ((3 == (3 & arg5_1300X))) {
        if ((6 == (31 & ((((*((long *) ((((char *) (-3 + arg5_1300X))) + -4))))>>2))))) {
          if ((0 == (3 & (arg3_1298X | arg2_1297X)))) {
            x_1301X = SvalS;
            if ((1 == x_1301X)) {
              goto L55594;}
            else {
              if ((5 == x_1301X)) {
                goto L55594;}
              else {
                goto L55605;}}}
          else {
            goto L55605;}}
        else {
          goto L55605;}}
      else {
        goto L55605;}}
      break;
    case 130 : {s48_make_availableAgc(8);
      arg2_1302X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      arg3_1303X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      arg4_1304X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      if ((3 == (3 & arg4_1304X))) {
        if ((6 == (31 & ((((*((long *) ((((char *) (-3 + arg4_1304X))) + -4))))>>2))))) {
          if ((0 == (3 & (arg2_1302X | (SvalS))))) {
            start_1305X = ((arg2_1302X)>>2);
            count_1306X = (((SvalS))>>2);
            v_1307X = 8 == (*((long *) (((char *) (-3 + arg4_1304X)))));
            if (v_1307X) {
              if ((3 == (3 & arg3_1303X))) {
                if ((17 == (31 & ((((*((long *) ((((char *) (-3 + arg3_1303X))) + -4))))>>2))))) {
                  if ((((long)(((unsigned long)(*((long *) ((((char *) (-3 + arg3_1303X))) + -4))))>>8)) < (start_1305X + count_1306X))) {
                    goto L48698;}
                  else {
                    got_1308X = ps_write_fd(((((*((long *) ((((char *) (-3 + arg4_1304X))) + 8))))>>2)), ((((char *) (-3 + arg3_1303X))) + start_1305X), count_1306X, &pendingP_1309X, &status_1310X);
                    if ((status_1310X == NO_ERRORS)) {
                      if (pendingP_1309X) {
                        addr_1311X = (((char *) (-3 + arg4_1304X))) + 20;S48_WRITE_BARRIER(arg4_1304X, addr_1311X, 5);
                        *((long *) addr_1311X) = (long) (5);
                        arg0K0 = 1;
                        goto L48697;}
                      else {
                        arg0K0 = (((got_1308X)<<2));
                        goto L48697;}}
                    else {
                      addr_1312X = s48_allocate_small(8);
                      *((long *) addr_1312X) = (long) (1046);
                      x_1313X = 3 + (((long) (addr_1312X + 4)));
                      *((long *) (((char *) (-3 + x_1313X)))) = (long) ((((status_1310X)<<2)));
                      arg0K0 = x_1313X;
                      goto L48697;}}}
                else {
                  goto L48698;}}
              else {
                goto L48698;}}
            else {
              goto L48698;}}
          else {
            goto L55808;}}
        else {
          goto L55808;}}
      else {
        goto L55808;}}
      break;
    case 131 : {
      if ((0 == (3 & (SvalS)))) {
        param_1314X = (((SvalS))>>2);
        if ((0 == param_1314X)) {
          x_1315X = ps_io_buffer_size();
          SvalS = (((x_1315X)<<2));
          Scode_pointerS = ((Scode_pointerS) + 1);
          arg3K0 = (Scode_pointerS);
          goto L32913;}
        else {
          if ((1 == param_1314X)) {
            x_1316X = ps_io_crlf_p();
            if (x_1316X) {
              arg0K0 = 5;
              goto L58592;}
            else {
              arg0K0 = 1;
              goto L58592;}}
          else {push_exception_setupB(17, 1);
            SstackS = ((SstackS) + -4);
            *((long *) (SstackS)) = (long) ((((param_1314X)<<2)));
            arg0K0 = 1;
            goto L30610;}}}
      else {push_exception_setupB(5, 1);
        x_1317X = SvalS;
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (x_1317X);
        arg0K0 = 1;
        goto L30610;}}
      break;
    case 132 : {s48_make_availableAgc(2052);
      obj_1318X = SvalS;
      if ((3 == (3 & obj_1318X))) {
        if ((6 == (31 & ((((*((long *) ((((char *) (-3 + obj_1318X))) + -4))))>>2))))) {
          channel_1319X = SvalS;
          if ((0 == (*((long *) (((char *) (-3 + channel_1319X))))))) {push_exception_setupB(5, 1);
            SstackS = ((SstackS) + -4);
            *((long *) (SstackS)) = (long) (channel_1319X);
            arg0K0 = 1;
            goto L30610;}
          else {
            readyP_1320X = ps_check_fd(((((*((long *) ((((char *) (-3 + channel_1319X))) + 8))))>>2)), (4 == (*((long *) (((char *) (-3 + channel_1319X)))))), &status_1321X);
            if ((status_1321X == NO_ERRORS)) {
              if (readyP_1320X) {
                arg0K0 = 5;
                goto L51684;}
              else {
                arg0K0 = 1;
                goto L51684;}}
            else {push_exception_setupB(24, 1);
              SstackS = ((SstackS) + -4);
              *((long *) (SstackS)) = (long) (channel_1319X);
              merged_arg0K0 = status_1321X;
              merged_arg0K1 = 0;
              get_error_string_return_tag = 1;
              goto get_error_string;
             get_error_string_return_1:
              x_1322X = get_error_string0_return_value;
              SstackS = ((SstackS) + -4);
              *((long *) (SstackS)) = (long) (x_1322X);
              arg0K0 = 2;
              goto L30610;}}}
        else {
          goto L62351;}}
      else {
        goto L62351;}}
      break;
    case 133 : {
      obj_1323X = SvalS;
      if ((3 == (3 & obj_1323X))) {
        if ((6 == (31 & ((((*((long *) ((((char *) (-3 + obj_1323X))) + -4))))>>2))))) {
          channel_1324X = SvalS;
          head_1325X = Spending_channels_headS;
          if ((1 == head_1325X)) {
            addr_1326X = (((char *) (-3 + channel_1324X))) + 20;S48_WRITE_BARRIER(channel_1324X, addr_1326X, 1);
            *((long *) addr_1326X) = (long) (1);
            n_1327X = ps_abort_fd_op(((((*((long *) ((((char *) (-3 + channel_1324X))) + 8))))>>2)));
            arg0K0 = (((n_1327X)<<2));
            goto L55956;}
          else {
            if ((channel_1324X == head_1325X)) {
              channel_1328X = Spending_channels_headS;
              next_1329X = *((long *) ((((char *) (-3 + channel_1328X))) + 16));
              Spending_channels_headS = next_1329X;
              addr_1330X = (((char *) (-3 + channel_1328X))) + 16;S48_WRITE_BARRIER(channel_1328X, addr_1330X, 1);
              *((long *) addr_1330X) = (long) (1);
              if ((1 == next_1329X)) {
                Spending_channels_tailS = 1;
                goto L15790;}
              else {
                goto L15790;}}
            else {
              arg0K0 = (*((long *) ((((char *) (-3 + head_1325X))) + 16)));
              arg0K1 = head_1325X;
              goto L15808;}}}
        else {
          goto L55939;}}
      else {
        goto L55939;}}
      break;
    case 134 : {s48_make_availableAgc(((((3 * (Snumber_of_channelsS)))<<2)));
      arg0K0 = (-1 + (Snumber_of_channelsS));
      arg0K1 = 25;
      goto L22599;}
      break;
    case 135 : {
      x_1331X = SvalS;
      addr_1332X = s48_allocate_weakAgc(8);
      *((long *) addr_1332X) = (long) (1078);
      weak_pointer_1333X = 3 + (((long) (addr_1332X + 4)));
      *((long *) (((char *) (-3 + weak_pointer_1333X)))) = (long) (x_1331X);
      SvalS = weak_pointer_1333X;
      Scode_pointerS = ((Scode_pointerS) + 1);
      arg3K0 = (Scode_pointerS);
      goto L32913;}
      break;
    case 136 : {
      SvalS = (*((long *) ((((char *) (-3 + (Scurrent_threadS)))) + 12)));
      Scode_pointerS = ((Scode_pointerS) + 1);
      arg3K0 = (Scode_pointerS);
      goto L32913;}
      break;
    case 137 : {
      proposal_1334X = SvalS;
      if ((1 == proposal_1334X)) {
        goto L48919;}
      else {
        if ((3 == (3 & proposal_1334X))) {
          if ((2 == (31 & ((((*((long *) ((((char *) (-3 + proposal_1334X))) + -4))))>>2))))) {
            if ((4 == ((((3 + ((long)(((unsigned long)(*((long *) ((((char *) (-3 + proposal_1334X))) + -4))))>>8))))>>2)))) {
              if ((1 == (*((long *) (((char *) (-3 + proposal_1334X))))))) {
                goto L48919;}
              else {
                goto L48950;}}
            else {
              goto L48950;}}
          else {
            goto L48950;}}
        else {
          goto L48950;}}}
      break;
    case 138 : {
      proposal_1335X = *((long *) ((((char *) (-3 + (Scurrent_threadS)))) + 12));
      if ((1 == proposal_1335X)) {push_exception_setupB(26, 1);
        arg0K0 = 0;
        goto L30610;}
      else {GET_PROPOSAL_LOCK();
        log_1336X = *((long *) ((((char *) (-3 + proposal_1335X))) + 4));
        arg0K0 = 0;
        goto L14222;}}
      break;
    case 139 : {
      stob_1337X = SvalS;
      type_1338X = *((unsigned char *) ((Scode_pointerS) + 1));
      offset_1339X = *((unsigned char *) ((Scode_pointerS) + 2));
      if ((3 == (3 & stob_1337X))) {
        if (((31 & ((((*((long *) ((((char *) (-3 + stob_1337X))) + -4))))>>2))) == type_1338X)) {
          x_1340X = *((long *) ((((char *) (-3 + (Scurrent_threadS)))) + 12));
          if ((1 == x_1340X)) {
            arg0K0 = (*((long *) ((((char *) (-3 + stob_1337X))) + (((offset_1339X)<<2)))));
            goto L37612;}
          else {
            merged_arg0K0 = stob_1337X;
            merged_arg0K1 = (((offset_1339X)<<2));
            proposal_d_read_return_tag = 1;
            goto proposal_d_read;
           proposal_d_read_return_1:
            v_1341X = proposal_d_read0_return_value;
            arg0K0 = v_1341X;
            goto L37612;}}
        else {
          goto L37613;}}
      else {
        goto L37613;}}
      break;
    case 140 : {
      arg2_1342X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      arg3_1343X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      arg4_1344X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      arg5_1345X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      if ((3 == (3 & arg5_1345X))) {
        if ((17 == (31 & ((((*((long *) ((((char *) (-3 + arg5_1345X))) + -4))))>>2))))) {
          if ((0 == (3 & arg4_1344X))) {
            if ((3 == (3 & arg3_1343X))) {
              if ((17 == (31 & ((((*((long *) ((((char *) (-3 + arg3_1343X))) + -4))))>>2))))) {
                if ((0 == (3 & (arg2_1342X | (SvalS))))) {
                  from_index_1346X = ((arg4_1344X)>>2);
                  to_index_1347X = ((arg2_1342X)>>2);
                  count_1348X = (((SvalS))>>2);
                  v_1349X = *((unsigned char *) ((Scode_pointerS) + 1));
                  if ((from_index_1346X < 0)) {
                    goto L37706;}
                  else {
                    if ((((long)(((unsigned long)(*((long *) ((((char *) (-3 + arg5_1345X))) + -4))))>>8)) < (from_index_1346X + count_1348X))) {
                      goto L37706;}
                    else {
                      if ((to_index_1347X < 0)) {
                        goto L37706;}
                      else {
                        if ((((long)(((unsigned long)(*((long *) ((((char *) (-3 + arg3_1343X))) + -4))))>>8)) < (to_index_1347X + count_1348X))) {
                          goto L37706;}
                        else {
                          if ((3 == (3 & arg3_1343X))) {
                            if ((0 == (128 & (*((long *) ((((char *) (-3 + arg3_1343X))) + -4)))))) {
                              if ((count_1348X < 0)) {
                                goto L37706;}
                              else {
                                if ((0 == v_1349X)) {
                                  goto L37766;}
                                else {
                                  if ((1 == (*((long *) ((((char *) (-3 + (Scurrent_threadS)))) + 12))))) {
                                    goto L37766;}
                                  else {
                                    arg0K0 = 4096;
                                    arg0K1 = (*((long *) ((((char *) (-3 + (*((long *) ((((char *) (-3 + (Scurrent_threadS)))) + 12)))))) + 12)));
                                    goto L37863;}}}}
                            else {
                              goto L37706;}}
                          else {
                            goto L37706;}}}}}}
                else {
                  goto L42783;}}
              else {
                goto L42783;}}
            else {
              goto L42783;}}
          else {
            goto L42783;}}
        else {
          goto L42783;}}
      else {
        goto L42783;}}
      break;
    case 141 : {
      arg2_1350X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      if ((3 == (3 & arg2_1350X))) {
        if ((17 == (31 & ((((*((long *) ((((char *) (-3 + arg2_1350X))) + -4))))>>2))))) {
          if ((0 == (3 & (SvalS)))) {
            index_1351X = (((SvalS))>>2);
            len_1352X = (long)(((unsigned long)(*((long *) ((((char *) (-3 + arg2_1350X))) + -4))))>>8);
            if ((index_1351X < 0)) {
              goto L38132;}
            else {
              if ((index_1351X < len_1352X)) {
                x_1353X = *((long *) ((((char *) (-3 + (Scurrent_threadS)))) + 12));
                if ((1 == x_1353X)) {
                  arg0K0 = ((((*((unsigned char *) ((((char *) (-3 + arg2_1350X))) + index_1351X))))<<2));
                  goto L38131;}
                else {
                  index_1354X = ((index_1351X)<<2);
                  log_1355X = *((long *) ((((char *) (-3 + (*((long *) ((((char *) (-3 + (Scurrent_threadS)))) + 12)))))) + 8));
                  arg0K0 = 0;
                  goto L20642;}}
              else {
                goto L38132;}}}
          else {
            goto L42979;}}
        else {
          goto L42979;}}
      else {
        goto L42979;}}
      break;
    case 142 : {
      arg2_1356X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      arg3_1357X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      if ((3 == (3 & arg3_1357X))) {
        if ((17 == (31 & ((((*((long *) ((((char *) (-3 + arg3_1357X))) + -4))))>>2))))) {
          if ((0 == (3 & arg2_1356X))) {
            index_1358X = ((arg2_1356X)>>2);
            byte_1359X = SvalS;
            if ((3 == (3 & arg3_1357X))) {
              if ((0 == (128 & (*((long *) ((((char *) (-3 + arg3_1357X))) + -4)))))) {
                if ((0 == (3 & byte_1359X))) {
                  len_1360X = (long)(((unsigned long)(*((long *) ((((char *) (-3 + arg3_1357X))) + -4))))>>8);
                  if ((index_1358X < 0)) {
                    goto L38258;}
                  else {
                    if ((index_1358X < len_1360X)) {
                      x_1361X = *((long *) ((((char *) (-3 + (Scurrent_threadS)))) + 12));
                      if ((1 == x_1361X)) {
                        *((unsigned char *) ((((char *) (-3 + arg3_1357X))) + index_1358X)) = (unsigned char) ((((byte_1359X)>>2)));
                        goto L38257;}
                      else {
                        index_1362X = ((index_1358X)<<2);
                        log_1363X = *((long *) ((((char *) (-3 + (*((long *) ((((char *) (-3 + (Scurrent_threadS)))) + 12)))))) + 8));
                        arg0K0 = 0;
                        goto L20818;}}
                    else {
                      goto L38258;}}}
                else {
                  goto L38223;}}
              else {
                goto L38223;}}
            else {
              goto L38223;}}
          else {
            goto L43084;}}
        else {
          goto L43084;}}
      else {
        goto L43084;}}
      break;
    case 143 : {
      SvalS = 529;
      Scode_pointerS = ((Scode_pointerS) + 1);
      arg3K0 = (Scode_pointerS);
      goto L32913;}
      break;
    case 144 : {
      SvalS = 13;
      Scode_pointerS = ((Scode_pointerS) + 1);
      arg3K0 = (Scode_pointerS);
      goto L32913;}
      break;
    case 145 : {
      x_1364X = SvalS;push_exception_setupB(15, 1);
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (x_1364X);
      arg0K0 = 1;
      goto L30610;}
      break;
    case 146 : {
      SvalS = 1;
      Scode_pointerS = ((Scode_pointerS) + 1);
      arg3K0 = (Scode_pointerS);
      goto L32913;}
      break;
    case 147 : {
      SvalS = 21;
      Scode_pointerS = ((Scode_pointerS) + 1);
      arg3K0 = (Scode_pointerS);
      goto L32913;}
      break;
    case 148 : {s48_make_availableAgc(2052);
      arg2_1365X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      arg3_1366X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      arg4_1367X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      if ((3 == (3 & arg4_1367X))) {
        if ((17 == (31 & ((((*((long *) ((((char *) (-3 + arg4_1367X))) + -4))))>>2))))) {
          if ((3 == (3 & arg2_1365X))) {
            if ((17 == (31 & ((((*((long *) ((((char *) (-3 + arg2_1365X))) + -4))))>>2))))) {
              obj_1368X = SvalS;
              if ((3 == (3 & obj_1368X))) {
                if ((2 == (31 & ((((*((long *) ((((char *) (-3 + obj_1368X))) + -4))))>>2))))) {
                  undumpables_1369X = SvalS;
                  port_1370X = ps_open_output_file((((char *)(((char *) (-3 + arg4_1367X))))), &status_1371X);
                  if ((status_1371X == NO_ERRORS)) {
                    status_1372X = ps_write_string((((char *)(((char *) (-3 + arg2_1365X))))), port_1370X);
                    if ((status_1372X == NO_ERRORS)) {
                      status_1373X = s48_write_image(arg3_1366X, undumpables_1369X, port_1370X);
                      if ((status_1373X == NO_ERRORS)) {
                        status_1374X = ps_close(port_1370X);
                        if ((status_1374X == NO_ERRORS)) {
                          SvalS = 13;
                          Scode_pointerS = ((Scode_pointerS) + 1);
                          arg3K0 = (Scode_pointerS);
                          goto L32913;}
                        else {
                          arg0K0 = 24;
                          arg0K1 = status_1374X;
                          goto L52729;}}
                      else {
                        status_1375X = ps_close(port_1370X);
                        if ((status_1375X == NO_ERRORS)) {
                          arg0K0 = 24;
                          arg0K1 = status_1373X;
                          goto L52729;}
                        else {
                          ps_write_string("Unable to close image file", (stderr));
                          { long ignoreXX;
                          PS_WRITE_CHAR(10, (stderr), ignoreXX) }
                          arg0K0 = 24;
                          arg0K1 = status_1373X;
                          goto L52729;}}}
                    else {
                      status_1376X = ps_close(port_1370X);
                      if ((status_1376X == NO_ERRORS)) {
                        arg0K0 = 24;
                        arg0K1 = status_1372X;
                        goto L52729;}
                      else {
                        ps_write_string("Unable to close image file", (stderr));
                        { long ignoreXX;
                        PS_WRITE_CHAR(10, (stderr), ignoreXX) }
                        arg0K0 = 24;
                        arg0K1 = status_1372X;
                        goto L52729;}}}
                  else {
                    arg0K0 = 10;
                    arg0K1 = status_1371X;
                    goto L52729;}}
                else {
                  goto L57747;}}
              else {
                goto L57747;}}
            else {
              goto L57747;}}
          else {
            goto L57747;}}
        else {
          goto L57747;}}
      else {
        goto L57747;}}
      break;
    case 149 : {
      SvalS = 13;s48_collect(1);
      Scode_pointerS = ((Scode_pointerS) + 1);
      arg3K0 = (Scode_pointerS);
      goto L32913;}
      break;
    case 150 : {
      obj_1377X = SvalS;
      if ((3 == (3 & obj_1377X))) {
        if ((16 == (31 & ((((*((long *) ((((char *) (-3 + obj_1377X))) + -4))))>>2))))) {
          x_1378X = Haction4880((SvalS));
          SvalS = (((x_1378X)<<2));
          Scode_pointerS = ((Scode_pointerS) + 1);
          arg3K0 = (Scode_pointerS);
          goto L32913;}
        else {
          goto L58460;}}
      else {
        goto L58460;}}
      break;
    case 151 : {s48_make_availableAgc(24);
      arg2_1379X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      proc_1380X = SvalS;
      if ((3 == (3 & arg2_1379X))) {
        if ((3 == (3 & proc_1380X))) {
          if ((3 == (31 & ((((*((long *) ((((char *) (-3 + proc_1380X))) + -4))))>>2))))) {GET_PROPOSAL_LOCK();
            addr_1381X = s48_allocate_small(12);
            *((long *) addr_1381X) = (long) (2050);
            x_1382X = 3 + (((long) (addr_1381X + 4)));
            *((long *) (((char *) (-3 + x_1382X)))) = (long) (arg2_1379X);
            *((long *) ((((char *) (-3 + x_1382X))) + 4)) = (long) (proc_1380X);
            b_1383X = SHARED_REF((Sfinalizer_alistS));
            addr_1384X = s48_allocate_small(12);
            *((long *) addr_1384X) = (long) (2050);
            x_1385X = 3 + (((long) (addr_1384X + 4)));
            *((long *) (((char *) (-3 + x_1385X)))) = (long) (x_1382X);
            *((long *) ((((char *) (-3 + x_1385X))) + 4)) = (long) (b_1383X);SHARED_SETB((Sfinalizer_alistS), x_1385X);RELEASE_PROPOSAL_LOCK();
            SvalS = 13;
            Scode_pointerS = ((Scode_pointerS) + 1);
            arg3K0 = (Scode_pointerS);
            goto L32913;}
          else {
            goto L53004;}}
        else {
          goto L53004;}}
      else {
        goto L53004;}}
      break;
    case 152 : {
      arg2_1386X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      if ((0 == (3 & arg2_1386X))) {
        key_1387X = ((arg2_1386X)>>2);
        other_1388X = SvalS;
        if ((6 == key_1387X)) {
          SvalS = (-4 & other_1388X);
          Scode_pointerS = ((Scode_pointerS) + 1);
          arg3K0 = (Scode_pointerS);
          goto L32913;}
        else {
          if ((0 == key_1387X)) {
            x_1389X = s48_available();
            SvalS = (((x_1389X)<<2));
            Scode_pointerS = ((Scode_pointerS) + 1);
            arg3K0 = (Scode_pointerS);
            goto L32913;}
          else {
            if ((1 == key_1387X)) {
              bytes_1390X = s48_heap_size();
              SvalS = (-4 & (3 + bytes_1390X));
              Scode_pointerS = ((Scode_pointerS) + 1);
              arg3K0 = (Scode_pointerS);
              goto L32913;}
            else {
              if ((2 == key_1387X)) {
                x_1391X = s48_max_heap_size();
                SvalS = (((x_1391X)<<2));
                Scode_pointerS = ((Scode_pointerS) + 1);
                arg3K0 = (Scode_pointerS);
                goto L32913;}
              else {
                if ((3 == key_1387X)) {
                  SvalS = (((((Sstack_endS) - (Sstack_beginS)))<<2));
                  Scode_pointerS = ((Scode_pointerS) + 1);
                  arg3K0 = (Scode_pointerS);
                  goto L32913;}
                else {
                  if ((4 == key_1387X)) {
                    x_1392X = s48_gc_count();
                    SvalS = (((x_1392X)<<2));
                    Scode_pointerS = ((Scode_pointerS) + 1);
                    arg3K0 = (Scode_pointerS);
                    goto L32913;}
                  else {
                    if ((5 == key_1387X)) {push_exception_setupB(14, 1);
                      SstackS = ((SstackS) + -4);
                      *((long *) (SstackS)) = (long) ((((key_1387X)<<2)));
                      SstackS = ((SstackS) + -4);
                      *((long *) (SstackS)) = (long) (other_1388X);
                      arg0K0 = 2;
                      goto L30610;}
                    else {push_exception_setupB(17, 1);
                      SstackS = ((SstackS) + -4);
                      *((long *) (SstackS)) = (long) ((((key_1387X)<<2)));
                      SstackS = ((SstackS) + -4);
                      *((long *) (SstackS)) = (long) (other_1388X);
                      arg0K0 = 2;
                      goto L30610;}}}}}}}}
      else {push_exception_setupB(5, 1);
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (arg2_1386X);
        x_1393X = SvalS;
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (x_1393X);
        arg0K0 = 2;
        goto L30610;}}
      break;
    case 153 : {
      if ((0 == (3 & (SvalS)))) {
        type_1394X = (((SvalS))>>2);
        arg4K0 = 1;
        goto L56075;}
      else {push_exception_setupB(5, 1);
        x_1395X = SvalS;
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (x_1395X);
        arg0K0 = 1;
        goto L30610;}}
      break;
    case 154 : {
      x_1396X = SvalS;
      arg4K0 = 1;
      arg0K1 = x_1396X;
      goto L62473;}
      break;
    case 155 : {
      SvalS = (Scurrent_threadS);
      Scode_pointerS = ((Scode_pointerS) + 1);
      arg3K0 = (Scode_pointerS);
      goto L32913;}
      break;
    case 156 : {
      Scurrent_threadS = (SvalS);
      SvalS = 13;
      Scode_pointerS = ((Scode_pointerS) + 1);
      arg3K0 = (Scode_pointerS);
      goto L32913;}
      break;
    case 157 : {
      val_1397X = SHARED_REF((Ssession_dataS));
      SvalS = val_1397X;
      Scode_pointerS = ((Scode_pointerS) + 1);
      arg3K0 = (Scode_pointerS);
      goto L32913;}
      break;
    case 158 : {SHARED_SETB((Ssession_dataS), (SvalS));
      SvalS = 13;
      Scode_pointerS = ((Scode_pointerS) + 1);
      arg3K0 = (Scode_pointerS);
      goto L32913;}
      break;
    case 159 : {
      obj_1398X = SvalS;
      if ((3 == (3 & obj_1398X))) {
        if ((2 == (31 & ((((*((long *) ((((char *) (-3 + obj_1398X))) + -4))))>>2))))) {
          if ((((((3 + ((long)(((unsigned long)(*((long *) ((((char *) (-3 + (SvalS)))) + -4))))>>8))))>>2)) < 195)) {
            goto L34657;}
          else {
            temp_1399X = SHARED_REF((Sexception_handlersS));SHARED_SETB((Sexception_handlersS), (SvalS));
            SvalS = temp_1399X;
            Scode_pointerS = ((Scode_pointerS) + 1);
            arg3K0 = (Scode_pointerS);
            goto L32913;}}
        else {
          goto L34657;}}
      else {
        goto L34657;}}
      break;
    case 160 : {
      data_1400X = 3 + (((long) (SstackS)));
      SstackS = ((SstackS) + 20);
      code_1401X = *((long *) ((((char *) (-3 + data_1400X))) + 8));
      exception_1402X = *((long *) ((((char *) (-3 + data_1400X))) + 12));
      size_1403X = *((long *) ((((char *) (-3 + data_1400X))) + 16));
      pc_1404X = (((*((long *) ((((char *) (-3 + data_1400X))) + 4))))>>2);
      opcode_1405X = *((unsigned char *) ((((char *) (-3 + code_1401X))) + pc_1404X));
      if ((opcode_1405X < 51)) {
        if ((4 == opcode_1405X)) {
          goto L32995;}
        else {
          Slast_code_calledS = code_1401X;
          Scode_pointerS = ((((char *) (-3 + code_1401X))) + pc_1404X);push_exception_setupB(28, 1);
          SstackS = ((SstackS) + -4);
          *((long *) (SstackS)) = (long) (exception_1402X);
          arg0K0 = 1;
          goto L30610;}}
      else {
        goto L32995;}}
      break;
    case 161 : {
      data_1406X = 3 + (((long) (SstackS)));
      SstackS = ((SstackS) + 20);
      code_1407X = *((long *) ((((char *) (-3 + data_1406X))) + 8));
      exception_1408X = *((long *) ((((char *) (-3 + data_1406X))) + 12));
      opcode_1409X = (((*((long *) ((((char *) (-3 + data_1406X))) + 4))))>>2);
      if ((opcode_1409X < 51)) {
        if ((4 == opcode_1409X)) {
          goto L30871;}
        else {
          Slast_code_calledS = code_1407X;
          Scode_pointerS = (((char *) (-3 + code_1407X)));push_exception_setupB(28, 1);
          SstackS = ((SstackS) + -4);
          *((long *) (SstackS)) = (long) (exception_1408X);
          arg0K0 = 1;
          goto L30610;}}
      else {
        goto L30871;}}
      break;
    case 162 : {
      obj_1410X = SvalS;
      if ((3 == (3 & obj_1410X))) {
        if ((2 == (31 & ((((*((long *) ((((char *) (-3 + obj_1410X))) + -4))))>>2))))) {
          if ((((((3 + ((long)(((unsigned long)(*((long *) ((((char *) (-3 + (SvalS)))) + -4))))>>8))))>>2)) < 7)) {
            goto L33554;}
          else {
            temp_1411X = SHARED_REF((Sinterrupt_handlersS));SHARED_SETB((Sinterrupt_handlersS), (SvalS));
            SvalS = temp_1411X;
            Scode_pointerS = ((Scode_pointerS) + 1);
            arg3K0 = (Scode_pointerS);
            goto L32913;}}
        else {
          goto L33554;}}
      else {
        goto L33554;}}
      break;
    case 163 : {
      old_1412X = Senabled_interruptsS;
      p_1413X = SvalS;
      Senabled_interruptsS = (((p_1413X)>>2));
      if ((0 == ((Spending_interruptsS) & (Senabled_interruptsS)))) {
        s48_Sstack_limitS = (Sreal_stack_limitS);
        if ((s48_Spending_eventsPS)) {
          s48_Sstack_limitS = (((char *) -1));
          goto L62521;}
        else {
          goto L62521;}}
      else {
        s48_Sstack_limitS = (((char *) -1));
        goto L62521;}}
      break;
    case 164 : {
      SstackS = ((SstackS) + 4);
      s48_pop_interrupt_state_return_tag = 0;
      goto s48_pop_interrupt_state;
     s48_pop_interrupt_state_return_0:
      pc_1414X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      code_1415X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      Slast_code_calledS = code_1415X;
      Scode_pointerS = ((((char *) (-3 + code_1415X))) + (((pc_1414X)>>2)));
      v_1416X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      SvalS = v_1416X;
      arg3K0 = (Scode_pointerS);
      goto L32913;}
      break;
    case 165 : {
      SstackS = ((SstackS) + 4);
      s48_pop_interrupt_state_return_tag = 1;
      goto s48_pop_interrupt_state;
     s48_pop_interrupt_state_return_1:
      v_1417X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      SvalS = v_1417X;
      p_1418X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      v_1419X = s48_call_native_procedure((SvalS), (((p_1418X)>>2)));
      arg0K0 = v_1419X;
      goto L60019;}
      break;
    case 166 : {
      SstackS = ((SstackS) + 4);
      s48_pop_interrupt_state_return_tag = 2;
      goto s48_pop_interrupt_state;
     s48_pop_interrupt_state_return_2:
      return_address_1420X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      template_1421X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      v_1422X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      SvalS = v_1422X;
      v_1423X = s48_jump_to_native_address(return_address_1420X, template_1421X);
      arg0K0 = v_1423X;
      goto L60019;}
      break;
    case 167 : {
      if ((0 == (3 & (SvalS)))) {
        p_1424X = SvalS;
        Spending_interruptsS = (-2 & (Spending_interruptsS));
        if ((0 == ((Spending_interruptsS) & (Senabled_interruptsS)))) {
          s48_Sstack_limitS = (Sreal_stack_limitS);
          if ((s48_Spending_eventsPS)) {
            s48_Sstack_limitS = (((char *) -1));
            goto L59576;}
          else {
            goto L59576;}}
        else {
          s48_Sstack_limitS = (((char *) -1));
          goto L59576;}}
      else {push_exception_setupB(5, 1);
        x_1425X = SvalS;
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (x_1425X);
        arg0K0 = 1;
        goto L30610;}}
      break;
    case 168 : {
      arg2_1426X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      if ((0 == (3 & arg2_1426X))) {
        x_1427X = SvalS;
        if ((1 == x_1427X)) {
          goto L57295;}
        else {
          if ((5 == x_1427X)) {
            goto L57295;}
          else {
            goto L57300;}}}
      else {
        goto L57300;}}
      break;
    case 169 : {
      p_1428X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      nargs_1429X = ((p_1428X)>>2);
      p_1430X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      rest_list_1431X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      if ((14 < nargs_1429X)) {push_exception_setupB(19, 1);
        x_1432X = *((long *) ((SstackS) + (-4 + (-4 & p_1430X))));
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (x_1432X);
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (nargs_1429X);
        arg0K0 = 2;
        goto L30610;}
      else {
        arg0K0 = rest_list_1431X;
        goto L38457;}}
      break;
    case 170 : {s48_make_availableAgc(20);
      arg2_1433X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      if ((3 == (3 & arg2_1433X))) {
        if ((16 == (31 & ((((*((long *) ((((char *) (-3 + arg2_1433X))) + -4))))>>2))))) {
          x_1434X = SvalS;
          if ((1 == x_1434X)) {
            goto L56170;}
          else {
            if ((5 == x_1434X)) {
              goto L56170;}
            else {
              goto L56175;}}}
        else {
          goto L56175;}}
      else {
        goto L56175;}}
      break;
    case 171 : {
      arg2_1435X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      if ((3 == (3 & arg2_1435X))) {
        if ((16 == (31 & ((((*((long *) ((((char *) (-3 + arg2_1435X))) + -4))))>>2))))) {
          x_1436X = SvalS;
          if ((1 == x_1436X)) {
            goto L41917;}
          else {
            if ((5 == x_1436X)) {
              goto L41917;}
            else {
              goto L41922;}}}
        else {
          goto L41922;}}
      else {
        goto L41922;}}
      break;
    case 172 : {
      arg4K0 = 1;
      goto L62581;}
      break;
    case 173 : {
      arg2_1437X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      if ((0 == (3 & arg2_1437X))) {
        option_1438X = ((arg2_1437X)>>2);
        other_1439X = SvalS;
        if ((2 == option_1438X)) {
          x_1440X = CHEAP_TIME();
          SvalS = (((x_1440X)<<2));
          Scode_pointerS = ((Scode_pointerS) + 1);
          arg3K0 = (Scode_pointerS);
          goto L32913;}
        else {
          if ((0 == option_1438X)) {
            seconds_1441X = s48_run_time(&mseconds_1442X);
            arg0K0 = option_1438X;
            arg0K1 = seconds_1441X;
            arg0K2 = mseconds_1442X;
            goto L58394;}
          else {
            if ((1 == option_1438X)) {
              seconds_1443X = s48_real_time(&mseconds_1444X);
              arg0K0 = option_1438X;
              arg0K1 = seconds_1443X;
              arg0K2 = mseconds_1444X;
              goto L58394;}
            else {
              if ((3 == option_1438X)) {
                seconds_1445X = s48_gc_run_time(&mseconds_1446X);
                arg0K0 = option_1438X;
                arg0K1 = seconds_1445X;
                arg0K2 = mseconds_1446X;
                goto L58394;}
              else {push_exception_setupB(17, 1);
                SstackS = ((SstackS) + -4);
                *((long *) (SstackS)) = (long) ((((option_1438X)<<2)));
                SstackS = ((SstackS) + -4);
                *((long *) (SstackS)) = (long) (other_1439X);
                arg0K0 = 2;
                goto L30610;}}}}}
      else {push_exception_setupB(5, 1);
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (arg2_1437X);
        x_1447X = SvalS;
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (x_1447X);
        arg0K0 = 2;
        goto L30610;}}
      break;
    case 174 : {
      if ((0 == (3 & (SvalS)))) {
        key_1448X = (((SvalS))>>2);
        if ((0 == key_1448X)) {
          val_1449X = enter_stringAgc_n(S48_HOST_ARCHITECTURE, (strlen((char *) S48_HOST_ARCHITECTURE)));
          SvalS = val_1449X;
          Scode_pointerS = ((Scode_pointerS) + 1);
          arg3K0 = (Scode_pointerS);
          goto L32913;}
        else {
          if ((1 == key_1448X)) {
            string_1450X = s48_get_os_string_encoding();
            val_1451X = enter_stringAgc_n(string_1450X, (strlen((char *) string_1450X)));
            SvalS = val_1451X;
            Scode_pointerS = ((Scode_pointerS) + 1);
            arg3K0 = (Scode_pointerS);
            goto L32913;}
          else {push_exception_setupB(17, 1);
            SstackS = ((SstackS) + -4);
            *((long *) (SstackS)) = (long) ((((key_1448X)<<2)));
            arg0K0 = 1;
            goto L30610;}}}
      else {push_exception_setupB(5, 1);
        x_1452X = SvalS;
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (x_1452X);
        arg0K0 = 1;
        goto L30610;}}
      break;
    case 175 : {
      arg2_1453X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      if ((0 == (3 & arg2_1453X))) {
        key_1454X = ((arg2_1453X)>>2);
        value_1455X = SvalS;
        status_1456X = s48_extended_vm(key_1454X, value_1455X);
        if ((0 == status_1456X)) {
          SvalS = (s48_Sextension_valueS);
          Scode_pointerS = ((Scode_pointerS) + 1);
          arg3K0 = (Scode_pointerS);
          goto L32913;}
        else {
          if ((1 == status_1456X)) {push_exception_setupB(22, 1);
            SstackS = ((SstackS) + -4);
            *((long *) (SstackS)) = (long) ((((key_1454X)<<2)));
            SstackS = ((SstackS) + -4);
            *((long *) (SstackS)) = (long) (value_1455X);
            arg0K0 = 2;
            goto L30610;}
          else {push_exception_setupB(23, 1);
            SstackS = ((SstackS) + -4);
            *((long *) (SstackS)) = (long) ((((key_1454X)<<2)));
            SstackS = ((SstackS) + -4);
            *((long *) (SstackS)) = (long) (value_1455X);
            arg0K0 = 2;
            goto L30610;}}}
      else {push_exception_setupB(5, 1);
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (arg2_1453X);
        x_1457X = SvalS;
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (x_1457X);
        arg0K0 = 2;
        goto L30610;}}
      break;
    case 176 : {
      arg2_1458X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      x_1459X = SvalS;
      Senabled_interruptsS = -1;
      if ((0 == ((Spending_interruptsS) & (Senabled_interruptsS)))) {
        s48_Sstack_limitS = (Sreal_stack_limitS);
        if ((s48_Spending_eventsPS)) {
          s48_Sstack_limitS = (((char *) -1));
          goto L62638;}
        else {
          goto L62638;}}
      else {
        s48_Sstack_limitS = (((char *) -1));
        goto L62638;}}
      break;
    case 177 : {
      arg2_1460X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      if ((3 == (3 & arg2_1460X))) {
        if ((16 == (31 & ((((*((long *) ((((char *) (-3 + arg2_1460X))) + -4))))>>2))))) {
          obj_1461X = SvalS;
          if ((3 == (3 & obj_1461X))) {
            if ((16 == (31 & ((((*((long *) ((((char *) (-3 + obj_1461X))) + -4))))>>2))))) {
              x_1462X = SvalS;
              len_1463X = (long)(((unsigned long)(*((long *) ((((char *) (-3 + arg2_1460X))) + -4))))>>8);
              if ((len_1463X == ((long)(((unsigned long)(*((long *) ((((char *) (-3 + x_1462X))) + -4))))>>8)))) {
                if (((!memcmp((void *)(((char *) (-3 + x_1462X))), (void *)(((char *) (-3 + arg2_1460X))),len_1463X)))) {
                  arg0K0 = 5;
                  goto L50604;}
                else {
                  arg0K0 = 1;
                  goto L50604;}}
              else {
                arg0K0 = 1;
                goto L50604;}}
            else {
              goto L50569;}}
          else {
            goto L50569;}}
        else {
          goto L50569;}}
      else {
        goto L50569;}}
      break;
    case 178 : {s48_make_availableAgc((4 + (-4 & (3 + (-4 & (SvalS))))));
      arg2_1464X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      if ((0 == (3 & (SvalS)))) {
        n_1465X = (((SvalS))>>2);
        if ((3 == (3 & arg2_1464X))) {
          if ((0 == (31 & ((((*((long *) ((((char *) (-3 + arg2_1464X))) + -4))))>>2))))) {
            goto L49788;}
          else {
            goto L49740;}}
        else {
          goto L49740;}}
      else {push_exception_setupB(5, 1);
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (arg2_1464X);
        x_1466X = SvalS;
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (x_1466X);
        arg0K0 = 2;
        goto L30610;}}
      break;
    case 179 : {
      arg2_1467X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      list_1468X = SvalS;
      arg0K0 = list_1468X;
      arg0K1 = list_1468X;
      arg4K2 = 1;
      goto L51747;}
      break;
    case 180 : {
      if ((529 == (SvalS))) {push_exception_setupB(0, 1);
        arg0K0 = 0;
        goto L30610;}
      else {
        Scode_pointerS = ((Scode_pointerS) + 1);
        arg3K0 = (Scode_pointerS);
        goto L32913;}}
      break;
    case 181 : {
      arg2_1469X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      arg3_1470X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      if ((0 == (3 & (SvalS)))) {
        index_1471X = (((SvalS))>>2);
        if ((3 == (3 & arg3_1470X))) {
          if ((9 == (31 & ((((*((long *) ((((char *) (-3 + arg3_1470X))) + -4))))>>2))))) {
            if ((arg2_1469X == (*((long *) (((char *) (-3 + arg3_1470X))))))) {
              len_1472X = (((3 + ((long)(((unsigned long)(*((long *) ((((char *) (-3 + arg3_1470X))) + -4))))>>8))))>>2);
              if ((index_1471X < 0)) {
                goto L38789;}
              else {
                if ((index_1471X < len_1472X)) {
                  v_1473X = *((unsigned char *) ((Scode_pointerS) + 1));
                  if ((0 == v_1473X)) {
                    goto L38779;}
                  else {
                    if ((1 == (*((long *) ((((char *) (-3 + (Scurrent_threadS)))) + 12))))) {
                      goto L38779;}
                    else {
                      merged_arg0K0 = arg3_1470X;
                      merged_arg0K1 = (((index_1471X)<<2));
                      proposal_d_read_return_tag = 2;
                      goto proposal_d_read;
                     proposal_d_read_return_2:
                      v_1474X = proposal_d_read0_return_value;
                      arg0K0 = v_1474X;
                      goto L38788;}}}
                else {
                  goto L38789;}}}
            else {
              goto L38809;}}
          else {
            goto L38809;}}
        else {
          goto L38809;}}
      else {push_exception_setupB(5, 1);
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (arg3_1470X);
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (arg2_1469X);
        x_1475X = SvalS;
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (x_1475X);
        arg0K0 = 3;
        goto L30610;}}
      break;
    case 182 : {
      arg2_1476X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      arg3_1477X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      arg4_1478X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      if ((0 == (3 & arg2_1476X))) {
        index_1479X = ((arg2_1476X)>>2);
        value_1480X = SvalS;
        if ((3 == (3 & arg4_1478X))) {
          if ((9 == (31 & ((((*((long *) ((((char *) (-3 + arg4_1478X))) + -4))))>>2))))) {
            if ((arg3_1477X == (*((long *) (((char *) (-3 + arg4_1478X))))))) {
              if ((3 == (3 & arg4_1478X))) {
                if ((0 == (128 & (*((long *) ((((char *) (-3 + arg4_1478X))) + -4)))))) {
                  len_1481X = (((3 + ((long)(((unsigned long)(*((long *) ((((char *) (-3 + arg4_1478X))) + -4))))>>8))))>>2);
                  if ((index_1479X < 0)) {
                    goto L39047;}
                  else {
                    if ((index_1479X < len_1481X)) {
                      v_1482X = *((unsigned char *) ((Scode_pointerS) + 1));
                      if ((0 == v_1482X)) {
                        goto L39037;}
                      else {
                        if ((1 == (*((long *) ((((char *) (-3 + (Scurrent_threadS)))) + 12))))) {
                          goto L39037;}
                        else {
                          merged_arg0K0 = arg4_1478X;
                          merged_arg0K1 = (((index_1479X)<<2));
                          merged_arg0K2 = value_1480X;
                          proposal_d_write_return_tag = 2;
                          goto proposal_d_write;
                         proposal_d_write_return_2:
                          goto L39046;}}}
                    else {
                      goto L39047;}}}
                else {
                  goto L39069;}}
              else {
                goto L39069;}}
            else {
              goto L39069;}}
          else {
            goto L39069;}}
        else {
          goto L39069;}}
      else {push_exception_setupB(5, 1);
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (arg4_1478X);
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (arg3_1477X);
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (arg2_1476X);
        x_1483X = SvalS;
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (x_1483X);
        arg0K0 = 4;
        goto L30610;}}
      break;
    case 183 : {
      arg2_1484X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      arg3_1485X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      arg4_1486X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      arg5_1487X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      if ((0 == (3 & arg5_1487X))) {
        if ((9 == (255 & arg4_1486X))) {
          if ((3 == (3 & arg3_1485X))) {
            if ((17 == (31 & ((((*((long *) ((((char *) (-3 + arg3_1485X))) + -4))))>>2))))) {
              if ((0 == (3 & (arg2_1484X | (SvalS))))) {
                encoding_1488X = ((arg5_1487X)>>2);
                value_1489X = ((arg4_1486X)>>8);
                start_1490X = ((arg2_1484X)>>2);
                count_1491X = (((SvalS))>>2);
                if ((3 == (3 & arg3_1485X))) {
                  if ((0 == (128 & (*((long *) ((((char *) (-3 + arg3_1485X))) + -4)))))) {
                    if ((start_1490X < 0)) {
                      goto L31229;}
                    else {
                      if ((count_1491X < 0)) {
                        goto L31229;}
                      else {
                        if ((((long)(((unsigned long)(*((long *) ((((char *) (-3 + arg3_1485X))) + -4))))>>8)) < (start_1490X + count_1491X))) {
                          goto L31229;}
                        else {
                          encoding_okP_1492X = encode_scalar_value(encoding_1488X, value_1489X, ((((char *) (-3 + arg3_1485X))) + start_1490X), count_1491X, &okP_1493X, &out_of_spaceP_1494X, &count_1495X);
                          if (encoding_okP_1492X) {
                            if (okP_1493X) {
                              if (out_of_spaceP_1494X) {
                                arg0K0 = 1;
                                goto L31281;}
                              else {
                                arg0K0 = 5;
                                goto L31281;}}
                            else {
                              arg0K0 = 1;
                              goto L31281;}}
                          else {push_exception_setupB(17, 1);
                            SstackS = ((SstackS) + -4);
                            *((long *) (SstackS)) = (long) ((((encoding_1488X)<<2)));
                            arg0K0 = 1;
                            goto L30610;}}}}}
                  else {
                    goto L31229;}}
                else {
                  goto L31229;}}
              else {
                goto L31959;}}
            else {
              goto L31959;}}
          else {
            goto L31959;}}
        else {
          goto L31959;}}
      else {
        goto L31959;}}
      break;
    case 184 : {
      arg2_1496X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      arg3_1497X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      arg4_1498X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      arg5_1499X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      if ((0 == (3 & arg5_1499X))) {
        if ((9 == (255 & arg4_1498X))) {
          if ((3 == (3 & arg3_1497X))) {
            if ((17 == (31 & ((((*((long *) ((((char *) (-3 + arg3_1497X))) + -4))))>>2))))) {
              if ((0 == (3 & (arg2_1496X | (SvalS))))) {
                encoding_1500X = ((arg5_1499X)>>2);
                value_1501X = ((arg4_1498X)>>8);
                start_1502X = ((arg2_1496X)>>2);
                count_1503X = (((SvalS))>>2);
                if ((3 == (3 & arg3_1497X))) {
                  if ((0 == (128 & (*((long *) ((((char *) (-3 + arg3_1497X))) + -4)))))) {
                    if ((start_1502X < 0)) {
                      goto L49943;}
                    else {
                      if ((count_1503X < 0)) {
                        goto L49943;}
                      else {
                        if ((((long)(((unsigned long)(*((long *) ((((char *) (-3 + arg3_1497X))) + -4))))>>8)) < (start_1502X + count_1503X))) {
                          goto L49943;}
                        else {
                          encoding_okP_1504X = encode_scalar_value(encoding_1500X, value_1501X, ((((char *) (-3 + arg3_1497X))) + start_1502X), count_1503X, &okP_1505X, &out_of_spaceP_1506X, &count_1507X);
                          if (encoding_okP_1504X) {
                            SvalS = 13;
                            Scode_pointerS = ((Scode_pointerS) + 1);
                            arg3K0 = (Scode_pointerS);
                            goto L32913;}
                          else {push_exception_setupB(17, 1);
                            SstackS = ((SstackS) + -4);
                            *((long *) (SstackS)) = (long) ((((encoding_1500X)<<2)));
                            arg0K0 = 1;
                            goto L30610;}}}}}
                  else {
                    goto L49943;}}
                else {
                  goto L49943;}}
              else {
                goto L56579;}}
            else {
              goto L56579;}}
          else {
            goto L56579;}}
        else {
          goto L56579;}}
      else {
        goto L56579;}}
      break;
    case 185 : {
      arg2_1508X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      arg3_1509X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      arg4_1510X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      if ((0 == (3 & arg4_1510X))) {
        if ((3 == (3 & arg3_1509X))) {
          if ((17 == (31 & ((((*((long *) ((((char *) (-3 + arg3_1509X))) + -4))))>>2))))) {
            if ((0 == (3 & (arg2_1508X | (SvalS))))) {
              encoding_1511X = ((arg4_1510X)>>2);
              start_1512X = ((arg2_1508X)>>2);
              count_1513X = (((SvalS))>>2);
              if ((start_1512X < 0)) {
                goto L31514;}
              else {
                if ((count_1513X < 0)) {
                  goto L31514;}
                else {
                  if ((((long)(((unsigned long)(*((long *) ((((char *) (-3 + arg3_1509X))) + -4))))>>8)) < (start_1512X + count_1513X))) {
                    goto L31514;}
                  else {
                    encoding_okP_1514X = decode_scalar_value(encoding_1511X, ((((char *) (-3 + arg3_1509X))) + start_1512X), count_1513X, &okP_1515X, &incompleteP_1516X, &value_1517X, &count_1518X);
                    if (encoding_okP_1514X) {
                      if (okP_1515X) {
                        if (incompleteP_1516X) {
                          arg0K0 = 1;
                          goto L31580;}
                        else {
                          arg0K0 = (9 + (((value_1517X)<<8)));
                          goto L31580;}}
                      else {
                        arg0K0 = 1;
                        goto L31580;}}
                    else {push_exception_setupB(17, 1);
                      SstackS = ((SstackS) + -4);
                      *((long *) (SstackS)) = (long) ((((encoding_1511X)<<2)));
                      arg0K0 = 1;
                      goto L30610;}}}}}
            else {
              goto L32155;}}
          else {
            goto L32155;}}
        else {
          goto L32155;}}
      else {
        goto L32155;}}
      break;
    case 186 : {
      arg2_1519X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      arg3_1520X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      arg4_1521X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      if ((0 == (3 & arg4_1521X))) {
        if ((3 == (3 & arg3_1520X))) {
          if ((17 == (31 & ((((*((long *) ((((char *) (-3 + arg3_1520X))) + -4))))>>2))))) {
            if ((0 == (3 & (arg2_1519X | (SvalS))))) {
              encoding_1522X = ((arg4_1521X)>>2);
              start_1523X = ((arg2_1519X)>>2);
              count_1524X = (((SvalS))>>2);
              if ((start_1523X < 0)) {
                goto L50162;}
              else {
                if ((count_1524X < 0)) {
                  goto L50162;}
                else {
                  if ((((long)(((unsigned long)(*((long *) ((((char *) (-3 + arg3_1520X))) + -4))))>>8)) < (start_1523X + count_1524X))) {
                    goto L50162;}
                  else {
                    encoding_okP_1525X = decode_scalar_value(encoding_1522X, ((((char *) (-3 + arg3_1520X))) + start_1523X), count_1524X, &okP_1526X, &incompleteP_1527X, &value_1528X, &count_1529X);
                    if (encoding_okP_1525X) {
                      SvalS = 13;
                      Scode_pointerS = ((Scode_pointerS) + 1);
                      arg3K0 = (Scode_pointerS);
                      goto L32913;}
                    else {push_exception_setupB(17, 1);
                      SstackS = ((SstackS) + -4);
                      *((long *) (SstackS)) = (long) ((((encoding_1522X)<<2)));
                      arg0K0 = 1;
                      goto L30610;}}}}}
            else {
              goto L56775;}}
          else {
            goto L56775;}}
        else {
          goto L56775;}}
      else {
        goto L56775;}}
      break;
    case 187 : {
      v_1530X = *((unsigned char *) ((Scode_pointerS) + 1));
      if ((0 == v_1530X)) {
        arg0K0 = (SvalS);
        goto L39326;}
      else {
        merged_arg0K0 = 0;
        get_current_port_return_tag = 0;
        goto get_current_port;
       get_current_port_return_0:
        v_1531X = get_current_port0_return_value;
        arg0K0 = v_1531X;
        goto L39326;}}
      break;
    case 188 : {
      v_1532X = *((unsigned char *) ((Scode_pointerS) + 1));
      if ((0 == v_1532X)) {
        arg0K0 = (SvalS);
        goto L39528;}
      else {
        merged_arg0K0 = 0;
        get_current_port_return_tag = 1;
        goto get_current_port;
       get_current_port_return_1:
        v_1533X = get_current_port0_return_value;
        arg0K0 = v_1533X;
        goto L39528;}}
      break;
    case 189 : {
      v_1534X = *((unsigned char *) ((Scode_pointerS) + 1));
      if ((0 == v_1534X)) {
        v_1535X = *((long *) (SstackS));
        SstackS = ((SstackS) + 4);
        arg0K0 = v_1535X;
        arg0K1 = (SvalS);
        goto L39723;}
      else {
        merged_arg0K0 = 4;
        get_current_port_return_tag = 2;
        goto get_current_port;
       get_current_port_return_2:
        v_1536X = get_current_port0_return_value;
        arg0K0 = (SvalS);
        arg0K1 = v_1536X;
        goto L39723;}}
      break;
    case 190 : {
      v_1537X = *((unsigned char *) ((Scode_pointerS) + 1));
      if ((0 == v_1537X)) {
        arg0K0 = (SvalS);
        goto L39992;}
      else {
        merged_arg0K0 = 0;
        get_current_port_return_tag = 3;
        goto get_current_port;
       get_current_port_return_3:
        v_1538X = get_current_port0_return_value;
        arg0K0 = v_1538X;
        goto L39992;}}
      break;
    case 191 : {
      v_1539X = *((unsigned char *) ((Scode_pointerS) + 1));
      if ((0 == v_1539X)) {
        arg0K0 = (SvalS);
        goto L40583;}
      else {
        merged_arg0K0 = 0;
        get_current_port_return_tag = 4;
        goto get_current_port;
       get_current_port_return_4:
        v_1540X = get_current_port0_return_value;
        arg0K0 = v_1540X;
        goto L40583;}}
      break;
    case 192 : {
      v_1541X = *((unsigned char *) ((Scode_pointerS) + 1));
      if ((0 == v_1541X)) {
        v_1542X = *((long *) (SstackS));
        SstackS = ((SstackS) + 4);
        arg0K0 = v_1542X;
        arg0K1 = (SvalS);
        goto L41094;}
      else {
        merged_arg0K0 = 4;
        get_current_port_return_tag = 5;
        goto get_current_port;
       get_current_port_return_5:
        v_1543X = get_current_port0_return_value;
        arg0K0 = (SvalS);
        arg0K1 = v_1543X;
        goto L41094;}}
      break;
    case 193 : {s48_make_availableAgc(2052);
      if ((0 == (3 & (SvalS)))) {
        merged_arg0K0 = ((((SvalS))>>2));
        merged_arg0K1 = 0;
        get_error_string_return_tag = 2;
        goto get_error_string;
       get_error_string_return_2:
        val_1544X = get_error_string0_return_value;
        SvalS = val_1544X;
        Scode_pointerS = ((Scode_pointerS) + 1);
        arg3K0 = (Scode_pointerS);
        goto L32913;}
      else {push_exception_setupB(5, 1);
        x_1545X = SvalS;
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (x_1545X);
        arg0K0 = 1;
        goto L30610;}}
      break;
    case 194 : {
      x_1546X = SvalS;
      out_1547X = stderr;
      arg0K0 = x_1546X;
      goto L52000;}
      break;
  }}
 L29685: {
  i_1548X = arg0K0;
  m_1549X = arg0K1;
  if ((0 == (n_1000X & m_1549X))) {
    arg0K0 = (1 + i_1548X);
    arg0K1 = (((m_1549X)<<1));
    goto L29685;}
  else {
    Spending_interruptsS = ((Spending_interruptsS) & (~ m_1549X));
    handlers_1550X = SHARED_REF((Sinterrupt_handlersS));
    if ((i_1548X == 0)) {
      x_1551X = Sinterrupted_templateS;
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (x_1551X);
      Sinterrupted_templateS = 1;
      n_1552X = Senabled_interruptsS;
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) ((((n_1552X)<<2)));
      arg0K0 = 2;
      goto L29642;}
    else {
      if ((i_1548X == 3)) {
        goto L16002;}
      else {
        if ((i_1548X == 2)) {
          goto L16002;}
        else {
          if ((i_1548X == 4)) {
            channel_1553X = Spending_channels_headS;
            next_1554X = *((long *) ((((char *) (-3 + channel_1553X))) + 16));
            Spending_channels_headS = next_1554X;
            addr_1555X = (((char *) (-3 + channel_1553X))) + 16;S48_WRITE_BARRIER(channel_1553X, addr_1555X, 1);
            *((long *) addr_1555X) = (long) (1);
            if ((1 == next_1554X)) {
              Spending_channels_tailS = 1;
              arg0K0 = channel_1553X;
              goto L16019;}
            else {
              arg0K0 = channel_1553X;
              goto L16019;}}
          else {
            if ((i_1548X == 5)) {
              v_1556X = (Sos_signal_ring_startS) == (Sos_signal_ring_endS);
              if (v_1556X) {
                ps_error("This cannot happen: OS signal ring empty", 0);
                goto L16240;}
              else {
                goto L16240;}}
            else {
              if ((i_1548X == 6)) {
                uid_1557X = s48_dequeue_external_event(&still_readyP_1558X);
                SstackS = ((SstackS) + -4);
                *((long *) (SstackS)) = (long) ((((uid_1557X)<<2)));
                if (still_readyP_1558X) {
                  Spending_interruptsS = (64 | (Spending_interruptsS));
                  if ((0 == ((Spending_interruptsS) & (Senabled_interruptsS)))) {
                    s48_Sstack_limitS = (Sreal_stack_limitS);
                    if ((s48_Spending_eventsPS)) {
                      s48_Sstack_limitS = (((char *) -1));
                      goto L16091;}
                    else {
                      goto L16091;}}
                  else {
                    s48_Sstack_limitS = (((char *) -1));
                    goto L16091;}}
                else {
                  goto L16091;}}
              else {
                n_1559X = Senabled_interruptsS;
                SstackS = ((SstackS) + -4);
                *((long *) (SstackS)) = (long) ((((n_1559X)<<2)));
                arg0K0 = 1;
                goto L29642;}}}}}}}}
 L60023: {
  tag_1560X = arg0K0;
  if ((tag_1560X == 0)) {
    arg0K0 = (s48_Snative_protocolS);
    arg0K1 = 25;
    arg0K2 = 0;
    goto L30038;}
  else {
    if ((tag_1560X == 1)) {
      stack_arg_count_1561X = s48_Snative_protocolS;
      obj_1562X = SvalS;
      if ((3 == (3 & obj_1562X))) {
        if ((3 == (31 & ((((*((long *) ((((char *) (-3 + obj_1562X))) + -4))))>>2))))) {
          arg0K0 = stack_arg_count_1561X;
          arg0K1 = 25;
          arg0K2 = 0;
          arg0K3 = -1;
          goto L60809;}
        else {
          arg0K0 = 3;
          arg0K1 = stack_arg_count_1561X;
          arg0K2 = 25;
          arg0K3 = 0;
          goto L30300;}}
      else {
        arg0K0 = 3;
        arg0K1 = stack_arg_count_1561X;
        arg0K2 = 25;
        arg0K3 = 0;
        goto L30300;}}
    else {
      if ((tag_1560X == 2)) {
        template_1563X = *((long *) (SstackS));
        SstackS = ((SstackS) + 4);
        return_address_1564X = *((long *) (SstackS));
        SstackS = ((SstackS) + 4);
        pending_interruptP_return_tag = 4;
        goto pending_interruptP;
       pending_interruptP_return_4:
        v_1565X = pending_interruptP0_return_value;
        if (v_1565X) {
          x_1566X = SvalS;
          SstackS = ((SstackS) + -4);
          *((long *) (SstackS)) = (long) (x_1566X);
          SstackS = ((SstackS) + -4);
          *((long *) (SstackS)) = (long) (template_1563X);
          SstackS = ((SstackS) + -4);
          *((long *) (SstackS)) = (long) (return_address_1564X);
          x_1567X = *((long *) ((((char *) (-3 + (Scurrent_threadS)))) + 12));
          SstackS = ((SstackS) + -4);
          *((long *) (SstackS)) = (long) (x_1567X);
          x_1568X = Scurrent_threadS;
          addr_1569X = (((char *) (-3 + x_1568X))) + 12;S48_WRITE_BARRIER(x_1568X, addr_1569X, 1);
          *((long *) addr_1569X) = (long) (1);
          n_1570X = Senabled_interruptsS;
          SstackS = ((SstackS) + -4);
          *((long *) (SstackS)) = (long) ((((n_1570X)<<2)));
          code_1571X = Snative_poll_return_codeS;
          v_1572X = ((((ScontS) - (SstackS)))>>2);
          SstackS = ((SstackS) + -4);
          *((long *) (SstackS)) = (long) ((4 + (((v_1572X)<<2))));
          SstackS = ((SstackS) + -4);
          *((long *) (SstackS)) = (long) ((((long) ((((char *) (-3 + code_1571X))) + 13))));
          ScontS = (SstackS);
          goto L29632;}
        else {
          v_1573X = s48_jump_to_native_address(return_address_1564X, template_1563X);
          arg0K0 = v_1573X;
          goto L60023;}}
      else {
        if ((tag_1560X == 3)) {
          arg0K0 = (s48_Snative_protocolS);
          arg0K1 = 25;
          arg0K2 = 0;
          goto L30038;}
        else {
          if ((tag_1560X == 4)) {
            arg3K0 = (Scode_pointerS);
            goto L32913;}
          else {
            if ((tag_1560X == 5)) {
              maybe_cont_1574X = *((long *) (SstackS));
              SstackS = ((SstackS) + 4);
              stack_nargs_1575X = s48_Snative_protocolS;
              list_args_1576X = *((long *) (SstackS));
              SstackS = ((SstackS) + 4);
              merged_arg0K0 = list_args_1576X;
              okay_argument_list_return_tag = 1;
              goto okay_argument_list;
             okay_argument_list_return_1:
              okayP_1577X = okay_argument_list0_return_value;
              length_1578X = okay_argument_list1_return_value;
              if (okayP_1577X) {
                if ((0 == maybe_cont_1574X)) {
                  merged_arg0K0 = stack_nargs_1575X;
                  move_args_above_contB_return_tag = 5;
                  goto move_args_above_contB;
                 move_args_above_contB_return_5:
                  arg0K0 = stack_nargs_1575X;
                  arg0K1 = list_args_1576X;
                  arg0K2 = length_1578X;
                  goto L59760;}
                else {
                  ScontS = ((SstackS) + (((stack_nargs_1575X)<<2)));
                  *((long *) (ScontS)) = (long) ((((long) (((char *) maybe_cont_1574X)))));
                  arg0K0 = stack_nargs_1575X;
                  arg0K1 = list_args_1576X;
                  arg0K2 = length_1578X;
                  goto L59760;}}
              else {
                merged_arg0K0 = list_args_1576X;
                merged_arg0K1 = stack_nargs_1575X;
                pop_args_GlistSAgc_return_tag = 2;
                goto pop_args_GlistSAgc;
               pop_args_GlistSAgc_return_2:
                args_1579X = pop_args_GlistSAgc0_return_value;push_exception_setupB(5, 0);
                x_1580X = SvalS;
                SstackS = ((SstackS) + -4);
                *((long *) (SstackS)) = (long) (x_1580X);
                SstackS = ((SstackS) + -4);
                *((long *) (SstackS)) = (long) (args_1579X);
                arg0K0 = 2;
                goto L30610;}}
            else {
              if ((tag_1560X == 6)) {push_exception_setupB(15, 1);
                x_1581X = SvalS;
                SstackS = ((SstackS) + -4);
                *((long *) (SstackS)) = (long) (x_1581X);
                arg0K0 = 1;
                goto L30610;}
              else {
                ps_error("unexpected native return value", 1, tag_1560X);
                arg0K0 = v_1582X;
                goto L65498;}}}}}}}}
 L33365: {
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L12300: {
  new_env_1583X = arg0K0;
  i_1584X = arg0K1;
  offset_1585X = arg0K2;
  total_count_1586X = arg0K3;
  arg0K0 = (*((unsigned char *) ((Scode_pointerS) + (1 + offset_1585X))));
  arg0K1 = i_1584X;
  arg0K2 = (1 + offset_1585X);
  goto L12306;}
 L22869: {
  count_1587X = arg0K0;
  i_1588X = arg0K1;
  offset_1589X = arg0K2;
  if ((0 == count_1587X)) {
    arg0K0 = new_env_1030X;
    arg0K1 = i_1588X;
    arg0K2 = offset_1589X;
    arg0K3 = total_count_1026X;
    goto L12300;}
  else {
    merged_arg0K0 = (*((long *) ((((char *) (-3 + template_1031X))) + ((((*((unsigned char *) ((Scode_pointerS) + (1 + offset_1589X)))))<<2)))));
    merged_arg0K1 = new_env_1030X;
    merged_arg0K2 = 0;
    make_closure_return_tag = 0;
    goto make_closure;
   make_closure_return_0:
    value_1590X = make_closure0_return_value;
    addr_1591X = (((char *) (-3 + new_env_1030X))) + (((i_1588X)<<2));S48_WRITE_BARRIER(new_env_1030X, addr_1591X, value_1590X);
    *((long *) addr_1591X) = (long) (value_1590X);
    arg0K0 = (-1 + count_1587X);
    arg0K1 = (1 + i_1588X);
    arg0K2 = (1 + offset_1589X);
    goto L22869;}}
 L15050: {
  new_env_1592X = arg0K0;
  i_1593X = arg0K1;
  offset_1594X = arg0K2;
  total_count_1595X = arg0K3;
  arg0K0 = (((((*((unsigned char *) ((Scode_pointerS) + (1 + offset_1594X)))))<<8)) + (*((unsigned char *) ((Scode_pointerS) + (2 + offset_1594X)))));
  arg0K1 = i_1593X;
  arg0K2 = (2 + offset_1594X);
  goto L15056;}
 L22930: {
  count_1596X = arg0K0;
  i_1597X = arg0K1;
  offset_1598X = arg0K2;
  if ((0 == count_1596X)) {
    arg0K0 = new_env_1036X;
    arg0K1 = i_1597X;
    arg0K2 = offset_1598X;
    arg0K3 = total_count_1032X;
    goto L15050;}
  else {
    merged_arg0K0 = (*((long *) ((((char *) (-3 + template_1037X))) + ((((((((*((unsigned char *) ((Scode_pointerS) + (1 + offset_1598X)))))<<8)) + (*((unsigned char *) ((Scode_pointerS) + (2 + offset_1598X))))))<<2)))));
    merged_arg0K1 = new_env_1036X;
    merged_arg0K2 = 0;
    make_closure_return_tag = 1;
    goto make_closure;
   make_closure_return_1:
    value_1599X = make_closure0_return_value;
    addr_1600X = (((char *) (-3 + new_env_1036X))) + (((i_1597X)<<2));S48_WRITE_BARRIER(new_env_1036X, addr_1600X, value_1599X);
    *((long *) addr_1600X) = (long) (value_1599X);
    arg0K0 = (-1 + count_1596X);
    arg0K1 = (1 + i_1597X);
    arg0K2 = (2 + offset_1598X);
    goto L22930;}}
 L35554: {
  i_1601X = arg0K0;
  if ((0 == i_1601X)) {
    SvalS = closure_1048X;
    Scode_pointerS = ((Scode_pointerS) + 3);
    arg3K0 = (Scode_pointerS);
    goto L32913;}
  else {
    value_1602X = *((long *) (SstackS));
    SstackS = ((SstackS) + 4);
    *((long *) ((((char *) (-3 + closure_1048X))) + (((i_1601X)<<2)))) = (long) (value_1602X);
    arg0K0 = (-1 + i_1601X);
    goto L35554;}}
 L61734: {
  n_1603X = arg0K0;
  if ((0 == n_1603X)) {
    Scode_pointerS = ((Scode_pointerS) + 3);
    arg3K0 = (Scode_pointerS);
    goto L32913;}
  else {
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) (1);
    arg0K0 = (-1 + n_1603X);
    goto L61734;}}
 L34888: {
  move_1604X = arg0K0;
  if ((move_1604X == n_moves_1056X)) {
    value_1605X = *((long *) (SstackS));
    SstackS = ((SstackS) + 4);
    SvalS = value_1605X;
    Scode_pointerS = ((Scode_pointerS) + (2 + (((n_moves_1056X)<<1))));
    arg3K0 = (Scode_pointerS);
    goto L32913;}
  else {
    index_1606X = 1 + (((move_1604X)<<1));
    *((long *) ((SstackS) + ((((*((unsigned char *) ((Scode_pointerS) + (2 + index_1606X)))))<<2)))) = (long) ((*((long *) ((SstackS) + ((((*((unsigned char *) ((Scode_pointerS) + (1 + index_1606X)))))<<2))))));
    arg0K0 = (1 + move_1604X);
    goto L34888;}}
 L34805: {
  move_1607X = arg0K0;
  if ((move_1607X == n_moves_1058X)) {
    value_1608X = *((long *) (SstackS));
    SstackS = ((SstackS) + 4);
    SvalS = value_1608X;
    Scode_pointerS = ((Scode_pointerS) + (3 + (((n_moves_1058X)<<2))));
    arg3K0 = (Scode_pointerS);
    goto L32913;}
  else {
    index_1609X = 2 + (((move_1607X)<<2));
    value_1610X = *((long *) ((SstackS) + ((((((((*((unsigned char *) ((Scode_pointerS) + (1 + index_1609X)))))<<8)) + (*((unsigned char *) ((Scode_pointerS) + (2 + index_1609X))))))<<2))));
    index_1611X = 2 + index_1609X;
    *((long *) ((SstackS) + ((((((((*((unsigned char *) ((Scode_pointerS) + (1 + index_1611X)))))<<8)) + (*((unsigned char *) ((Scode_pointerS) + (2 + index_1611X))))))<<2)))) = (long) (value_1610X);
    arg0K0 = (1 + move_1607X);
    goto L34805;}}
 L61803: {
  value_1612X = arg0K0;
  SvalS = value_1612X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L60736: {
  stack_arg_count_1613X = arg0K0;
  obj_1614X = SvalS;
  if ((3 == (3 & obj_1614X))) {
    if ((3 == (31 & ((((*((long *) ((((char *) (-3 + obj_1614X))) + -4))))>>2))))) {
      template_1615X = *((long *) (((char *) (-3 + (SvalS)))));
      code_1616X = *((long *) (((char *) (-3 + template_1615X))));
      protocol_1617X = *((unsigned char *) ((((char *) (-3 + code_1616X))) + 1));
      if ((protocol_1617X == stack_arg_count_1613X)) {
        arg0K0 = code_1616X;
        arg0K1 = 2;
        arg0K2 = 3;
        arg0K3 = template_1615X;
        goto L29426;}
      else {
        if (((127 & protocol_1617X) == stack_arg_count_1613X)) {
          if (((SstackS) < (s48_Sstack_limitS))) {
            interruptP_1618X = (s48_Sstack_limitS) == (((char *) -1));
            s48_Sstack_limitS = (Sreal_stack_limitS);
            if (((SstackS) < (Sreal_stack_limitS))) {s48_copy_stack_into_heap();
              if (((SstackS) < (Sreal_stack_limitS))) {
                ps_error("VM's stack is too small (how can this happen?)", 0);
                if (interruptP_1618X) {
                  goto L60222;}
                else {
                  goto L60229;}}
              else {
                if (interruptP_1618X) {
                  goto L60222;}
                else {
                  goto L60229;}}}
            else {
              if (interruptP_1618X) {
                goto L60222;}
              else {
                goto L60229;}}}
          else {
            goto L60229;}}
        else {
          arg0K0 = stack_arg_count_1613X;
          arg0K1 = 25;
          arg0K2 = 0;
          arg0K3 = -1;
          goto L60809;}}}
    else {
      arg0K0 = 3;
      arg0K1 = stack_arg_count_1613X;
      arg0K2 = 25;
      arg0K3 = 0;
      goto L30300;}}
  else {
    arg0K0 = 3;
    arg0K1 = stack_arg_count_1613X;
    arg0K2 = 25;
    arg0K3 = 0;
    goto L30300;}}
 L30413: {
  obj_1619X = SvalS;
  if ((3 == (3 & obj_1619X))) {
    if ((3 == (31 & ((((*((long *) ((((char *) (-3 + obj_1619X))) + -4))))>>2))))) {
      arg0K0 = stack_arg_count_1062X;
      arg0K1 = 25;
      arg0K2 = 0;
      arg0K3 = -1;
      goto L60809;}
    else {
      arg0K0 = 3;
      arg0K1 = stack_arg_count_1062X;
      arg0K2 = 25;
      arg0K3 = 0;
      goto L30300;}}
  else {
    arg0K0 = 3;
    arg0K1 = stack_arg_count_1062X;
    arg0K2 = 25;
    arg0K3 = 0;
    goto L30300;}}
 L61829: {
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L59760: {
  stack_arg_count_1620X = arg0K0;
  list_args_1621X = arg0K1;
  list_arg_count_1622X = arg0K2;
  if ((0 == list_arg_count_1622X)) {
    obj_1623X = SvalS;
    if ((3 == (3 & obj_1623X))) {
      if ((3 == (31 & ((((*((long *) ((((char *) (-3 + obj_1623X))) + -4))))>>2))))) {
        arg0K0 = stack_arg_count_1620X;
        arg0K1 = 25;
        arg0K2 = 0;
        arg0K3 = -1;
        goto L60809;}
      else {
        arg0K0 = 3;
        arg0K1 = stack_arg_count_1620X;
        arg0K2 = 25;
        arg0K3 = 0;
        goto L30300;}}
    else {
      arg0K0 = 3;
      arg0K1 = stack_arg_count_1620X;
      arg0K2 = 25;
      arg0K3 = 0;
      goto L30300;}}
  else {
    obj_1624X = SvalS;
    if ((3 == (3 & obj_1624X))) {
      if ((3 == (31 & ((((*((long *) ((((char *) (-3 + obj_1624X))) + -4))))>>2))))) {
        arg0K0 = stack_arg_count_1620X;
        arg0K1 = list_args_1621X;
        arg0K2 = list_arg_count_1622X;
        arg0K3 = -1;
        goto L60809;}
      else {
        arg0K0 = 3;
        arg0K1 = stack_arg_count_1620X;
        arg0K2 = list_args_1621X;
        arg0K3 = list_arg_count_1622X;
        goto L30300;}}
    else {
      arg0K0 = 3;
      arg0K1 = stack_arg_count_1620X;
      arg0K2 = list_args_1621X;
      arg0K3 = list_arg_count_1622X;
      goto L30300;}}}
 L21835: {
  list_args_1625X = arg0K0;
  stack_nargs_1626X = arg0K1;
  merged_arg0K0 = list_args_1625X;
  okay_argument_list_return_tag = 2;
  goto okay_argument_list;
 okay_argument_list_return_2:
  okayP_1627X = okay_argument_list0_return_value;
  list_arg_count_1628X = okay_argument_list1_return_value;
  if (okayP_1627X) {
    arg0K0 = stack_nargs_1626X;
    arg0K1 = list_args_1625X;
    arg0K2 = list_arg_count_1628X;
    goto L59760;}
  else {
    merged_arg0K0 = list_args_1625X;
    merged_arg0K1 = stack_nargs_1626X;
    pop_args_GlistSAgc_return_tag = 3;
    goto pop_args_GlistSAgc;
   pop_args_GlistSAgc_return_3:
    args_1629X = pop_args_GlistSAgc0_return_value;push_exception_setupB(5, 0);
    x_1630X = SvalS;
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) (x_1630X);
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) (args_1629X);
    arg0K0 = 2;
    goto L30610;}}
 L21880: {
  list_1631X = arg0K0;
  follower_1632X = arg0K1;
  if ((25 == list_1631X)) {
    list_args_1633X = *((long *) (((char *) (-3 + (*((long *) ((((char *) (-3 + follower_1632X))) + 4)))))));
    addr_1634X = (((char *) (-3 + follower_1632X))) + 4;S48_WRITE_BARRIER(follower_1632X, addr_1634X, list_args_1633X);
    *((long *) addr_1634X) = (long) (list_args_1633X);
    arg0K0 = rest_list_1077X;
    arg0K1 = (-1 + stack_nargs_1076X);
    goto L21835;}
  else {
    arg0K0 = (*((long *) ((((char *) (-3 + list_1631X))) + 4)));
    arg0K1 = (*((long *) ((((char *) (-3 + follower_1632X))) + 4)));
    goto L21880;}}
 L30371: {
  obj_1635X = SvalS;
  if ((3 == (3 & obj_1635X))) {
    if ((3 == (31 & ((((*((long *) ((((char *) (-3 + obj_1635X))) + -4))))>>2))))) {
      arg0K0 = 0;
      arg0K1 = 25;
      arg0K2 = 0;
      arg0K3 = -1;
      goto L60809;}
    else {
      arg0K0 = 3;
      arg0K1 = 0;
      arg0K2 = 25;
      arg0K3 = 0;
      goto L30300;}}
  else {
    arg0K0 = 3;
    arg0K1 = 0;
    arg0K2 = 25;
    arg0K3 = 0;
    goto L30300;}}
 L30380: {
  SstackS = (Sbottom_of_stackS);
  Sheap_continuationS = cont_1079X;
  ScontS = (Sbottom_of_stackS);
  goto L30371;}
 L60347: {
  code_pointer_1636X = ((char *) (*((long *) (ScontS))));
  protocol_1637X = *((unsigned char *) (code_pointer_1636X + 1));
  if ((1 == protocol_1637X)) {
    goto L60364;}
  else {
    if ((66 == protocol_1637X)) {
      goto L60364;}
    else {
      if ((129 == protocol_1637X)) {
        arg0K0 = 2;
        goto L60149;}
      else {
        if ((194 == protocol_1637X)) {
          arg0K0 = 2;
          goto L60149;}
        else {
          if ((71 == protocol_1637X)) {
            cont_1638X = Sheap_continuationS;
            if ((3 == (3 & cont_1638X))) {
              if ((10 == (31 & ((((*((long *) ((((char *) (-3 + cont_1638X))) + -4))))>>2))))) {
                merged_arg0K0 = cont_1638X;
                merged_arg0K1 = 0;
                copy_continuation_from_heapB_return_tag = 1;
                goto copy_continuation_from_heapB;
               copy_continuation_from_heapB_return_1:
                goto L60347;}
              else {
                arg0K0 = cont_1638X;
                goto L30956;}}
            else {
              arg0K0 = cont_1638X;
              goto L30956;}}
          else {
            if ((70 == protocol_1637X)) {
              offset_1639X = ((((*((unsigned char *) (code_pointer_1636X + 2))))<<8)) + (*((unsigned char *) (code_pointer_1636X + 3)));
              proc_1640X = *((long *) ((ScontS) + 4));
              if ((0 == offset_1639X)) {
                cont_1641X = ScontS;
                pointer_1642X = (((char *) (*((long *) cont_1641X)))) + -2;
                size_1643X = ((((*((unsigned char *) pointer_1642X)))<<8)) + (*((unsigned char *) (pointer_1642X + 1)));
                if ((65535 == size_1643X)) {
                  arg0K0 = ((((*((long *) (cont_1641X + 4))))>>2));
                  goto L60508;}
                else {
                  arg0K0 = size_1643X;
                  goto L60508;}}
              else {
                ScontS = ((ScontS) + 4);
                *((long *) (ScontS)) = (long) ((((long) (code_pointer_1636X + offset_1639X))));
                SstackS = (ScontS);
                goto L60413;}}
            else {
              if ((65 == protocol_1637X)) {
                wants_stack_args_1644X = ((((*((unsigned char *) (code_pointer_1636X + 2))))<<8)) + (*((unsigned char *) (code_pointer_1636X + 3)));
                if ((0 == wants_stack_args_1644X)) {
                  pop_continuationB_return_tag = 0;
                  goto pop_continuationB;
                 pop_continuationB_return_0:s48_make_availableAgc(12);
                  a_1645X = SvalS;
                  addr_1646X = s48_allocate_small(12);
                  *((long *) addr_1646X) = (long) (2050);
                  x_1647X = 3 + (((long) (addr_1646X + 4)));
                  *((long *) (((char *) (-3 + x_1647X)))) = (long) (a_1645X);
                  *((long *) ((((char *) (-3 + x_1647X))) + 4)) = (long) (25);
                  SstackS = ((SstackS) + -4);
                  *((long *) (SstackS)) = (long) (x_1647X);
                  Scode_pointerS = ((Scode_pointerS) + 4);
                  arg3K0 = (Scode_pointerS);
                  goto L32913;}
                else {
                  if ((1 == wants_stack_args_1644X)) {
                    pop_continuationB_return_tag = 1;
                    goto pop_continuationB;
                   pop_continuationB_return_1:
                    x_1648X = SvalS;
                    SstackS = ((SstackS) + -4);
                    *((long *) (SstackS)) = (long) (x_1648X);
                    SstackS = ((SstackS) + -4);
                    *((long *) (SstackS)) = (long) (25);
                    Scode_pointerS = ((Scode_pointerS) + 4);
                    arg3K0 = (Scode_pointerS);
                    goto L32913;}
                  else {
                    x_1649X = SvalS;
                    SstackS = ((SstackS) + -4);
                    *((long *) (SstackS)) = (long) (x_1649X);
                    merged_arg0K0 = 25;
                    merged_arg0K1 = 1;
                    pop_args_GlistSAgc_return_tag = 4;
                    goto pop_args_GlistSAgc;
                   pop_args_GlistSAgc_return_4:
                    args_1650X = pop_args_GlistSAgc0_return_value;push_exception_setupB(4, 0);
                    SstackS = ((SstackS) + -4);
                    *((long *) (SstackS)) = (long) (1);
                    SstackS = ((SstackS) + -4);
                    *((long *) (SstackS)) = (long) (args_1650X);
                    arg0K0 = 2;
                    goto L30610;}}}
              else {
                x_1651X = SvalS;
                SstackS = ((SstackS) + -4);
                *((long *) (SstackS)) = (long) (x_1651X);
                merged_arg0K0 = 25;
                merged_arg0K1 = 1;
                pop_args_GlistSAgc_return_tag = 5;
                goto pop_args_GlistSAgc;
               pop_args_GlistSAgc_return_5:
                args_1652X = pop_args_GlistSAgc0_return_value;push_exception_setupB(4, 0);
                SstackS = ((SstackS) + -4);
                *((long *) (SstackS)) = (long) (1);
                SstackS = ((SstackS) + -4);
                *((long *) (SstackS)) = (long) (args_1652X);
                arg0K0 = 2;
                goto L30610;}}}}}}}}
 L30038: {
  stack_nargs_1653X = arg0K0;
  list_args_1654X = arg0K1;
  list_arg_count_1655X = arg0K2;
  code_pointer_1656X = ((char *) (*((long *) (ScontS))));
  protocol_1657X = *((unsigned char *) (code_pointer_1656X + 1));
  if ((1 == protocol_1657X)) {
    if ((1 == (stack_nargs_1653X + list_arg_count_1655X))) {
      if ((1 == stack_nargs_1653X)) {
        v_1658X = *((long *) (SstackS));
        SstackS = ((SstackS) + 4);
        arg0K0 = v_1658X;
        goto L30127;}
      else {
        arg0K0 = (*((long *) (((char *) (-3 + list_args_1654X)))));
        goto L30127;}}
    else {
      arg0K0 = stack_nargs_1653X;
      arg0K1 = list_args_1654X;
      goto L31039;}}
  else {
    if ((66 == protocol_1657X)) {
      pop_continuationB_return_tag = 2;
      goto pop_continuationB;
     pop_continuationB_return_2:
      arg0K0 = 1;
      goto L33337;}
    else {
      if ((127 < protocol_1657X)) {
        if ((129 == protocol_1657X)) {
          if ((1 == (stack_nargs_1653X + list_arg_count_1655X))) {
            if ((1 == stack_nargs_1653X)) {
              v_1659X = *((long *) (SstackS));
              SstackS = ((SstackS) + 4);
              arg0K0 = v_1659X;
              goto L60693;}
            else {
              arg0K0 = (*((long *) (((char *) (-3 + list_args_1654X)))));
              goto L60693;}}
          else {
            merged_arg0K0 = list_args_1654X;
            merged_arg0K1 = stack_nargs_1653X;
            pop_args_GlistSAgc_return_tag = 6;
            goto pop_args_GlistSAgc;
           pop_args_GlistSAgc_return_6:
            args_1660X = pop_args_GlistSAgc0_return_value;push_exception_setupB(4, 0);
            SstackS = ((SstackS) + -4);
            *((long *) (SstackS)) = (long) (1);
            SstackS = ((SstackS) + -4);
            *((long *) (SstackS)) = (long) (args_1660X);
            arg0K0 = 2;
            goto L30610;}}
        else {
          if ((194 == protocol_1657X)) {
            arg0K0 = 2;
            goto L60149;}
          else {
            ps_error("unknown native return protocol", 1, protocol_1657X);
            merged_arg0K0 = list_args_1654X;
            merged_arg0K1 = stack_nargs_1653X;
            pop_args_GlistSAgc_return_tag = 7;
            goto pop_args_GlistSAgc;
           pop_args_GlistSAgc_return_7:
            args_1661X = pop_args_GlistSAgc0_return_value;push_exception_setupB(4, 0);
            SstackS = ((SstackS) + -4);
            *((long *) (SstackS)) = (long) (1);
            SstackS = ((SstackS) + -4);
            *((long *) (SstackS)) = (long) (args_1661X);
            arg0K0 = 2;
            goto L30610;}}}
      else {
        if ((71 == protocol_1657X)) {
          cont_1662X = Sheap_continuationS;
          if ((3 == (3 & cont_1662X))) {
            if ((10 == (31 & ((((*((long *) ((((char *) (-3 + cont_1662X))) + -4))))>>2))))) {
              merged_arg0K0 = cont_1662X;
              merged_arg0K1 = stack_nargs_1653X;
              copy_continuation_from_heapB_return_tag = 2;
              goto copy_continuation_from_heapB;
             copy_continuation_from_heapB_return_2:
              arg0K0 = stack_nargs_1653X;
              arg0K1 = list_args_1654X;
              arg0K2 = list_arg_count_1655X;
              goto L30038;}
            else {
              goto L30073;}}
          else {
            goto L30073;}}
        else {
          if ((70 == protocol_1657X)) {
            SvalS = (*((long *) ((ScontS) + 4)));
            offset_1663X = ((((*((unsigned char *) (code_pointer_1656X + 2))))<<8)) + (*((unsigned char *) (code_pointer_1656X + 3)));
            if ((0 == offset_1663X)) {
              cont_1664X = ScontS;
              pointer_1665X = (((char *) (*((long *) cont_1664X)))) + -2;
              size_1666X = ((((*((unsigned char *) pointer_1665X)))<<8)) + (*((unsigned char *) (pointer_1665X + 1)));
              if ((65535 == size_1666X)) {
                arg0K0 = ((((*((long *) (cont_1664X + 4))))>>2));
                goto L30190;}
              else {
                arg0K0 = size_1666X;
                goto L30190;}}
            else {
              ScontS = ((ScontS) + 4);
              *((long *) (ScontS)) = (long) ((((long) (code_pointer_1656X + offset_1663X))));
              merged_arg0K0 = stack_nargs_1653X;
              move_args_above_contB_return_tag = 6;
              goto move_args_above_contB;
             move_args_above_contB_return_6:
              arg0K0 = stack_nargs_1653X;
              arg0K1 = list_args_1654X;
              arg0K2 = list_arg_count_1655X;
              goto L59760;}}
          else {
            if ((63 < protocol_1657X)) {
              if ((65 == protocol_1657X)) {
                count_1667X = ((((*((unsigned char *) (code_pointer_1656X + 2))))<<8)) + (*((unsigned char *) (code_pointer_1656X + 3)));
                if (((stack_nargs_1653X + list_arg_count_1655X) < count_1667X)) {
                  merged_arg0K0 = list_args_1654X;
                  merged_arg0K1 = stack_nargs_1653X;
                  pop_args_GlistSAgc_return_tag = 8;
                  goto pop_args_GlistSAgc;
                 pop_args_GlistSAgc_return_8:
                  args_1668X = pop_args_GlistSAgc0_return_value;push_exception_setupB(4, 0);
                  SstackS = ((SstackS) + -4);
                  *((long *) (SstackS)) = (long) (1);
                  SstackS = ((SstackS) + -4);
                  *((long *) (SstackS)) = (long) (args_1668X);
                  arg0K0 = 2;
                  goto L30610;}
                else {
                  arg_top_1669X = SstackS;
                  pop_continuationB_return_tag = 3;
                  goto pop_continuationB;
                 pop_continuationB_return_3:
                  arg3K0 = ((SstackS) + -4);
                  arg3K1 = (arg_top_1669X + (-4 + (((stack_nargs_1653X)<<2))));
                  goto L34387;}}
              else {
                if ((64 == protocol_1657X)) {
                  arg0K0 = (((((*((unsigned char *) (code_pointer_1656X + 2))))<<8)) + (*((unsigned char *) (code_pointer_1656X + 3))));
                  arg0K1 = 3;
                  arg0K2 = stack_nargs_1653X;
                  arg0K3 = list_args_1654X;
                  arg0K4 = list_arg_count_1655X;
                  goto L34239;}
                else {
                  ps_error("unknown protocol", 1, protocol_1657X);
                  arg0K0 = stack_nargs_1653X;
                  arg0K1 = list_args_1654X;
                  goto L31039;}}}
            else {
              arg0K0 = protocol_1657X;
              arg0K1 = 1;
              arg0K2 = stack_nargs_1653X;
              arg0K3 = list_args_1654X;
              arg0K4 = list_arg_count_1655X;
              goto L34239;}}}}}}}
 L34539: {
  if ((nargs_1086X == (*((unsigned char *) ((((char *) (-3 + code_1085X))) + 1))))) {
    arg0K0 = code_1085X;
    arg0K1 = 2;
    arg0K2 = 3;
    arg0K3 = template_1084X;
    goto L29426;}
  else {
    v_1670X = *((unsigned char *) ((((char *) (-3 + code_1085X))) + 1));
    if ((67 == v_1670X)) {
      if ((nargs_1086X == (*((unsigned char *) ((((char *) (-3 + code_1085X))) + (-3 + ((long)(((unsigned long)(*((long *) ((((char *) (-3 + code_1085X))) + -4))))>>8)))))))) {
        index_1671X = -2 + ((long)(((unsigned long)(*((long *) ((((char *) (-3 + code_1085X))) + -4))))>>8));
        arg0K0 = code_1085X;
        arg0K1 = 2;
        arg0K2 = template_1084X;
        arg0K3 = (((((*((unsigned char *) ((((char *) (-3 + code_1085X))) + index_1671X))))<<8)) + (*((unsigned char *) ((((char *) (-3 + code_1085X))) + (1 + index_1671X)))));
        goto L33347;}
      else {
        goto L34561;}}
    else {
      goto L34561;}}}
 L33222: {
  arg0K0 = (2 + (((max_1090X)<<1)));
  goto L33224;}
 L33224: {
  offset_1672X = arg0K0;
  Scode_pointerS = ((Scode_pointerS) + offset_1672X);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L33811: {
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L33120: {
  delta_1673X = arg0K0;
  Scode_pointerS = ((Scode_pointerS) + delta_1673X);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L33702: {
  delta_1674X = arg0K0;
  Scode_pointerS = ((Scode_pointerS) + delta_1674X);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L61874: {
  val_1675X = arg0K0;
  SvalS = val_1675X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L61886: {
  val_1676X = arg0K0;
  SvalS = val_1676X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L19484: {
  if ((3 == (3 & x_1105X))) {
    if ((8 == (31 & ((((*((long *) ((((char *) (-3 + x_1105X))) + -4))))>>2))))) {
      arg0K0 = 5;
      goto L61886;}
    else {
      goto L19490;}}
  else {
    goto L19490;}}
 L51217: {
  SvalS = 5;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L51218: {
  if ((3 == (3 & n_1106X))) {
    if ((11 == (31 & ((((*((long *) ((((char *) (-3 + n_1106X))) + -4))))>>2))))) {
      goto L51231;}
    else {
      goto L51226;}}
  else {
    goto L51226;}}
 L51351: {
  n_1677X = arg0K0;
  if ((0 == (3 & n_1677X))) {
    goto L51384;}
  else {
    if ((3 == (3 & n_1677X))) {
      if ((19 == (31 & ((((*((long *) ((((char *) (-3 + n_1677X))) + -4))))>>2))))) {
        goto L51384;}
      else {
        goto L51367;}}
    else {
      goto L51367;}}}
 L43771: {
  SvalS = 5;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L43772: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (n_1107X);
  arg0K0 = 1;
  goto L30610;}
 L43897: {
  v_1678X = (char *) s48_long_to_bignum(x_1112X);
  v_1679X = enter_bignum(v_1678X);
  arg0K0 = v_1679X;
  goto L43843;}
 L43843: {
  val_1680X = arg0K0;
  SvalS = val_1680X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L43849: {
  if ((0 == (3 & y_1111X))) {
    goto L43855;}
  else {
    if ((3 == (3 & y_1111X))) {
      if ((19 == (31 & ((((*((long *) ((((char *) (-3 + y_1111X))) + -4))))>>2))))) {
        goto L43855;}
      else {
        goto L43858;}}
    else {
      goto L43858;}}}
 L43858: {
  if ((3 == (3 & arg2_1110X))) {
    if ((18 == (31 & ((((*((long *) ((((char *) (-3 + arg2_1110X))) + -4))))>>2))))) {
      if ((3 == (3 & y_1111X))) {
        if ((18 == (31 & ((((*((long *) ((((char *) (-3 + y_1111X))) + -4))))>>2))))) {
          Stemp0S = arg2_1110X;
          Stemp1S = y_1111X;s48_make_availableAgc(12);
          value_1681X = Stemp0S;
          Stemp0S = 1;
          x_1682X = *((double *) (((char *) (-3 + value_1681X))));
          value_1683X = Stemp1S;
          Stemp1S = 1;
          y_1684X = *((double *) (((char *) (-3 + value_1683X))));
          addr_1685X = s48_allocate_small(12);
          *((long *) addr_1685X) = (long) (2122);
          Kdouble_1686X = 3 + (((long) (addr_1685X + 4)));
          *((double *) (((char *) (-3 + Kdouble_1686X)))) = (double) ((x_1682X + y_1684X));
          SvalS = Kdouble_1686X;
          Scode_pointerS = ((Scode_pointerS) + 1);
          arg3K0 = (Scode_pointerS);
          goto L32913;}
        else {
          goto L43872;}}
      else {
        goto L43872;}}
    else {
      goto L43872;}}
  else {
    goto L43872;}}
 L12549: {
  a_1687X = arg0K0;
  if ((b_1116X < 0)) {
    arg0K0 = (0 - b_1116X);
    goto L12553;}
  else {
    arg0K0 = b_1116X;
    goto L12553;}}
 L53124: {
  if ((0 == (3 & y_1114X))) {
    goto L53130;}
  else {
    if ((3 == (3 & y_1114X))) {
      if ((19 == (31 & ((((*((long *) ((((char *) (-3 + y_1114X))) + -4))))>>2))))) {
        goto L53130;}
      else {
        goto L53133;}}
    else {
      goto L53133;}}}
 L53133: {
  if ((3 == (3 & arg2_1113X))) {
    if ((18 == (31 & ((((*((long *) ((((char *) (-3 + arg2_1113X))) + -4))))>>2))))) {
      if ((3 == (3 & y_1114X))) {
        if ((18 == (31 & ((((*((long *) ((((char *) (-3 + y_1114X))) + -4))))>>2))))) {
          Stemp0S = arg2_1113X;
          Stemp1S = y_1114X;s48_make_availableAgc(12);
          value_1688X = Stemp0S;
          Stemp0S = 1;
          x_1689X = *((double *) (((char *) (-3 + value_1688X))));
          value_1690X = Stemp1S;
          Stemp1S = 1;
          y_1691X = *((double *) (((char *) (-3 + value_1690X))));
          addr_1692X = s48_allocate_small(12);
          *((long *) addr_1692X) = (long) (2122);
          Kdouble_1693X = 3 + (((long) (addr_1692X + 4)));
          *((double *) (((char *) (-3 + Kdouble_1693X)))) = (double) ((x_1689X * y_1691X));
          SvalS = Kdouble_1693X;
          Scode_pointerS = ((Scode_pointerS) + 1);
          arg3K0 = (Scode_pointerS);
          goto L32913;}
        else {
          goto L53147;}}
      else {
        goto L53147;}}
    else {
      goto L53147;}}
  else {
    goto L53147;}}
 L44186: {
  v_1694X = (char *) s48_long_to_bignum(x_1119X);
  v_1695X = enter_bignum(v_1694X);
  arg0K0 = v_1695X;
  goto L44132;}
 L44132: {
  val_1696X = arg0K0;
  SvalS = val_1696X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L44138: {
  if ((0 == (3 & y_1118X))) {
    goto L44144;}
  else {
    if ((3 == (3 & y_1118X))) {
      if ((19 == (31 & ((((*((long *) ((((char *) (-3 + y_1118X))) + -4))))>>2))))) {
        goto L44144;}
      else {
        goto L44147;}}
    else {
      goto L44147;}}}
 L44147: {
  if ((3 == (3 & arg2_1117X))) {
    if ((18 == (31 & ((((*((long *) ((((char *) (-3 + arg2_1117X))) + -4))))>>2))))) {
      if ((3 == (3 & y_1118X))) {
        if ((18 == (31 & ((((*((long *) ((((char *) (-3 + y_1118X))) + -4))))>>2))))) {
          Stemp0S = arg2_1117X;
          Stemp1S = y_1118X;s48_make_availableAgc(12);
          value_1697X = Stemp0S;
          Stemp0S = 1;
          x_1698X = *((double *) (((char *) (-3 + value_1697X))));
          value_1699X = Stemp1S;
          Stemp1S = 1;
          y_1700X = *((double *) (((char *) (-3 + value_1699X))));
          addr_1701X = s48_allocate_small(12);
          *((long *) addr_1701X) = (long) (2122);
          Kdouble_1702X = 3 + (((long) (addr_1701X + 4)));
          *((double *) (((char *) (-3 + Kdouble_1702X)))) = (double) ((x_1698X - y_1700X));
          SvalS = Kdouble_1702X;
          Scode_pointerS = ((Scode_pointerS) + 1);
          arg3K0 = (Scode_pointerS);
          goto L32913;}
        else {
          goto L44161;}}
      else {
        goto L44161;}}
    else {
      goto L44161;}}
  else {
    goto L44161;}}
 L12807: {
  a_1703X = arg0K0;
  if ((b_1123X < 0)) {
    arg0K0 = (0 - b_1123X);
    goto L12811;}
  else {
    arg0K0 = b_1123X;
    goto L12811;}}
 L53377: {
  if ((0 == (3 & y_1121X))) {
    goto L53383;}
  else {
    if ((3 == (3 & y_1121X))) {
      if ((19 == (31 & ((((*((long *) ((((char *) (-3 + y_1121X))) + -4))))>>2))))) {
        goto L53383;}
      else {
        goto L53414;}}
    else {
      goto L53414;}}}
 L53414: {
  if ((3 == (3 & arg2_1120X))) {
    if ((18 == (31 & ((((*((long *) ((((char *) (-3 + arg2_1120X))) + -4))))>>2))))) {
      if ((3 == (3 & y_1121X))) {
        if ((18 == (31 & ((((*((long *) ((((char *) (-3 + y_1121X))) + -4))))>>2))))) {
          Stemp0S = arg2_1120X;
          Stemp1S = y_1121X;s48_make_availableAgc(12);
          value_1704X = Stemp0S;
          Stemp0S = 1;
          x_1705X = *((double *) (((char *) (-3 + value_1704X))));
          value_1706X = Stemp1S;
          Stemp1S = 1;
          value_1707X = x_1705X / (*((double *) (((char *) (-3 + value_1706X)))));
          addr_1708X = s48_allocate_small(12);
          *((long *) addr_1708X) = (long) (2122);
          Kdouble_1709X = 3 + (((long) (addr_1708X + 4)));
          *((double *) (((char *) (-3 + Kdouble_1709X)))) = (double) (value_1707X);
          SvalS = Kdouble_1709X;
          Scode_pointerS = ((Scode_pointerS) + 1);
          arg3K0 = (Scode_pointerS);
          goto L32913;}
        else {
          goto L53428;}}
      else {
        goto L53428;}}
    else {
      goto L53428;}}
  else {
    goto L53428;}}
 L44417: {
  val_1710X = arg0K0;
  SvalS = val_1710X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L44423: {
  if ((0 == (3 & y_1125X))) {
    goto L44429;}
  else {
    if ((3 == (3 & y_1125X))) {
      if ((19 == (31 & ((((*((long *) ((((char *) (-3 + y_1125X))) + -4))))>>2))))) {
        goto L44429;}
      else {
        goto L44434;}}
    else {
      goto L44434;}}}
 L44434: {
  if ((3 == (3 & arg2_1124X))) {
    if ((18 == (31 & ((((*((long *) ((((char *) (-3 + arg2_1124X))) + -4))))>>2))))) {
      if ((3 == (3 & y_1125X))) {
        if ((18 == (31 & ((((*((long *) ((((char *) (-3 + y_1125X))) + -4))))>>2))))) {
          b_1711X = (*((double *) (((char *) (-3 + arg2_1124X))))) == (*((double *) (((char *) (-3 + y_1125X)))));
          if (b_1711X) {
            arg0K0 = 5;
            goto L44449;}
          else {
            arg0K0 = 1;
            goto L44449;}}
        else {
          goto L44450;}}
      else {
        goto L44450;}}
    else {
      goto L44450;}}
  else {
    goto L44450;}}
 L44677: {
  val_1712X = arg0K0;
  SvalS = val_1712X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L44683: {
  if ((0 == (3 & y_1127X))) {
    goto L44689;}
  else {
    if ((3 == (3 & y_1127X))) {
      if ((19 == (31 & ((((*((long *) ((((char *) (-3 + y_1127X))) + -4))))>>2))))) {
        goto L44689;}
      else {
        goto L44694;}}
    else {
      goto L44694;}}}
 L44694: {
  if ((3 == (3 & arg2_1126X))) {
    if ((18 == (31 & ((((*((long *) ((((char *) (-3 + arg2_1126X))) + -4))))>>2))))) {
      if ((3 == (3 & y_1127X))) {
        if ((18 == (31 & ((((*((long *) ((((char *) (-3 + y_1127X))) + -4))))>>2))))) {
          b_1713X = (*((double *) (((char *) (-3 + arg2_1126X))))) < (*((double *) (((char *) (-3 + y_1127X)))));
          if (b_1713X) {
            arg0K0 = 5;
            goto L44709;}
          else {
            arg0K0 = 1;
            goto L44709;}}
        else {
          goto L44710;}}
      else {
        goto L44710;}}
    else {
      goto L44710;}}
  else {
    goto L44710;}}
 L45000: {
  val_1714X = arg0K0;
  SvalS = val_1714X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L45006: {
  if ((0 == (3 & y_1129X))) {
    goto L45012;}
  else {
    if ((3 == (3 & y_1129X))) {
      if ((19 == (31 & ((((*((long *) ((((char *) (-3 + y_1129X))) + -4))))>>2))))) {
        goto L45012;}
      else {
        goto L45017;}}
    else {
      goto L45017;}}}
 L45017: {
  if ((3 == (3 & arg2_1128X))) {
    if ((18 == (31 & ((((*((long *) ((((char *) (-3 + arg2_1128X))) + -4))))>>2))))) {
      if ((3 == (3 & y_1129X))) {
        if ((18 == (31 & ((((*((long *) ((((char *) (-3 + y_1129X))) + -4))))>>2))))) {
          b_1715X = (*((double *) (((char *) (-3 + y_1129X))))) < (*((double *) (((char *) (-3 + arg2_1128X)))));
          if (b_1715X) {
            arg0K0 = 5;
            goto L45032;}
          else {
            arg0K0 = 1;
            goto L45032;}}
        else {
          goto L45033;}}
      else {
        goto L45033;}}
    else {
      goto L45033;}}
  else {
    goto L45033;}}
 L45323: {
  val_1716X = arg0K0;
  SvalS = val_1716X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L45329: {
  if ((0 == (3 & y_1131X))) {
    goto L45335;}
  else {
    if ((3 == (3 & y_1131X))) {
      if ((19 == (31 & ((((*((long *) ((((char *) (-3 + y_1131X))) + -4))))>>2))))) {
        goto L45335;}
      else {
        goto L45340;}}
    else {
      goto L45340;}}}
 L45340: {
  if ((3 == (3 & arg2_1130X))) {
    if ((18 == (31 & ((((*((long *) ((((char *) (-3 + arg2_1130X))) + -4))))>>2))))) {
      if ((3 == (3 & y_1131X))) {
        if ((18 == (31 & ((((*((long *) ((((char *) (-3 + y_1131X))) + -4))))>>2))))) {
          if (((*((double *) (((char *) (-3 + y_1131X))))) < (*((double *) (((char *) (-3 + arg2_1130X))))))) {
            arg0K0 = 1;
            goto L45355;}
          else {
            arg0K0 = 5;
            goto L45355;}}
        else {
          goto L45356;}}
      else {
        goto L45356;}}
    else {
      goto L45356;}}
  else {
    goto L45356;}}
 L45617: {
  val_1717X = arg0K0;
  SvalS = val_1717X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L45623: {
  if ((0 == (3 & y_1133X))) {
    goto L45629;}
  else {
    if ((3 == (3 & y_1133X))) {
      if ((19 == (31 & ((((*((long *) ((((char *) (-3 + y_1133X))) + -4))))>>2))))) {
        goto L45629;}
      else {
        goto L45634;}}
    else {
      goto L45634;}}}
 L45634: {
  if ((3 == (3 & arg2_1132X))) {
    if ((18 == (31 & ((((*((long *) ((((char *) (-3 + arg2_1132X))) + -4))))>>2))))) {
      if ((3 == (3 & y_1133X))) {
        if ((18 == (31 & ((((*((long *) ((((char *) (-3 + y_1133X))) + -4))))>>2))))) {
          if (((*((double *) (((char *) (-3 + arg2_1132X))))) < (*((double *) (((char *) (-3 + y_1133X))))))) {
            arg0K0 = 1;
            goto L45649;}
          else {
            arg0K0 = 5;
            goto L45649;}}
        else {
          goto L45650;}}
      else {
        goto L45650;}}
    else {
      goto L45650;}}
  else {
    goto L45650;}}
 L13421: {
  a_1718X = arg0K0;
  if ((b_1138X < 0)) {
    arg0K0 = (0 - b_1138X);
    goto L13425;}
  else {
    arg0K0 = b_1138X;
    goto L13425;}}
 L45923: {
  if ((0 == (3 & y_1135X))) {
    goto L45929;}
  else {
    if ((3 == (3 & y_1135X))) {
      if ((19 == (31 & ((((*((long *) ((((char *) (-3 + y_1135X))) + -4))))>>2))))) {
        goto L45929;}
      else {
        goto L45932;}}
    else {
      goto L45932;}}}
 L45932: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1134X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (y_1135X);
  arg0K0 = 2;
  goto L30610;}
 L46137: {
  a_1719X = arg0K0;
  n_1720X = ((y_1140X)>>2);
  if ((n_1720X < 0)) {
    arg0K0 = (0 - n_1720X);
    goto L46139;}
  else {
    arg0K0 = n_1720X;
    goto L46139;}}
 L46099: {
  if ((0 == (3 & y_1140X))) {
    goto L46105;}
  else {
    if ((3 == (3 & y_1140X))) {
      if ((19 == (31 & ((((*((long *) ((((char *) (-3 + y_1140X))) + -4))))>>2))))) {
        goto L46105;}
      else {
        goto L46108;}}
    else {
      goto L46108;}}}
 L46108: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1139X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (y_1140X);
  arg0K0 = 2;
  goto L30610;}
 L46286: {
  SvalS = n_1143X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L46287: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (n_1143X);
  arg0K0 = 1;
  goto L30610;}
 L46341: {
  SvalS = n_1144X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L46342: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (n_1144X);
  arg0K0 = 1;
  goto L30610;}
 L46396: {
  SvalS = 4;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L46399: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (n_1145X);
  arg0K0 = 1;
  goto L30610;}
 L46456: {
  SvalS = n_1146X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L46457: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (n_1146X);
  arg0K0 = 1;
  goto L30610;}
 L46511: {
  SvalS = 0;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L46514: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (n_1147X);
  arg0K0 = 1;
  goto L30610;}
 L54704: {
  x_1721X = SvalS;
  if ((0 == (3 & x_1721X))) {
    if ((0 < x_1721X)) {
      goto L54733;}
    else {
      goto L54727;}}
  else {
    v_1722X = s48_bignum_test((((char *) (-3 + x_1721X))));
    if ((-1 == v_1722X)) {
      goto L54727;}
    else {
      goto L54733;}}}
 L54707: {
push_exception_setupB(5, 1);
  x_1723X = SvalS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1723X);
  arg0K0 = 1;
  goto L30610;}
 L58096: {
  x_1724X = SvalS;
  if ((0 == (3 & x_1724X))) {
    n_1725X = ((x_1724X)>>2);
    if ((n_1725X < 0)) {
      arg0K0 = (0 - n_1725X);
      goto L53714;}
    else {
      arg0K0 = n_1725X;
      goto L53714;}}
  else {
    if ((0 == (3 & x_1724X))) {
      arg0K0 = 1;
      arg0K1 = 3;
      goto L24799;}
    else {
      arg0K0 = (-1 + ((((3 + ((long)(((unsigned long)(*((long *) ((((char *) (-3 + x_1724X))) + -4))))>>8))))>>2)));
      arg0K1 = 0;
      goto L24799;}}}
 L58099: {
push_exception_setupB(5, 1);
  x_1726X = SvalS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1726X);
  arg0K0 = 1;
  goto L30610;}
 L46657: {
  val_1727X = integer_bitwise_not(x_1165X);
  SvalS = val_1727X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L46660: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1165X);
  arg0K0 = 1;
  goto L30610;}
 L46748: {
  x_1728X = arg0K0;
  arg0K0 = x_1728X;
  arg0K1 = 0;
  goto L46754;}
 L46731: {
  val_1729X = integer_bit_count(x_1166X);
  SvalS = val_1729X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L46734: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1166X);
  arg0K0 = 1;
  goto L30610;}
 L46833: {
  if ((0 == (3 & y_1169X))) {
    goto L46839;}
  else {
    if ((3 == (3 & y_1169X))) {
      if ((19 == (31 & ((((*((long *) ((((char *) (-3 + y_1169X))) + -4))))>>2))))) {
        goto L46839;}
      else {
        goto L46842;}}
    else {
      goto L46842;}}}
 L46842: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1168X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (y_1169X);
  arg0K0 = 2;
  goto L30610;}
 L46996: {
  if ((0 == (3 & y_1171X))) {
    goto L47002;}
  else {
    if ((3 == (3 & y_1171X))) {
      if ((19 == (31 & ((((*((long *) ((((char *) (-3 + y_1171X))) + -4))))>>2))))) {
        goto L47002;}
      else {
        goto L47005;}}
    else {
      goto L47005;}}}
 L47005: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1170X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (y_1171X);
  arg0K0 = 2;
  goto L30610;}
 L47159: {
  if ((0 == (3 & y_1173X))) {
    goto L47165;}
  else {
    if ((3 == (3 & y_1173X))) {
      if ((19 == (31 & ((((*((long *) ((((char *) (-3 + y_1173X))) + -4))))>>2))))) {
        goto L47165;}
      else {
        goto L47168;}}
    else {
      goto L47168;}}}
 L47168: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1172X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (y_1173X);
  arg0K0 = 2;
  goto L30610;}
 L43551: {
  val_1730X = arg0K0;
  SvalS = val_1730X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L43567: {
  val_1731X = arg0K0;
  SvalS = val_1731X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L43568: {
push_exception_setupB(6, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1174X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (y_1175X);
  arg0K0 = 2;
  goto L30610;}
 L53764: {
  if ((0 == (3 & y_1175X))) {
    if ((0 == (3 & arg2_1174X))) {
      value_1732X = ((arg2_1174X)>>2);
      count_1733X = ((y_1175X)>>2);
      if ((count_1733X < 0)) {
        PS_SHIFT_RIGHT(value_1732X, (0 - count_1733X), x_1734X)
        x_1735X = x_1734X;s48_make_availableAgc(16);
        if ((536870911 < x_1735X)) {
          goto L53884;}
        else {
          if ((x_1735X < -536870912)) {
            goto L53884;}
          else {
            arg0K0 = (((x_1735X)<<2));
            goto L53879;}}}
      else {
        PS_SHIFT_LEFT(value_1732X, count_1733X, x_1736X)
        result_1737X = x_1736X;
        PS_SHIFT_RIGHT(result_1737X, count_1733X, x_1738X)
        if ((value_1732X == x_1738X)) {
          if ((value_1732X < 0)) {
            if ((result_1737X < 0)) {s48_make_availableAgc(16);
              if ((536870911 < result_1737X)) {
                goto L53906;}
              else {
                if ((result_1737X < -536870912)) {
                  goto L53906;}
                else {
                  arg0K0 = (((result_1737X)<<2));
                  goto L53901;}}}
            else {
              arg0K0 = arg2_1174X;
              arg0K1 = y_1175X;
              goto L53777;}}
          else {
            if ((result_1737X < 0)) {
              arg0K0 = arg2_1174X;
              arg0K1 = y_1175X;
              goto L53777;}
            else {s48_make_availableAgc(16);
              if ((536870911 < result_1737X)) {
                goto L53928;}
              else {
                if ((result_1737X < -536870912)) {
                  goto L53928;}
                else {
                  arg0K0 = (((result_1737X)<<2));
                  goto L53923;}}}}}
        else {
          arg0K0 = arg2_1174X;
          arg0K1 = y_1175X;
          goto L53777;}}}
    else {
      if ((3 == (3 & arg2_1174X))) {
        if ((19 == (31 & ((((*((long *) ((((char *) (-3 + arg2_1174X))) + -4))))>>2))))) {
          y_1739X = ((y_1175X)>>2);
          merged_arg0K0 = arg2_1174X;
          merged_arg0K1 = y_1739X;
          shift_space_return_tag = 0;
          goto shift_space;
         shift_space_return_0:
          needed_1740X = shift_space0_return_value;
          Stemp0S = arg2_1174X;s48_make_availableAgc((((needed_1740X)<<2)));
          value_1741X = Stemp0S;
          Stemp0S = 1;
          if ((0 == (3 & value_1741X))) {
            v_1742X = (char *) s48_long_to_bignum((((value_1741X)>>2)));
            arg3K0 = v_1742X;
            goto L53959;}
          else {
            arg3K0 = (((char *) (-3 + value_1741X)));
            goto L53959;}}
        else {
          goto L53786;}}
      else {
        goto L53786;}}}
  else {push_exception_setupB(5, 1);
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) (arg2_1174X);
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) (y_1175X);
    arg0K0 = 2;
    goto L30610;}}
 L62145: {
  val_1743X = arg0K0;
  SvalS = val_1743X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L51018: {
  val_1744X = arg0K0;
  SvalS = val_1744X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L50989: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1179X);
  x_1745X = SvalS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1745X);
  arg0K0 = 2;
  goto L30610;}
 L50926: {
  val_1746X = arg0K0;
  SvalS = val_1746X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L50897: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1181X);
  x_1747X = SvalS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1747X);
  arg0K0 = 2;
  goto L30610;}
 L55013: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((x_1184X)<<2)));
  arg0K0 = 1;
  goto L30610;}
 L55019: {
  SvalS = (9 + (((x_1184X)<<8)));
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L50824: {
  val_1748X = arg0K0;
  SvalS = val_1748X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L62178: {
  val_1749X = arg0K0;
  SvalS = val_1749X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L62192: {
  value_1750X = arg0K0;
  SvalS = value_1750X;
  Scode_pointerS = ((Scode_pointerS) + 2);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L35684: {
push_exception_setupB(5, 2);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (stob_1191X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((type_1192X)<<2)));
  arg0K0 = 2;
  goto L30610;}
 L35789: {
  SvalS = new_1197X;
  Scode_pointerS = ((Scode_pointerS) + 3);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L35773: {
  i_1751X = arg0K0;
  if ((i_1751X < 0)) {
    goto L35789;}
  else {
    value_1752X = *((long *) (SstackS));
    SstackS = ((SstackS) + 4);
    *((long *) ((((char *) (-3 + new_1197X))) + (((i_1751X)<<2)))) = (long) (value_1752X);
    arg0K0 = (-1 + i_1751X);
    goto L35773;}}
 L35907: {
  i_1753X = arg0K0;
  if ((i_1753X < 0)) {
    arg0K0 = stack_nargs_1205X;
    arg0K1 = rest_list_1206X;
    goto L36049;}
  else {
    value_1754X = *((long *) (SstackS));
    SstackS = ((SstackS) + 4);
    *((long *) ((((char *) (-3 + new_1203X))) + (((i_1753X)<<2)))) = (long) (value_1754X);
    arg0K0 = (-1 + i_1753X);
    goto L35907;}}
 L36075: {
push_exception_setupB(5, 3);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (stob_1207X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((type_1208X)<<2)));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((offset_1209X)<<2)));
  arg0K0 = 3;
  goto L30610;}
 L36192: {
  addr_1755X = (((char *) (-3 + arg2_1210X))) + (((offset_1213X)<<2));S48_WRITE_BARRIER(arg2_1210X, addr_1755X, value_1211X);
  *((long *) addr_1755X) = (long) (value_1211X);
  goto L36201;}
 L36201: {
  SvalS = 13;
  Scode_pointerS = ((Scode_pointerS) + 4);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L36202: {
push_exception_setupB(5, 4);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1210X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((type_1212X)<<2)));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((offset_1213X)<<2)));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (value_1211X);
  arg0K0 = 4;
  goto L30610;}
 L36419: {
push_exception_setupB(5, 2);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((type_1217X)<<2)));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((len_1218X)<<2)));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (init_1216X);
  arg0K0 = 3;
  goto L30610;}
 L36436: {
  x_1756X = arg0K0;
  value_1757X = Stemp0S;
  Stemp0S = 1;
  if ((1 == x_1756X)) {push_exception_setupB(8, 2);
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) ((((type_1217X)<<2)));
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) ((((len_1218X)<<2)));
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) (value_1757X);
    arg0K0 = 3;
    goto L30610;}
  else {
    arg0K0 = (-1 + len_1218X);
    goto L36462;}}
 L36709: {
push_exception_setupB(7, 3);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1221X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((type_1223X)<<2)));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (index_1222X);
  arg0K0 = 3;
  goto L30610;}
 L36699: {
  arg0K0 = (*((long *) ((((char *) (-3 + arg2_1221X))) + (-4 & index_1222X))));
  goto L36708;}
 L36708: {
  value_1758X = arg0K0;
  SvalS = value_1758X;
  Scode_pointerS = ((Scode_pointerS) + 3);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L36664: {
push_exception_setupB(5, 3);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1221X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((type_1223X)<<2)));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (index_1222X);
  arg0K0 = 3;
  goto L30610;}
 L36996: {
push_exception_setupB(7, 3);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg3_1229X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((type_1231X)<<2)));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1228X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (value_1230X);
  arg0K0 = 4;
  goto L30610;}
 L36986: {
  addr_1759X = (((char *) (-3 + arg3_1229X))) + (-4 & arg2_1228X);S48_WRITE_BARRIER(arg3_1229X, addr_1759X, value_1230X);
  *((long *) addr_1759X) = (long) (value_1230X);
  goto L36995;}
 L36995: {
  SvalS = 13;
  Scode_pointerS = ((Scode_pointerS) + 3);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L36949: {
push_exception_setupB(5, 3);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg3_1229X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((type_1231X)<<2)));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1228X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (value_1230X);
  arg0K0 = 4;
  goto L30610;}
 L62235: {
  new_1760X = arg0K0;
  if ((1 == new_1760X)) {push_exception_setupB(8, 1);
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) (72);
    arg0K0 = 1;
    goto L30610;}
  else {
    SvalS = new_1760X;
    Scode_pointerS = ((Scode_pointerS) + 1);
    arg3K0 = (Scode_pointerS);
    goto L32913;}}
 L47441: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((len_1237X)<<2)));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((init_1238X)<<2)));
  arg0K0 = 2;
  goto L30610;}
 L47456: {
  vector_1761X = arg0K0;
  if ((1 == vector_1761X)) {push_exception_setupB(8, 1);
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) ((((len_1237X)<<2)));
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) ((((init_1238X)<<2)));
    arg0K0 = 2;
    goto L30610;}
  else {
    arg0K0 = (-1 + len_1237X);
    goto L47478;}}
 L59361: {
push_exception_setupB(5, 1);
  x_1762X = SvalS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1762X);
  arg0K0 = 1;
  goto L30610;}
 L55156: {
push_exception_setupB(7, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1242X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((index_1243X)<<2)));
  arg0K0 = 2;
  goto L30610;}
 L58777: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1242X);
  x_1763X = SvalS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1763X);
  arg0K0 = 2;
  goto L30610;}
 L52336: {
push_exception_setupB(7, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg3_1246X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((index_1247X)<<2)));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((Kchar_1248X)<<2)));
  arg0K0 = 3;
  goto L30610;}
 L52315: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg3_1246X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((index_1247X)<<2)));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((Kchar_1248X)<<2)));
  arg0K0 = 3;
  goto L30610;}
 L57416: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg3_1246X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1245X);
  x_1764X = SvalS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1764X);
  arg0K0 = 3;
  goto L30610;}
 L47626: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((len_1251X)<<2)));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((9 + (((init_1252X)<<8))));
  arg0K0 = 2;
  goto L30610;}
 L47641: {
  vector_1765X = arg0K0;
  if ((1 == vector_1765X)) {push_exception_setupB(8, 1);
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) ((((len_1251X)<<2)));
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) ((9 + (((init_1252X)<<8))));
    arg0K0 = 2;
    goto L30610;}
  else {
    arg0K0 = (-1 + len_1251X);
    goto L47663;}}
 L55237: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1250X);
  x_1766X = SvalS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1766X);
  arg0K0 = 2;
  goto L30610;}
 L59411: {
push_exception_setupB(5, 1);
  x_1767X = SvalS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1767X);
  arg0K0 = 1;
  goto L30610;}
 L55302: {
push_exception_setupB(7, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1257X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((index_1258X)<<2)));
  arg0K0 = 2;
  goto L30610;}
 L55330: {
  bits_1768X = arg0K0;
  j_1769X = arg0K1;
  scalar_value_1770X = arg0K2;
  if ((j_1769X < 4)) {
    PS_SHIFT_LEFT((*((unsigned char *) ((((char *) (-3 + arg2_1257X))) + ((((index_1258X)<<2)) + j_1769X)))), bits_1768X, x_1771X)
    arg0K0 = (8 + bits_1768X);
    arg0K1 = (1 + j_1769X);
    arg0K2 = (x_1771X + scalar_value_1770X);
    goto L55330;}
  else {
    SvalS = (9 + (((scalar_value_1770X)<<8)));
    Scode_pointerS = ((Scode_pointerS) + 1);
    arg3K0 = (Scode_pointerS);
    goto L32913;}}
 L58875: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1257X);
  x_1772X = SvalS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1772X);
  arg0K0 = 2;
  goto L30610;}
 L52491: {
push_exception_setupB(7, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg3_1261X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((index_1262X)<<2)));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((9 + (((Kchar_1263X)<<8))));
  arg0K0 = 3;
  goto L30610;}
 L52555: {
  bits_1773X = arg0K0;
  j_1774X = arg0K1;
  shifted_1775X = arg0K2;
  if ((j_1774X < 4)) {
    *((unsigned char *) ((((char *) (-3 + arg3_1261X))) + ((((index_1262X)<<2)) + j_1774X))) = (unsigned char) ((255 & shifted_1775X));
    arg0K0 = (8 + bits_1773X);
    arg0K1 = (1 + j_1774X);
    arg0K2 = ((long)(((unsigned long)shifted_1775X)>>8));
    goto L52555;}
  else {
    SvalS = 13;
    Scode_pointerS = ((Scode_pointerS) + 1);
    arg3K0 = (Scode_pointerS);
    goto L32913;}}
 L52470: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg3_1261X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((index_1262X)<<2)));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((9 + (((Kchar_1263X)<<8))));
  arg0K0 = 3;
  goto L30610;}
 L57546: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg3_1261X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1260X);
  x_1776X = SvalS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1776X);
  arg0K0 = 3;
  goto L30610;}
 L37331: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg5_1268X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((from_index_1269X)<<2)));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg3_1266X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((to_index_1270X)<<2)));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((count_1271X)<<2)));
  arg0K0 = 5;
  goto L30610;}
 L42504: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg5_1268X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg4_1267X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg3_1266X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1265X);
  x_1777X = SvalS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1777X);
  arg0K0 = 5;
  goto L30610;}
 L28187: {
  bucket_1778X = arg0K0;
  arg0K0 = bucket_1778X;
  goto L28193;}
 L43713: {
push_exception_setupB(5, 1);
  x_1779X = SvalS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1779X);
  arg0K0 = 1;
  goto L30610;}
 L57110: {
  val_1780X = arg0K0;
  SvalS = val_1780X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L57091: {
push_exception_setupB(5, 1);
  x_1781X = SvalS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1781X);
  arg0K0 = 1;
  goto L30610;}
 L52093: {
  if ((1 == (SvalS))) {
    addr_1782X = (((char *) (-3 + arg2_1283X))) + 4;S48_WRITE_BARRIER(arg2_1283X, addr_1782X, 273);
    *((long *) addr_1782X) = (long) (273);
    goto L52099;}
  else {
    if ((17 == (255 & (*((long *) ((((char *) (-3 + arg2_1283X))) + 4)))))) {
      addr_1783X = (((char *) (-3 + arg2_1283X))) + 4;S48_WRITE_BARRIER(arg2_1283X, addr_1783X, 529);
      *((long *) addr_1783X) = (long) (529);
      goto L52099;}
    else {
      goto L52099;}}}
 L52100: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1283X);
  x_1784X = SvalS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1784X);
  arg0K0 = 2;
  goto L30610;}
 L62297: {
  val_1785X = arg0K0;
  SvalS = val_1785X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L55394: {
  SvalS = x_1286X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L48065: {
  if ((0 == (3 & arg4_1289X))) {
    if (((((arg4_1289X)>>2)) < 0)) {push_exception_setupB(5, 1);
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (arg4_1289X);
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) ((((mode_1290X)<<2)));
      arg0K0 = 2;
      goto L30610;}
    else {
      arg0K0 = (((arg4_1289X)>>2));
      goto L47851;}}
  else {
    if ((3 == (3 & arg4_1289X))) {
      if ((17 == (31 & ((((*((long *) ((((char *) (-3 + arg4_1289X))) + -4))))>>2))))) {
        filename_1786X = ((char *)(((char *) (-3 + arg4_1289X))));
        if ((1 == mode_1290X)) {
          goto L47913;}
        else {
          if ((3 == mode_1290X)) {
            goto L47913;}
          else {
            v_1787X = ps_open_fd(filename_1786X, 0, &v_1788X);
            arg0K0 = v_1787X;
            arg0K1 = v_1788X;
            goto L47922;}}}
      else {push_exception_setupB(5, 1);
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (arg4_1289X);
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) ((((mode_1290X)<<2)));
        arg0K0 = 2;
        goto L30610;}}
    else {push_exception_setupB(5, 1);
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (arg4_1289X);
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) ((((mode_1290X)<<2)));
      arg0K0 = 2;
      goto L30610;}}}
 L62316: {
push_exception_setupB(5, 1);
  x_1789X = SvalS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1789X);
  arg0K0 = 1;
  goto L30610;}
 L55594: {
  if ((1 == (SvalS))) {
    arg4K0 = 0;
    goto L55604;}
  else {
    arg4K0 = 1;
    goto L55604;}}
 L55605: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg5_1300X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg4_1299X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg3_1298X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1297X);
  x_1790X = SvalS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1790X);
  arg0K0 = 5;
  goto L30610;}
 L48698: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg4_1304X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg3_1303X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((start_1305X)<<2)));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((count_1306X)<<2)));
  arg0K0 = 4;
  goto L30610;}
 L48697: {
  val_1791X = arg0K0;
  SvalS = val_1791X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L55808: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg4_1304X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg3_1303X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1302X);
  x_1792X = SvalS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1792X);
  arg0K0 = 4;
  goto L30610;}
 L58592: {
  val_1793X = arg0K0;
  SvalS = val_1793X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L51684: {
  val_1794X = arg0K0;
  SvalS = val_1794X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L62351: {
push_exception_setupB(5, 1);
  x_1795X = SvalS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1795X);
  arg0K0 = 1;
  goto L30610;}
 L55956: {
  val_1796X = arg0K0;
  SvalS = val_1796X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L15790: {
  x_1797X = Spending_channels_headS;
  if ((1 == x_1797X)) {
    Spending_interruptsS = (-17 & (Spending_interruptsS));
    goto L15802;}
  else {
    goto L15802;}}
 L15808: {
  ch_1798X = arg0K0;
  prev_1799X = arg0K1;
  if ((1 == ch_1798X)) {
    addr_1800X = (((char *) (-3 + channel_1324X))) + 20;S48_WRITE_BARRIER(channel_1324X, addr_1800X, 1);
    *((long *) addr_1800X) = (long) (1);
    n_1801X = ps_abort_fd_op(((((*((long *) ((((char *) (-3 + channel_1324X))) + 8))))>>2)));
    arg0K0 = (((n_1801X)<<2));
    goto L55956;}
  else {
    if ((ch_1798X == channel_1324X)) {
      y_1802X = Spending_channels_tailS;
      if ((ch_1798X == y_1802X)) {
        Spending_channels_tailS = prev_1799X;
        goto L15832;}
      else {
        goto L15832;}}
    else {
      arg0K0 = (*((long *) ((((char *) (-3 + ch_1798X))) + 16)));
      arg0K1 = ch_1798X;
      goto L15808;}}}
 L55939: {
push_exception_setupB(5, 1);
  x_1803X = SvalS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1803X);
  arg0K0 = 1;
  goto L30610;}
 L22599: {
  i_1804X = arg0K0;
  res_1805X = arg0K1;
  if ((-1 == i_1804X)) {
    SvalS = res_1805X;
    Scode_pointerS = ((Scode_pointerS) + 1);
    arg3K0 = (Scode_pointerS);
    goto L32913;}
  else {
    channel_1806X = *((Svm_channelsS) + i_1804X);
    if ((3 == (3 & channel_1806X))) {
      if ((6 == (31 & ((((*((long *) ((((char *) (-3 + channel_1806X))) + -4))))>>2))))) {
        addr_1807X = s48_allocate_small(12);
        *((long *) addr_1807X) = (long) (2050);
        x_1808X = 3 + (((long) (addr_1807X + 4)));
        *((long *) (((char *) (-3 + x_1808X)))) = (long) (channel_1806X);
        *((long *) ((((char *) (-3 + x_1808X))) + 4)) = (long) (res_1805X);
        arg0K0 = x_1808X;
        goto L22613;}
      else {
        arg0K0 = res_1805X;
        goto L22613;}}
    else {
      arg0K0 = res_1805X;
      goto L22613;}}}
 L48919: {
  old_1809X = *((long *) ((((char *) (-3 + (Scurrent_threadS)))) + 12));
  if ((1 == old_1809X)) {
    goto L48935;}
  else {
    addr_1810X = ((char *) (-3 + old_1809X));S48_WRITE_BARRIER(old_1809X, addr_1810X, 1);
    *((long *) addr_1810X) = (long) (1);
    goto L48935;}}
 L48950: {
  if ((proposal_1334X == (*((long *) ((((char *) (-3 + (Scurrent_threadS)))) + 12))))) {
    SvalS = 13;
    Scode_pointerS = ((Scode_pointerS) + 1);
    arg3K0 = (Scode_pointerS);
    goto L32913;}
  else {push_exception_setupB(5, 1);
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) (proposal_1334X);
    arg0K0 = 1;
    goto L30610;}}
 L14222: {
  i_1811X = arg0K0;
  stob_1812X = *((long *) ((((char *) (-3 + log_1336X))) + (((i_1811X)<<2))));
  if ((1 == stob_1812X)) {
    log_1813X = *((long *) ((((char *) (-3 + proposal_1335X))) + 8));
    arg0K0 = 0;
    goto L14460;}
  else {
    value_1814X = *((long *) ((((char *) (-3 + log_1336X))) + (8 + (((i_1811X)<<2)))));
    verify_1815X = *((long *) ((((char *) (-3 + log_1336X))) + (12 + (((i_1811X)<<2)))));
    if ((29 == verify_1815X)) {
      if ((3 == (3 & stob_1812X))) {
        if ((0 == (128 & (*((long *) ((((char *) (-3 + stob_1812X))) + -4)))))) {
          goto L14274;}
        else {
          goto L49198;}}
      else {
        goto L49198;}}
    else {
      if ((verify_1815X == (*((long *) ((((char *) (-3 + stob_1812X))) + (-4 & (*((long *) ((((char *) (-3 + log_1336X))) + (4 + (((i_1811X)<<2)))))))))))) {
        if ((verify_1815X == value_1814X)) {
          goto L14274;}
        else {
          if ((3 == (3 & stob_1812X))) {
            if ((0 == (128 & (*((long *) ((((char *) (-3 + stob_1812X))) + -4)))))) {
              goto L14274;}
            else {
              goto L49198;}}
          else {
            goto L49198;}}}
      else {
        goto L49198;}}}}
 L37612: {
  value_1816X = arg0K0;
  SvalS = value_1816X;
  Scode_pointerS = ((Scode_pointerS) + 3);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L37613: {
push_exception_setupB(5, 3);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (stob_1337X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((type_1338X)<<2)));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((offset_1339X)<<2)));
  arg0K0 = 3;
  goto L30610;}
 L37706: {
push_exception_setupB(5, 2);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg5_1345X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((from_index_1346X)<<2)));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg3_1343X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((to_index_1347X)<<2)));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((count_1348X)<<2)));
  arg0K0 = 5;
  goto L30610;}
 L37766: {
  memmove((void *)((((char *) (-3 + arg3_1343X))) + to_index_1347X), (void *)((((char *) (-3 + arg5_1345X))) + from_index_1346X),count_1348X);
  SvalS = 13;
  Scode_pointerS = ((Scode_pointerS) + 2);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L37863: {
  left_1817X = arg0K0;
  copies_1818X = arg0K1;
  if ((1 == copies_1818X)) {
    if ((left_1817X < count_1348X)) {
      goto L37706;}
    else {
      from_index_1819X = ((from_index_1346X)<<2);
      to_index_1820X = ((to_index_1347X)<<2);
      count_1821X = ((count_1348X)<<2);
      Stemp0S = arg5_1345X;
      Stemp1S = arg3_1343X;
      addr_1822X = s48_allocate_tracedAgc(28);
      if ((addr_1822X == NULL)) {
        arg0K0 = 1;
        goto L13937;}
      else {
        *((long *) addr_1822X) = (long) (6154);
        arg0K0 = (3 + (((long) (addr_1822X + 4))));
        goto L13937;}}}
  else {
    arg0K0 = (left_1817X - ((((*((long *) ((((char *) (-3 + copies_1818X))) + 16))))>>2)));
    arg0K1 = (*((long *) ((((char *) (-3 + copies_1818X))) + 20)));
    goto L37863;}}
 L42783: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg5_1345X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg4_1344X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg3_1343X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1342X);
  x_1823X = SvalS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1823X);
  arg0K0 = 5;
  goto L30610;}
 L38132: {
push_exception_setupB(7, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1350X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((index_1351X)<<2)));
  arg0K0 = 2;
  goto L30610;}
 L38131: {
  value_1824X = arg0K0;
  SvalS = value_1824X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L20642: {
  i_1825X = arg0K0;
  next_stob_1826X = *((long *) ((((char *) (-3 + log_1355X))) + (((i_1825X)<<2))));
  if ((1 == next_stob_1826X)) {
    v_1827X = add_log_entryAgc(2, i_1825X, arg2_1350X, index_1354X, ((((*((unsigned char *) ((((char *) (-3 + arg2_1350X))) + (((index_1354X)>>2))))))<<2)), 1);
    arg0K0 = v_1827X;
    goto L38131;}
  else {
    if ((arg2_1350X == next_stob_1826X)) {
      if ((index_1354X == (*((long *) ((((char *) (-3 + log_1355X))) + (4 + (((i_1825X)<<2)))))))) {
        arg0K0 = (*((long *) ((((char *) (-3 + log_1355X))) + (8 + (((i_1825X)<<2))))));
        goto L38131;}
      else {
        goto L20664;}}
    else {
      goto L20664;}}}
 L42979: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1350X);
  x_1828X = SvalS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1828X);
  arg0K0 = 2;
  goto L30610;}
 L38258: {
push_exception_setupB(7, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg3_1357X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((index_1358X)<<2)));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (byte_1359X);
  arg0K0 = 3;
  goto L30610;}
 L38257: {
  SvalS = 13;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L20818: {
  i_1829X = arg0K0;
  next_stob_1830X = *((long *) ((((char *) (-3 + log_1363X))) + (((i_1829X)<<2))));
  if ((1 == next_stob_1830X)) {add_log_entryAgc(2, i_1829X, arg3_1357X, index_1362X, byte_1359X, 0);
    goto L38257;}
  else {
    if ((arg3_1357X == next_stob_1830X)) {
      if ((index_1362X == (*((long *) ((((char *) (-3 + log_1363X))) + (4 + (((i_1829X)<<2)))))))) {
        addr_1831X = (((char *) (-3 + log_1363X))) + (8 + (((i_1829X)<<2)));S48_WRITE_BARRIER(log_1363X, addr_1831X, byte_1359X);
        *((long *) addr_1831X) = (long) (byte_1359X);
        goto L38257;}
      else {
        goto L20838;}}
    else {
      goto L20838;}}}
 L38223: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg3_1357X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((index_1358X)<<2)));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (byte_1359X);
  arg0K0 = 3;
  goto L30610;}
 L43084: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg3_1357X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1356X);
  x_1832X = SvalS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1832X);
  arg0K0 = 3;
  goto L30610;}
 L52729: {
  reason_1833X = arg0K0;
  status_1834X = arg0K1;push_exception_setupB(reason_1833X, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg4_1367X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg3_1366X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1365X);
  merged_arg0K0 = status_1834X;
  merged_arg0K1 = 0;
  get_error_string_return_tag = 3;
  goto get_error_string;
 get_error_string_return_3:
  x_1835X = get_error_string0_return_value;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1835X);
  arg0K0 = 4;
  goto L30610;}
 L57747: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg4_1367X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg3_1366X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1365X);
  x_1836X = SvalS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1836X);
  arg0K0 = 4;
  goto L30610;}
 L58460: {
push_exception_setupB(5, 1);
  x_1837X = SvalS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1837X);
  arg0K0 = 1;
  goto L30610;}
 L53004: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1379X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (proc_1380X);
  arg0K0 = 2;
  goto L30610;}
 L56075: {
  firstP_1838X = arg4K0;
  vector_1839X = s48_find_all(type_1394X);
  if ((1 == vector_1839X)) {
    if (firstP_1838X) {s48_collect(1);
      arg4K0 = 0;
      goto L56075;}
    else {push_exception_setupB(8, 1);
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) ((((type_1394X)<<2)));
      arg0K0 = 1;
      goto L30610;}}
  else {
    SvalS = vector_1839X;
    Scode_pointerS = ((Scode_pointerS) + 1);
    arg3K0 = (Scode_pointerS);
    goto L32913;}}
 L62473: {
  firstP_1840X = arg4K0;
  type_1841X = arg0K1;
  vector_1842X = s48_find_all_records(type_1841X);
  if ((1 == vector_1842X)) {
    if (firstP_1840X) {
      Stemp0S = type_1841X;s48_collect(1);
      value_1843X = Stemp0S;
      Stemp0S = 1;
      arg4K0 = 0;
      arg0K1 = value_1843X;
      goto L62473;}
    else {push_exception_setupB(8, 1);
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (type_1841X);
      arg0K0 = 1;
      goto L30610;}}
  else {
    SvalS = vector_1842X;
    Scode_pointerS = ((Scode_pointerS) + 1);
    arg3K0 = (Scode_pointerS);
    goto L32913;}}
 L34657: {
push_exception_setupB(5, 1);
  x_1844X = SvalS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1844X);
  arg0K0 = 1;
  goto L30610;}
 L32995: {
  Slast_code_calledS = code_1401X;
  Scode_pointerS = ((((char *) (-3 + code_1401X))) + (pc_1404X + (((size_1403X)>>2))));
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L30871: {
  ps_write_string("returning to nc ", (stderr));
  ps_write_integer((*((long *) (SstackS))), (stderr));
  arg0K0 = 0;
  arg0K1 = 25;
  arg0K2 = 0;
  goto L30038;}
 L33554: {
push_exception_setupB(5, 1);
  x_1845X = SvalS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1845X);
  arg0K0 = 1;
  goto L30610;}
 L62521: {
  SvalS = (((old_1412X)<<2));
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L59576: {
  x_1846X = s48_schedule_alarm_interrupt((((p_1424X)>>2)));
  SvalS = (((x_1846X)<<2));
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L57295: {
  if ((1 == (SvalS))) {
    arg4K0 = 0;
    goto L57299;}
  else {
    arg4K0 = 1;
    goto L57299;}}
 L57300: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1426X);
  x_1847X = SvalS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1847X);
  arg0K0 = 2;
  goto L30610;}
 L38457: {
  rest_list_1848X = arg0K0;
  if ((25 == rest_list_1848X)) {
    name_1849X = *((long *) ((SstackS) + (-8 + (((nargs_1429X)<<2)))));
    proc_1850X = *((long *) ((SstackS) + (-4 + (((nargs_1429X)<<2)))));
    args_1851X = SstackS;
    if ((3 == (3 & name_1849X))) {
      if ((16 == (31 & ((((*((long *) ((((char *) (-3 + name_1849X))) + -4))))>>2))))) {
        if ((3 == (3 & proc_1850X))) {
          if ((17 == (31 & ((((*((long *) ((((char *) (-3 + proc_1850X))) + -4))))>>2))))) {
            if ((4 == ((long)(((unsigned long)(*((long *) ((((char *) (-3 + proc_1850X))) + -4))))>>8)))) {
              SstackS = (ScontS);
              result_1852X = s48_external_call(proc_1850X, name_1849X, (-2 + nargs_1429X), args_1851X);
              if ((Sexternal_exceptionPS)) {
                Sexternal_exceptionPS = 0;
                arg0K0 = (Sexternal_exception_nargsS);
                goto L30610;}
              else {
                SvalS = result_1852X;
                Scode_pointerS = ((Scode_pointerS) + 1);
                arg3K0 = (Scode_pointerS);
                goto L32913;}}
            else {
              goto L38713;}}
          else {
            goto L38713;}}
        else {
          goto L38713;}}
      else {
        goto L38713;}}
    else {
      goto L38713;}}
  else {
    x_1853X = *((long *) (((char *) (-3 + rest_list_1848X))));
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) (x_1853X);
    arg0K0 = (*((long *) ((((char *) (-3 + rest_list_1848X))) + 4)));
    goto L38457;}}
 L56170: {
  if ((1 == (SvalS))) {
    v_1854X = Hlookup833((Sexported_bindingsS), arg2_1433X, 0);
    arg0K0 = v_1854X;
    goto L56211;}
  else {
    v_1855X = Hlookup814((Simported_bindingsS), arg2_1433X, 0);
    arg0K0 = v_1855X;
    goto L56211;}}
 L56175: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1433X);
  x_1856X = SvalS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1856X);
  arg0K0 = 2;
  goto L30610;}
 L41917: {
  if ((1 == (SvalS))) {
    arg0K0 = (Sexported_bindingsS);
    goto L41952;}
  else {
    arg0K0 = (Simported_bindingsS);
    goto L41952;}}
 L41922: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1435X);
  x_1857X = SvalS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1857X);
  arg0K0 = 2;
  goto L30610;}
 L62581: {
  firstP_1858X = arg4K0;
  vector_1859X = s48_gather_objects(shared_binding_undefinedP, for_each_imported_binding);
  if ((1 == vector_1859X)) {
    if (firstP_1858X) {s48_collect(1);
      arg4K0 = 0;
      goto L62581;}
    else {push_exception_setupB(8, 1);
      arg0K0 = 0;
      goto L30610;}}
  else {
    SvalS = vector_1859X;
    Scode_pointerS = ((Scode_pointerS) + 1);
    arg3K0 = (Scode_pointerS);
    goto L32913;}}
 L58394: {
  option_1860X = arg0K0;
  seconds_1861X = arg0K1;
  mseconds_1862X = arg0K2;
  if ((536869 < seconds_1861X)) {push_exception_setupB(6, 1);
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) ((((option_1860X)<<2)));
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) ((((seconds_1861X)<<2)));
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) ((((mseconds_1862X)<<2)));
    arg0K0 = 3;
    goto L30610;}
  else {
    SvalS = (((((1000 * seconds_1861X) + mseconds_1862X))<<2));
    Scode_pointerS = ((Scode_pointerS) + 1);
    arg3K0 = (Scode_pointerS);
    goto L32913;}}
 L62638: {
  s48_Scallback_return_stack_blockS = arg2_1458X;
  arg0K0 = x_1459X;
  goto L65498;}
 L50604: {
  val_1863X = arg0K0;
  SvalS = val_1863X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L50569: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1460X);
  x_1864X = SvalS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1864X);
  arg0K0 = 2;
  goto L30610;}
 L49788: {
  len_1865X = ((n_1465X)<<2);
  addr_1866X = s48_allocate_small((4 + len_1865X));
  *((long *) addr_1866X) = (long) ((66 + (((len_1865X)<<8))));
  obj_1867X = 3 + (((long) (addr_1866X + 4)));
  arg0K0 = arg2_1464X;
  arg0K1 = (-1 + n_1465X);
  goto L49765;}
 L49740: {
  if ((25 == arg2_1464X)) {
    goto L49788;}
  else {push_exception_setupB(5, 1);
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) (arg2_1464X);
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) ((((n_1465X)<<2)));
    arg0K0 = 2;
    goto L30610;}}
 L51747: {
  list_1868X = arg0K0;
  slow_1869X = arg0K1;
  move_slowP_1870X = arg4K2;
  if ((25 == list_1868X)) {
    SvalS = 1;
    Scode_pointerS = ((Scode_pointerS) + 1);
    arg3K0 = (Scode_pointerS);
    goto L32913;}
  else {
    if ((3 == (3 & list_1868X))) {
      if ((0 == (31 & ((((*((long *) ((((char *) (-3 + list_1868X))) + -4))))>>2))))) {
        head_1871X = *((long *) (((char *) (-3 + list_1868X))));
        if ((3 == (3 & head_1871X))) {
          if ((0 == (31 & ((((*((long *) ((((char *) (-3 + head_1871X))) + -4))))>>2))))) {
            if (((*((long *) (((char *) (-3 + head_1871X))))) == arg2_1467X)) {
              SvalS = head_1871X;
              Scode_pointerS = ((Scode_pointerS) + 1);
              arg3K0 = (Scode_pointerS);
              goto L32913;}
            else {
              list_1872X = *((long *) ((((char *) (-3 + list_1868X))) + 4));
              if ((list_1872X == slow_1869X)) {push_exception_setupB(5, 1);
                SstackS = ((SstackS) + -4);
                *((long *) (SstackS)) = (long) (arg2_1467X);
                SstackS = ((SstackS) + -4);
                *((long *) (SstackS)) = (long) (list_1468X);
                arg0K0 = 2;
                goto L30610;}
              else {
                if (move_slowP_1870X) {
                  arg0K0 = list_1872X;
                  arg0K1 = (*((long *) ((((char *) (-3 + slow_1869X))) + 4)));
                  arg4K2 = 0;
                  goto L51747;}
                else {
                  arg0K0 = list_1872X;
                  arg0K1 = slow_1869X;
                  arg4K2 = 1;
                  goto L51747;}}}}
          else {push_exception_setupB(5, 1);
            SstackS = ((SstackS) + -4);
            *((long *) (SstackS)) = (long) (arg2_1467X);
            SstackS = ((SstackS) + -4);
            *((long *) (SstackS)) = (long) (list_1468X);
            arg0K0 = 2;
            goto L30610;}}
        else {push_exception_setupB(5, 1);
          SstackS = ((SstackS) + -4);
          *((long *) (SstackS)) = (long) (arg2_1467X);
          SstackS = ((SstackS) + -4);
          *((long *) (SstackS)) = (long) (list_1468X);
          arg0K0 = 2;
          goto L30610;}}
      else {push_exception_setupB(5, 1);
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (arg2_1467X);
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (list_1468X);
        arg0K0 = 2;
        goto L30610;}}
    else {push_exception_setupB(5, 1);
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (arg2_1467X);
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (list_1468X);
      arg0K0 = 2;
      goto L30610;}}}
 L38789: {
push_exception_setupB(7, 2);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg3_1470X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1469X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((index_1471X)<<2)));
  arg0K0 = 3;
  goto L30610;}
 L38779: {
  arg0K0 = (*((long *) ((((char *) (-3 + arg3_1470X))) + (((index_1471X)<<2)))));
  goto L38788;}
 L38788: {
  value_1873X = arg0K0;
  SvalS = value_1873X;
  Scode_pointerS = ((Scode_pointerS) + 2);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L38809: {
push_exception_setupB(5, 2);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg3_1470X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1469X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((index_1471X)<<2)));
  arg0K0 = 3;
  goto L30610;}
 L39047: {
push_exception_setupB(7, 2);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg4_1478X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg3_1477X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((index_1479X)<<2)));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (value_1480X);
  arg0K0 = 4;
  goto L30610;}
 L39037: {
  addr_1874X = (((char *) (-3 + arg4_1478X))) + (((index_1479X)<<2));S48_WRITE_BARRIER(arg4_1478X, addr_1874X, value_1480X);
  *((long *) addr_1874X) = (long) (value_1480X);
  goto L39046;}
 L39046: {
  SvalS = 13;
  Scode_pointerS = ((Scode_pointerS) + 2);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L39069: {
push_exception_setupB(5, 2);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg4_1478X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg3_1477X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((index_1479X)<<2)));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (value_1480X);
  arg0K0 = 4;
  goto L30610;}
 L31229: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((encoding_1488X)<<2)));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((9 + (((value_1489X)<<8))));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg3_1485X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((start_1490X)<<2)));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((count_1491X)<<2)));
  arg0K0 = 5;
  goto L30610;}
 L31281: {
  x_1875X = arg0K0;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1875X);
  if (okP_1493X) {
    arg0K0 = (((count_1495X)<<2));
    goto L31291;}
  else {
    arg0K0 = 1;
    goto L31291;}}
 L31959: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg5_1487X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg4_1486X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg3_1485X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1484X);
  x_1876X = SvalS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1876X);
  arg0K0 = 5;
  goto L30610;}
 L49943: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((encoding_1500X)<<2)));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((9 + (((value_1501X)<<8))));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg3_1497X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((start_1502X)<<2)));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((count_1503X)<<2)));
  arg0K0 = 5;
  goto L30610;}
 L56579: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg5_1499X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg4_1498X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg3_1497X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1496X);
  x_1877X = SvalS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1877X);
  arg0K0 = 5;
  goto L30610;}
 L31514: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((encoding_1511X)<<2)));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg3_1509X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((start_1512X)<<2)));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((count_1513X)<<2)));
  arg0K0 = 4;
  goto L30610;}
 L31580: {
  x_1878X = arg0K0;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1878X);
  if (okP_1515X) {
    arg0K0 = (((count_1518X)<<2));
    goto L31590;}
  else {
    arg0K0 = 1;
    goto L31590;}}
 L32155: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg4_1510X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg3_1509X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1508X);
  x_1879X = SvalS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1879X);
  arg0K0 = 4;
  goto L30610;}
 L50162: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((encoding_1522X)<<2)));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg3_1520X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((start_1523X)<<2)));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((count_1524X)<<2)));
  arg0K0 = 4;
  goto L30610;}
 L56775: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg4_1521X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg3_1520X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1519X);
  x_1880X = SvalS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1880X);
  arg0K0 = 4;
  goto L30610;}
 L39326: {
  port_1881X = arg0K0;
  if ((3 == (3 & port_1881X))) {
    if ((7 == (31 & ((((*((long *) ((((char *) (-3 + port_1881X))) + -4))))>>2))))) {
      if ((0 == (4 & ((((*((long *) ((((char *) (-3 + port_1881X))) + 12))))>>2))))) {
        goto L39383;}
      else {
        b_1882X = *((long *) ((((char *) (-3 + port_1881X))) + 24));
        if ((1 == b_1882X)) {push_exception_setupB(13, 2);
          SstackS = ((SstackS) + -4);
          *((long *) (SstackS)) = (long) (port_1881X);
          arg0K0 = 1;
          goto L30610;}
        else {
          p_1883X = *((long *) ((((char *) (-3 + port_1881X))) + 28));
          p_1884X = *((long *) ((((char *) (-3 + port_1881X))) + 32));
          i_1885X = ((p_1883X)>>2);
          if ((i_1885X == (((p_1884X)>>2)))) {push_exception_setupB(13, 2);
            SstackS = ((SstackS) + -4);
            *((long *) (SstackS)) = (long) (port_1881X);
            arg0K0 = 1;
            goto L30610;}
          else {
            val_1886X = 4 + (((i_1885X)<<2));
            addr_1887X = (((char *) (-3 + port_1881X))) + 28;S48_WRITE_BARRIER(port_1881X, addr_1887X, val_1886X);
            *((long *) addr_1887X) = (long) (val_1886X);
            SvalS = ((((*((unsigned char *) ((((char *) (-3 + b_1882X))) + i_1885X))))<<2));
            Scode_pointerS = ((Scode_pointerS) + 2);
            arg3K0 = (Scode_pointerS);
            goto L32913;}}}}
    else {
      goto L39383;}}
  else {
    goto L39383;}}
 L39528: {
  port_1888X = arg0K0;
  if ((3 == (3 & port_1888X))) {
    if ((7 == (31 & ((((*((long *) ((((char *) (-3 + port_1888X))) + -4))))>>2))))) {
      if ((0 == (4 & ((((*((long *) ((((char *) (-3 + port_1888X))) + 12))))>>2))))) {
        goto L39585;}
      else {
        b_1889X = *((long *) ((((char *) (-3 + port_1888X))) + 24));
        if ((1 == b_1889X)) {push_exception_setupB(13, 2);
          SstackS = ((SstackS) + -4);
          *((long *) (SstackS)) = (long) (port_1888X);
          arg0K0 = 1;
          goto L30610;}
        else {
          p_1890X = *((long *) ((((char *) (-3 + port_1888X))) + 28));
          p_1891X = *((long *) ((((char *) (-3 + port_1888X))) + 32));
          i_1892X = ((p_1890X)>>2);
          if ((i_1892X == (((p_1891X)>>2)))) {push_exception_setupB(13, 2);
            SstackS = ((SstackS) + -4);
            *((long *) (SstackS)) = (long) (port_1888X);
            arg0K0 = 1;
            goto L30610;}
          else {
            SvalS = ((((*((unsigned char *) ((((char *) (-3 + b_1889X))) + i_1892X))))<<2));
            Scode_pointerS = ((Scode_pointerS) + 2);
            arg3K0 = (Scode_pointerS);
            goto L32913;}}}}
    else {
      goto L39585;}}
  else {
    goto L39585;}}
 L39723: {
  byte_1893X = arg0K0;
  port_1894X = arg0K1;
  if ((0 == (3 & byte_1893X))) {
    if ((3 == (3 & port_1894X))) {
      if ((7 == (31 & ((((*((long *) ((((char *) (-3 + port_1894X))) + -4))))>>2))))) {
        if ((0 == (8 & ((((*((long *) ((((char *) (-3 + port_1894X))) + 12))))>>2))))) {
          goto L39800;}
        else {
          if ((1 == (*((long *) ((((char *) (-3 + port_1894X))) + 32))))) {push_exception_setupB(13, 2);
            SstackS = ((SstackS) + -4);
            *((long *) (SstackS)) = (long) (byte_1893X);
            SstackS = ((SstackS) + -4);
            *((long *) (SstackS)) = (long) (port_1894X);
            arg0K0 = 2;
            goto L30610;}
          else {
            p_1895X = *((long *) ((((char *) (-3 + port_1894X))) + 28));
            b_1896X = *((long *) ((((char *) (-3 + port_1894X))) + 24));
            i_1897X = ((p_1895X)>>2);
            if ((i_1897X == ((long)(((unsigned long)(*((long *) ((((char *) (-3 + b_1896X))) + -4))))>>8)))) {push_exception_setupB(13, 2);
              SstackS = ((SstackS) + -4);
              *((long *) (SstackS)) = (long) (byte_1893X);
              SstackS = ((SstackS) + -4);
              *((long *) (SstackS)) = (long) (port_1894X);
              arg0K0 = 2;
              goto L30610;}
            else {
              val_1898X = 4 + (((i_1897X)<<2));
              addr_1899X = (((char *) (-3 + port_1894X))) + 28;S48_WRITE_BARRIER(port_1894X, addr_1899X, val_1898X);
              *((long *) addr_1899X) = (long) (val_1898X);
              *((unsigned char *) ((((char *) (-3 + b_1896X))) + i_1897X)) = (unsigned char) ((((byte_1893X)>>2)));
              SvalS = 13;
              Scode_pointerS = ((Scode_pointerS) + 2);
              arg3K0 = (Scode_pointerS);
              goto L32913;}}}}
      else {
        goto L39800;}}
    else {
      goto L39800;}}
  else {
    goto L39800;}}
 L39992: {
  port_1900X = arg0K0;
  if ((3 == (3 & port_1900X))) {
    if ((7 == (31 & ((((*((long *) ((((char *) (-3 + port_1900X))) + -4))))>>2))))) {
      if ((0 == (4 & ((((*((long *) ((((char *) (-3 + port_1900X))) + 12))))>>2))))) {
        goto L40165;}
      else {
        b_1901X = *((long *) ((((char *) (-3 + port_1900X))) + 24));
        if ((1 == b_1901X)) {push_exception_setupB(13, 2);
          SstackS = ((SstackS) + -4);
          *((long *) (SstackS)) = (long) (port_1900X);
          arg0K0 = 1;
          goto L30610;}
        else {
          arg0K0 = ((((*((long *) ((((char *) (-3 + port_1900X))) + 28))))>>2));
          goto L40021;}}}
    else {
      goto L40165;}}
  else {
    goto L40165;}}
 L40583: {
  port_1902X = arg0K0;
  if ((3 == (3 & port_1902X))) {
    if ((7 == (31 & ((((*((long *) ((((char *) (-3 + port_1902X))) + -4))))>>2))))) {
      if ((0 == (4 & ((((*((long *) ((((char *) (-3 + port_1902X))) + 12))))>>2))))) {
        goto L40756;}
      else {
        b_1903X = *((long *) ((((char *) (-3 + port_1902X))) + 24));
        if ((1 == b_1903X)) {push_exception_setupB(13, 2);
          SstackS = ((SstackS) + -4);
          *((long *) (SstackS)) = (long) (port_1902X);
          arg0K0 = 1;
          goto L30610;}
        else {
          arg0K0 = ((((*((long *) ((((char *) (-3 + port_1902X))) + 28))))>>2));
          goto L40612;}}}
    else {
      goto L40756;}}
  else {
    goto L40756;}}
 L41094: {
  Kchar_1904X = arg0K0;
  port_1905X = arg0K1;
  if ((9 == (255 & Kchar_1904X))) {
    if ((3 == (3 & port_1905X))) {
      if ((7 == (31 & ((((*((long *) ((((char *) (-3 + port_1905X))) + -4))))>>2))))) {
        if ((0 == (8 & ((((*((long *) ((((char *) (-3 + port_1905X))) + 12))))>>2))))) {
          goto L41313;}
        else {
          if ((1 == (*((long *) ((((char *) (-3 + port_1905X))) + 32))))) {push_exception_setupB(13, 2);
            SstackS = ((SstackS) + -4);
            *((long *) (SstackS)) = (long) (Kchar_1904X);
            SstackS = ((SstackS) + -4);
            *((long *) (SstackS)) = (long) (port_1905X);
            arg0K0 = 2;
            goto L30610;}
          else {
            codec_1906X = *((long *) ((((char *) (-3 + port_1905X))) + 4));
            if ((0 == (3 & codec_1906X))) {
              b_1907X = *((long *) ((((char *) (-3 + port_1905X))) + 24));
              i_1908X = (((*((long *) ((((char *) (-3 + port_1905X))) + 28))))>>2);
              l_1909X = (long)(((unsigned long)(*((long *) ((((char *) (-3 + b_1907X))) + -4))))>>8);
              if ((i_1908X == l_1909X)) {push_exception_setupB(13, 2);
                SstackS = ((SstackS) + -4);
                *((long *) (SstackS)) = (long) (Kchar_1904X);
                SstackS = ((SstackS) + -4);
                *((long *) (SstackS)) = (long) (port_1905X);
                arg0K0 = 2;
                goto L30610;}
              else {
                x_1910X = *((long *) ((((char *) (-3 + port_1905X))) + 8));
                if ((1 == x_1910X)) {
                  goto L41259;}
                else {
                  if ((10 == (((Kchar_1904X)>>8)))) {
                    codec_okP_1911X = encode_scalar_value((((codec_1906X)>>2)), 13, ((((char *) (-3 + b_1907X))) + i_1908X), (l_1909X - i_1908X), &encoding_okP_1912X, &out_of_spaceP_1913X, &count_1914X);
                    if (codec_okP_1911X) {
                      if (encoding_okP_1912X) {
                        if (out_of_spaceP_1913X) {push_exception_setupB(13, 2);
                          SstackS = ((SstackS) + -4);
                          *((long *) (SstackS)) = (long) (Kchar_1904X);
                          SstackS = ((SstackS) + -4);
                          *((long *) (SstackS)) = (long) (port_1905X);
                          arg0K0 = 2;
                          goto L30610;}
                        else {
                          i_1915X = i_1908X + count_1914X;
                          if ((i_1915X == l_1909X)) {push_exception_setupB(13, 2);
                            SstackS = ((SstackS) + -4);
                            *((long *) (SstackS)) = (long) (Kchar_1904X);
                            SstackS = ((SstackS) + -4);
                            *((long *) (SstackS)) = (long) (port_1905X);
                            arg0K0 = 2;
                            goto L30610;}
                          else {encode_scalar_value((((codec_1906X)>>2)), 10, ((((char *) (-3 + b_1907X))) + i_1915X), (l_1909X - i_1915X), &encoding_okP_1916X, &out_of_spaceP_1917X, &count_1918X);
                            if (encoding_okP_1916X) {
                              if (out_of_spaceP_1917X) {push_exception_setupB(13, 2);
                                SstackS = ((SstackS) + -4);
                                *((long *) (SstackS)) = (long) (Kchar_1904X);
                                SstackS = ((SstackS) + -4);
                                *((long *) (SstackS)) = (long) (port_1905X);
                                arg0K0 = 2;
                                goto L30610;}
                              else {
                                val_1919X = (((i_1915X + count_1918X))<<2);
                                addr_1920X = (((char *) (-3 + port_1905X))) + 28;S48_WRITE_BARRIER(port_1905X, addr_1920X, val_1919X);
                                *((long *) addr_1920X) = (long) (val_1919X);
                                SvalS = 13;
                                Scode_pointerS = ((Scode_pointerS) + 2);
                                arg3K0 = (Scode_pointerS);
                                goto L32913;}}
                            else {push_exception_setupB(13, 2);
                              SstackS = ((SstackS) + -4);
                              *((long *) (SstackS)) = (long) (Kchar_1904X);
                              SstackS = ((SstackS) + -4);
                              *((long *) (SstackS)) = (long) (port_1905X);
                              arg0K0 = 2;
                              goto L30610;}}}}
                      else {push_exception_setupB(13, 2);
                        SstackS = ((SstackS) + -4);
                        *((long *) (SstackS)) = (long) (Kchar_1904X);
                        SstackS = ((SstackS) + -4);
                        *((long *) (SstackS)) = (long) (port_1905X);
                        arg0K0 = 2;
                        goto L30610;}}
                    else {push_exception_setupB(5, 2);
                      SstackS = ((SstackS) + -4);
                      *((long *) (SstackS)) = (long) (Kchar_1904X);
                      SstackS = ((SstackS) + -4);
                      *((long *) (SstackS)) = (long) (port_1905X);
                      arg0K0 = 2;
                      goto L30610;}}
                  else {
                    goto L41259;}}}}
            else {push_exception_setupB(13, 2);
              SstackS = ((SstackS) + -4);
              *((long *) (SstackS)) = (long) (Kchar_1904X);
              SstackS = ((SstackS) + -4);
              *((long *) (SstackS)) = (long) (port_1905X);
              arg0K0 = 2;
              goto L30610;}}}}
      else {
        goto L41313;}}
    else {
      goto L41313;}}
  else {
    goto L41313;}}
 L52000: {
  stuff_1921X = arg0K0;
  if ((3 == (3 & stuff_1921X))) {
    if ((0 == (31 & ((((*((long *) ((((char *) (-3 + stuff_1921X))) + -4))))>>2))))) {
      thing_1922X = *((long *) (((char *) (-3 + stuff_1921X))));
      if ((0 == (3 & thing_1922X))) {
        ps_write_integer((((thing_1922X)>>2)), out_1547X);
        goto L52006;}
      else {
        if ((9 == (255 & thing_1922X))) {
          ps_write_string("#\\", out_1547X);
          { long ignoreXX;
          PS_WRITE_CHAR((((char) (((thing_1922X)>>8)))), out_1547X, ignoreXX) }
          goto L52006;}
        else {
          if ((3 == (3 & thing_1922X))) {
            if ((9 == (31 & ((((*((long *) ((((char *) (-3 + thing_1922X))) + -4))))>>2))))) {
              if ((0 < ((((3 + ((long)(((unsigned long)(*((long *) ((((char *) (-3 + thing_1922X))) + -4))))>>8))))>>2)))) {
                type_1923X = *((long *) (((char *) (-3 + thing_1922X))));
                if ((3 == (3 & type_1923X))) {
                  if ((9 == (31 & ((((*((long *) ((((char *) (-3 + type_1923X))) + -4))))>>2))))) {
                    if ((2 < ((((3 + ((long)(((unsigned long)(*((long *) ((((char *) (-3 + type_1923X))) + -4))))>>8))))>>2)))) {
                      obj_1924X = *((long *) ((((char *) (-3 + type_1923X))) + 8));
                      if ((3 == (3 & obj_1924X))) {
                        if ((1 == (31 & ((((*((long *) ((((char *) (-3 + obj_1924X))) + -4))))>>2))))) {
                          ps_write_string("#{", out_1547X);write_vm_string((*((long *) (((char *) (-3 + (*((long *) ((((char *) (-3 + (*((long *) (((char *) (-3 + thing_1922X)))))))) + 8)))))))), out_1547X);
                          { long ignoreXX;
                          PS_WRITE_CHAR(125, out_1547X, ignoreXX) }
                          goto L52006;}
                        else {
                          goto L23921;}}
                      else {
                        goto L23921;}}
                    else {
                      goto L23921;}}
                  else {
                    goto L23921;}}
                else {
                  goto L23921;}}
              else {
                goto L23921;}}
            else {
              goto L23921;}}
          else {
            goto L23921;}}}}
    else {
      goto L51991;}}
  else {
    goto L51991;}}
 L29642: {
  arg_count_1925X = arg0K0;
  if ((3 == (3 & handlers_1550X))) {
    if ((2 == (31 & ((((*((long *) ((((char *) (-3 + handlers_1550X))) + -4))))>>2))))) {
      goto L29656;}
    else {
      goto L29698;}}
  else {
    goto L29698;}}
 L16002: {
  x_1926X = Sfinalize_theseS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1926X);
  Sfinalize_theseS = 25;
  n_1927X = Senabled_interruptsS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((n_1927X)<<2)));
  if ((Sgc_in_troublePS)) {
    arg0K0 = 5;
    goto L16013;}
  else {
    arg0K0 = 1;
    goto L16013;}}
 L16019: {
  channel_1928X = arg0K0;
  x_1929X = 1 == (Spending_channels_headS);
  if (x_1929X) {
    goto L16033;}
  else {
    Spending_interruptsS = (16 | (Spending_interruptsS));
    if ((0 == ((Spending_interruptsS) & (Senabled_interruptsS)))) {
      s48_Sstack_limitS = (Sreal_stack_limitS);
      if ((s48_Spending_eventsPS)) {
        s48_Sstack_limitS = (((char *) -1));
        goto L16033;}
      else {
        goto L16033;}}
    else {
      s48_Sstack_limitS = (((char *) -1));
      goto L16033;}}}
 L16240: {
  sig_1930X = *(Sos_signal_ringS + (Sos_signal_ring_startS));
  if ((31 == (Sos_signal_ring_startS))) {
    arg0K0 = 0;
    goto L16244;}
  else {
    arg0K0 = (1 + (Sos_signal_ring_startS));
    goto L16244;}}
 L16091: {
  n_1931X = Senabled_interruptsS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((n_1931X)<<2)));
  arg0K0 = 2;
  goto L29642;}
 L12306: {
  count_1932X = arg0K0;
  i_1933X = arg0K1;
  offset_1934X = arg0K2;
  if ((0 == count_1932X)) {
    if ((i_1933X < total_count_1586X)) {
      arg0K0 = i_1933X;
      arg0K1 = offset_1934X;
      goto L10445;}
    else {
      arg0K0 = offset_1934X;
      goto L65515;}}
  else {
    value_1935X = *((long *) ((SstackS) + ((((*((unsigned char *) ((Scode_pointerS) + (1 + offset_1934X)))))<<2))));
    addr_1936X = (((char *) (-3 + new_env_1583X))) + (((i_1933X)<<2));S48_WRITE_BARRIER(new_env_1583X, addr_1936X, value_1935X);
    *((long *) addr_1936X) = (long) (value_1935X);
    arg0K0 = (-1 + count_1932X);
    arg0K1 = (1 + i_1933X);
    arg0K2 = (1 + offset_1934X);
    goto L12306;}}
 L15056: {
  count_1937X = arg0K0;
  i_1938X = arg0K1;
  offset_1939X = arg0K2;
  if ((0 == count_1937X)) {
    if ((i_1938X < total_count_1595X)) {
      arg0K0 = i_1938X;
      arg0K1 = offset_1939X;
      goto L11510;}
    else {
      arg0K0 = offset_1939X;
      goto L65506;}}
  else {
    value_1940X = *((long *) ((SstackS) + ((((((((*((unsigned char *) ((Scode_pointerS) + (1 + offset_1939X)))))<<8)) + (*((unsigned char *) ((Scode_pointerS) + (2 + offset_1939X))))))<<2))));
    addr_1941X = (((char *) (-3 + new_env_1592X))) + (((i_1938X)<<2));S48_WRITE_BARRIER(new_env_1592X, addr_1941X, value_1940X);
    *((long *) addr_1941X) = (long) (value_1940X);
    arg0K0 = (-1 + count_1937X);
    arg0K1 = (1 + i_1938X);
    arg0K2 = (2 + offset_1939X);
    goto L15056;}}
 L60222: {
  pending_interruptP_return_tag = 5;
  goto pending_interruptP;
 pending_interruptP_return_5:
  v_1942X = pending_interruptP0_return_value;
  if (v_1942X) {
    arg0K0 = 2;
    goto L29898;}
  else {
    goto L60229;}}
 L60229: {
  v_1943X = s48_call_native_procedure((SvalS), 2);
  arg0K0 = v_1943X;
  goto L60019;}
 L60364: {
  pop_continuationB_return_tag = 4;
  goto pop_continuationB;
 pop_continuationB_return_4:
  Scode_pointerS = ((Scode_pointerS) + 2);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L60149: {
  protocol_skip_1944X = arg0K0;
  SstackS = (ScontS);
  cont_1945X = ScontS;
  pointer_1946X = (((char *) (*((long *) cont_1945X)))) + -2;
  size_1947X = ((((*((unsigned char *) pointer_1946X)))<<8)) + (*((unsigned char *) (pointer_1946X + 1)));
  if ((65535 == size_1947X)) {
    arg0K0 = ((((*((long *) (cont_1945X + 4))))>>2));
    goto L60160;}
  else {
    arg0K0 = size_1947X;
    goto L60160;}}
 L30956: {
  cont_1948X = arg0K0;
  if ((1 == cont_1948X)) {
    if ((0 == (3 & (SvalS)))) {
      s48_Scallback_return_stack_blockS = 1;
      arg0K0 = ((((SvalS))>>2));
      goto L65498;}
    else {
      goto L30971;}}
  else {
    goto L30971;}}
 L60508: {
  v_1949X = arg0K0;
  ScontS = (cont_1641X + (4 + (((v_1949X)<<2))));
  merged_arg0K0 = 0;
  move_args_above_contB_return_tag = 7;
  goto move_args_above_contB;
 move_args_above_contB_return_7:
  goto L60413;}
 L60413: {
  x_1950X = SvalS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1950X);
  SvalS = proc_1640X;
  arg0K0 = 1;
  arg0K1 = 25;
  arg0K2 = 0;
  goto L59760;}
 L30127: {
  v_1951X = arg0K0;
  SvalS = v_1951X;
  pop_continuationB_return_tag = 5;
  goto pop_continuationB;
 pop_continuationB_return_5:
  arg0K0 = 1;
  goto L33337;}
 L31039: {
  stack_nargs_1952X = arg0K0;
  list_args_1953X = arg0K1;
  merged_arg0K0 = list_args_1953X;
  merged_arg0K1 = stack_nargs_1952X;
  pop_args_GlistSAgc_return_tag = 9;
  goto pop_args_GlistSAgc;
 pop_args_GlistSAgc_return_9:
  args_1954X = pop_args_GlistSAgc0_return_value;push_exception_setupB(4, 0);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (args_1954X);
  arg0K0 = 2;
  goto L30610;}
 L33337: {
  bytes_used_1955X = arg0K0;
  Scode_pointerS = ((Scode_pointerS) + (1 + bytes_used_1955X));
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L60693: {
  v_1956X = arg0K0;
  SvalS = v_1956X;
  arg0K0 = 2;
  goto L60149;}
 L30073: {
  if ((1 == (stack_nargs_1653X + list_arg_count_1655X))) {
    if ((1 == stack_nargs_1653X)) {
      v_1957X = *((long *) (SstackS));
      SstackS = ((SstackS) + 4);
      arg0K0 = v_1957X;
      goto L30151;}
    else {
      arg0K0 = (*((long *) (((char *) (-3 + list_args_1654X)))));
      goto L30151;}}
  else {
    arg0K0 = stack_nargs_1653X;
    arg0K1 = list_args_1654X;
    goto L31039;}}
 L30190: {
  v_1958X = arg0K0;
  ScontS = (cont_1664X + (4 + (((v_1958X)<<2))));
  merged_arg0K0 = stack_nargs_1653X;
  move_args_above_contB_return_tag = 8;
  goto move_args_above_contB;
 move_args_above_contB_return_8:
  arg0K0 = stack_nargs_1653X;
  arg0K1 = list_args_1654X;
  arg0K2 = list_arg_count_1655X;
  goto L59760;}
 L34387: {
  loc_1959X = arg3K0;
  arg_1960X = arg3K1;
  if ((arg_1960X < arg_top_1669X)) {
    SstackS = ((SstackS) + (0 - (((stack_nargs_1653X)<<2))));
    if ((count_1667X < stack_nargs_1653X)) {
      merged_arg0K0 = list_args_1654X;
      merged_arg0K1 = (stack_nargs_1653X - count_1667X);
      pop_args_GlistSAgc_return_tag = 10;
      goto pop_args_GlistSAgc;
     pop_args_GlistSAgc_return_10:
      v_1961X = pop_args_GlistSAgc0_return_value;
      arg0K0 = v_1961X;
      goto L34366;}
    else {
      arg0K0 = stack_nargs_1653X;
      arg0K1 = list_args_1654X;
      goto L34348;}}
  else {
    *((long *) loc_1959X) = (long) ((*((long *) arg_1960X)));
    arg3K0 = (loc_1959X + -4);
    arg3K1 = (arg_1960X + -4);
    goto L34387;}}
 L34239: {
  count_1962X = arg0K0;
  bytes_used_1963X = arg0K1;
  stack_nargs_1964X = arg0K2;
  list_args_1965X = arg0K3;
  list_arg_count_1966X = arg0K4;
  if ((count_1962X == (stack_nargs_1964X + list_arg_count_1966X))) {
    arg_top_1967X = SstackS;
    pop_continuationB_return_tag = 6;
    goto pop_continuationB;
   pop_continuationB_return_6:
    arg3K0 = ((SstackS) + -4);
    arg3K1 = (arg_top_1967X + (-4 + (((stack_nargs_1964X)<<2))));
    goto L34271;}
  else {
    merged_arg0K0 = list_args_1965X;
    merged_arg0K1 = stack_nargs_1964X;
    pop_args_GlistSAgc_return_tag = 11;
    goto pop_args_GlistSAgc;
   pop_args_GlistSAgc_return_11:
    args_1968X = pop_args_GlistSAgc0_return_value;push_exception_setupB(4, 0);
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) (1);
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) (args_1968X);
    arg0K0 = 2;
    goto L30610;}}
 L34561: {
push_exception_setupB(5, 8);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (template_1084X);
  arg0K0 = 1;
  goto L30610;}
 L19490: {
  if ((3 == (3 & x_1105X))) {
    if ((18 == (31 & ((((*((long *) ((((char *) (-3 + x_1105X))) + -4))))>>2))))) {
      arg0K0 = 5;
      goto L61886;}
    else {
      goto L19496;}}
  else {
    goto L19496;}}
 L51231: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (n_1106X);
  arg0K0 = 1;
  goto L30610;}
 L51226: {
  if ((3 == (3 & n_1106X))) {
    if ((18 == (31 & ((((*((long *) ((((char *) (-3 + n_1106X))) + -4))))>>2))))) {
      goto L51231;}
    else {
      goto L51232;}}
  else {
    goto L51232;}}
 L51384: {
  SvalS = 5;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L51367: {
  if ((3 == (3 & n_1677X))) {
    if ((8 == (31 & ((((*((long *) ((((char *) (-3 + n_1677X))) + -4))))>>2))))) {
      goto L51384;}
    else {
      goto L51375;}}
  else {
    goto L51375;}}
 L43855: {
  val_1969X = integer_add(arg2_1110X, y_1111X);
  SvalS = val_1969X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L43872: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1110X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (y_1111X);
  arg0K0 = 2;
  goto L30610;}
 L12553: {
  b_1970X = arg0K0;
  lo_a_1971X = 65535 & a_1687X;
  lo_b_1972X = 65535 & b_1970X;
  hi_a_1973X = 65535 & (((a_1687X)>>16));
  hi_b_1974X = 65535 & (((b_1970X)>>16));
  lo_c_1975X = SMALL_MULTIPLY(lo_a_1971X, lo_b_1972X);
  v_1976X = SMALL_MULTIPLY(lo_a_1971X, hi_b_1974X);
  v_1977X = SMALL_MULTIPLY(lo_b_1972X, hi_a_1973X);
  mid_c_1978X = v_1976X + v_1977X;
  c_1979X = lo_c_1975X + (((mid_c_1978X)<<16));
  if ((0 < hi_a_1973X)) {
    if ((0 < hi_b_1974X)) {
      val_1980X = integer_multiply(arg2_1113X, y_1114X);
      SvalS = val_1980X;
      Scode_pointerS = ((Scode_pointerS) + 1);
      arg3K0 = (Scode_pointerS);
      goto L32913;}
    else {
      goto L12595;}}
  else {
    goto L12595;}}
 L53130: {
  val_1981X = integer_multiply(arg2_1113X, y_1114X);
  SvalS = val_1981X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L53147: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1113X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (y_1114X);
  arg0K0 = 2;
  goto L30610;}
 L44144: {
  val_1982X = integer_subtract(arg2_1117X, y_1118X);
  SvalS = val_1982X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L44161: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1117X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (y_1118X);
  arg0K0 = 2;
  goto L30610;}
 L12811: {
  b_1983X = arg0K0;
  c_1984X = a_1703X / b_1983X;
  x_1985X = 0 == (a_1703X % b_1983X);
  if (x_1985X) {
    if ((a_1122X < 0)) {
      if ((b_1123X < 0)) {s48_make_availableAgc(16);
        if ((536870911 < c_1984X)) {
          goto L63643;}
        else {
          if ((c_1984X < -536870912)) {
            goto L63643;}
          else {
            arg0K0 = (((c_1984X)<<2));
            goto L63638;}}}
      else {
        goto L12857;}}
    else {
      if ((b_1123X < 0)) {
        goto L12857;}
      else {s48_make_availableAgc(16);
        if ((536870911 < c_1984X)) {
          goto L63665;}
        else {
          if ((c_1984X < -536870912)) {
            goto L63665;}
          else {
            arg0K0 = (((c_1984X)<<2));
            goto L63660;}}}}}
  else {push_exception_setupB(5, 1);
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) (arg2_1120X);
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) (y_1121X);
    arg0K0 = 2;
    goto L30610;}}
 L53383: {
  if ((0 == (3 & arg2_1120X))) {
    arg0K0 = 1;
    arg0K1 = 3;
    goto L21197;}
  else {
    arg0K0 = (-1 + ((((3 + ((long)(((unsigned long)(*((long *) ((((char *) (-3 + arg2_1120X))) + -4))))>>8))))>>2)));
    arg0K1 = 0;
    goto L21197;}}
 L53428: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1120X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (y_1121X);
  arg0K0 = 2;
  goto L30610;}
 L44429: {
  b_1986X = integerE(arg2_1124X, y_1125X);
  if (b_1986X) {
    arg0K0 = 5;
    goto L44433;}
  else {
    arg0K0 = 1;
    goto L44433;}}
 L44449: {
  val_1987X = arg0K0;
  SvalS = val_1987X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L44450: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1124X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (y_1125X);
  arg0K0 = 2;
  goto L30610;}
 L44689: {
  if ((0 == (3 & arg2_1126X))) {
    if ((0 == (3 & y_1127X))) {
      if ((arg2_1126X < y_1127X)) {
        arg0K0 = 5;
        goto L44693;}
      else {
        arg0K0 = 1;
        goto L44693;}}
    else {
      v_1988X = s48_bignum_test((((char *) (-3 + y_1127X))));
      if ((1 == v_1988X)) {
        arg0K0 = 5;
        goto L44693;}
      else {
        arg0K0 = 1;
        goto L44693;}}}
  else {
    if ((0 == (3 & y_1127X))) {
      v_1989X = s48_bignum_test((((char *) (-3 + arg2_1126X))));
      if ((1 == v_1989X)) {
        arg0K0 = 1;
        goto L44693;}
      else {
        arg0K0 = 5;
        goto L44693;}}
    else {
      v_1990X = s48_bignum_compare((((char *) (-3 + arg2_1126X))), (((char *) (-3 + y_1127X))));
      if ((-1 == v_1990X)) {
        arg0K0 = 5;
        goto L44693;}
      else {
        arg0K0 = 1;
        goto L44693;}}}}
 L44709: {
  val_1991X = arg0K0;
  SvalS = val_1991X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L44710: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1126X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (y_1127X);
  arg0K0 = 2;
  goto L30610;}
 L45012: {
  if ((0 == (3 & y_1129X))) {
    if ((0 == (3 & arg2_1128X))) {
      if ((y_1129X < arg2_1128X)) {
        arg0K0 = 5;
        goto L45016;}
      else {
        arg0K0 = 1;
        goto L45016;}}
    else {
      v_1992X = s48_bignum_test((((char *) (-3 + arg2_1128X))));
      if ((1 == v_1992X)) {
        arg0K0 = 5;
        goto L45016;}
      else {
        arg0K0 = 1;
        goto L45016;}}}
  else {
    if ((0 == (3 & arg2_1128X))) {
      v_1993X = s48_bignum_test((((char *) (-3 + y_1129X))));
      if ((1 == v_1993X)) {
        arg0K0 = 1;
        goto L45016;}
      else {
        arg0K0 = 5;
        goto L45016;}}
    else {
      v_1994X = s48_bignum_compare((((char *) (-3 + y_1129X))), (((char *) (-3 + arg2_1128X))));
      if ((-1 == v_1994X)) {
        arg0K0 = 5;
        goto L45016;}
      else {
        arg0K0 = 1;
        goto L45016;}}}}
 L45032: {
  val_1995X = arg0K0;
  SvalS = val_1995X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L45033: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1128X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (y_1129X);
  arg0K0 = 2;
  goto L30610;}
 L45335: {
  b_1996X = integerLE(arg2_1130X, y_1131X);
  if (b_1996X) {
    arg0K0 = 5;
    goto L45339;}
  else {
    arg0K0 = 1;
    goto L45339;}}
 L45355: {
  val_1997X = arg0K0;
  SvalS = val_1997X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L45356: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1130X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (y_1131X);
  arg0K0 = 2;
  goto L30610;}
 L45629: {
  b_1998X = integerGE(arg2_1132X, y_1133X);
  if (b_1998X) {
    arg0K0 = 5;
    goto L45633;}
  else {
    arg0K0 = 1;
    goto L45633;}}
 L45649: {
  val_1999X = arg0K0;
  SvalS = val_1999X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L45650: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1132X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (y_1133X);
  arg0K0 = 2;
  goto L30610;}
 L13425: {
  b_2000X = arg0K0;
  c_2001X = a_1718X / b_2000X;
  if ((a_1137X < 0)) {
    if ((b_1138X < 0)) {
      goto L13471;}
    else {
      goto L13470;}}
  else {
    if ((b_1138X < 0)) {
      goto L13470;}
    else {
      goto L13471;}}}
 L45929: {
  val_2002X = Hinteger_op8281(arg2_1134X, y_1135X);
  SvalS = val_2002X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L46139: {
  b_2003X = arg0K0;
  c_2004X = a_1719X % b_2003X;
  if ((a_1142X < 0)) {
    arg0K0 = (0 - c_2004X);
    goto L46143;}
  else {
    arg0K0 = c_2004X;
    goto L46143;}}
 L46105: {
  val_2005X = Hinteger_op8212(arg2_1139X, y_1140X);
  SvalS = val_2005X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L54733: {
  SvalS = 0;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L54727: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_1721X);
  arg0K0 = 1;
  goto L30610;}
 L53714: {
  x_2006X = arg0K0;s48_make_availableAgc(16);
  if ((536870911 < x_2006X)) {
    goto L53740;}
  else {
    if ((x_2006X < -536870912)) {
      goto L53740;}
    else {
      arg0K0 = (((x_2006X)<<2));
      goto L53735;}}}
 L24799: {
  length_2007X = arg0K0;
  extra_2008X = arg0K1;
  Stemp0S = x_1724X;s48_make_availableAgc(((((length_2007X + extra_2008X))<<2)));
  value_2009X = Stemp0S;
  Stemp0S = 1;
  if ((0 == (3 & value_2009X))) {
    v_2010X = (char *) s48_long_to_bignum((((value_2009X)>>2)));
    arg3K0 = v_2010X;
    goto L24791;}
  else {
    arg3K0 = (((char *) (-3 + value_2009X)));
    goto L24791;}}
 L46754: {
  x_2011X = arg0K0;
  count_2012X = arg0K1;
  if ((0 == x_2011X)) {
    SvalS = (((count_2012X)<<2));
    Scode_pointerS = ((Scode_pointerS) + 1);
    arg3K0 = (Scode_pointerS);
    goto L32913;}
  else {
    arg0K0 = (((x_2011X)>>1));
    arg0K1 = (count_2012X + (1 & x_2011X));
    goto L46754;}}
 L46839: {
  val_2013X = integer_bitwise_and(arg2_1168X, y_1169X);
  SvalS = val_2013X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L47002: {
  val_2014X = integer_bitwise_ior(arg2_1170X, y_1171X);
  SvalS = val_2014X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L47165: {
  val_2015X = integer_bitwise_xor(arg2_1172X, y_1173X);
  SvalS = val_2015X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L53884: {
  v_2016X = (char *) s48_long_to_bignum(x_1735X);
  v_2017X = enter_bignum(v_2016X);
  arg0K0 = v_2017X;
  goto L53879;}
 L53879: {
  val_2018X = arg0K0;
  SvalS = val_2018X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L53906: {
  v_2019X = (char *) s48_long_to_bignum(result_1737X);
  v_2020X = enter_bignum(v_2019X);
  arg0K0 = v_2020X;
  goto L53901;}
 L53901: {
  val_2021X = arg0K0;
  SvalS = val_2021X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L53777: {
  x_2022X = arg0K0;
  y_2023X = arg0K1;
  y_2024X = ((y_2023X)>>2);
  merged_arg0K0 = x_2022X;
  merged_arg0K1 = y_2024X;
  shift_space_return_tag = 1;
  goto shift_space;
 shift_space_return_1:
  needed_2025X = shift_space0_return_value;
  Stemp0S = x_2022X;s48_make_availableAgc((((needed_2025X)<<2)));
  value_2026X = Stemp0S;
  Stemp0S = 1;
  if ((0 == (3 & value_2026X))) {
    v_2027X = (char *) s48_long_to_bignum((((value_2026X)>>2)));
    arg3K0 = v_2027X;
    goto L53851;}
  else {
    arg3K0 = (((char *) (-3 + value_2026X)));
    goto L53851;}}
 L53928: {
  v_2028X = (char *) s48_long_to_bignum(result_1737X);
  v_2029X = enter_bignum(v_2028X);
  arg0K0 = v_2029X;
  goto L53923;}
 L53923: {
  val_2030X = arg0K0;
  SvalS = val_2030X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L53959: {
  x_2031X = arg3K0;
  external_bignum_2032X = (char *) s48_bignum_arithmetic_shift(x_2031X, y_1739X);
  v_2033X = s48_bignum_fits_in_word_p(external_bignum_2032X, 30, 1);
  if (v_2033X) {
    n_2034X = s48_bignum_to_long(external_bignum_2032X);
    arg0K0 = (((n_2034X)<<2));
    goto L53785;}
  else {
    v_2035X = enter_bignum(external_bignum_2032X);
    arg0K0 = v_2035X;
    goto L53785;}}
 L53786: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg2_1174X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (y_1175X);
  arg0K0 = 2;
  goto L30610;}
 L36049: {
  i_2036X = arg0K0;
  rest_list_2037X = arg0K1;
  if ((25 == rest_list_2037X)) {
    SvalS = new_1203X;
    Scode_pointerS = ((Scode_pointerS) + 2);
    arg3K0 = (Scode_pointerS);
    goto L32913;}
  else {
    *((long *) ((((char *) (-3 + new_1203X))) + (((i_2036X)<<2)))) = (long) ((*((long *) (((char *) (-3 + rest_list_2037X))))));
    arg0K0 = (1 + i_2036X);
    arg0K1 = (*((long *) ((((char *) (-3 + rest_list_2037X))) + 4)));
    goto L36049;}}
 L36462: {
  i_2038X = arg0K0;
  if ((i_2038X < 0)) {
    SvalS = x_1756X;
    Scode_pointerS = ((Scode_pointerS) + 2);
    arg3K0 = (Scode_pointerS);
    goto L32913;}
  else {
    addr_2039X = (((char *) (-3 + x_1756X))) + (((i_2038X)<<2));S48_WRITE_BARRIER(x_1756X, addr_2039X, value_1757X);
    *((long *) addr_2039X) = (long) (value_1757X);
    arg0K0 = (-1 + i_2038X);
    goto L36462;}}
 L47478: {
  i_2040X = arg0K0;
  if ((i_2040X < 0)) {
    SvalS = vector_1761X;
    Scode_pointerS = ((Scode_pointerS) + 1);
    arg3K0 = (Scode_pointerS);
    goto L32913;}
  else {
    *((unsigned char *) ((((char *) (-3 + vector_1761X))) + i_2040X)) = (unsigned char) (init_1238X);
    arg0K0 = (-1 + i_2040X);
    goto L47478;}}
 L47663: {
  i_2041X = arg0K0;
  if ((i_2041X < 0)) {
    SvalS = vector_1765X;
    Scode_pointerS = ((Scode_pointerS) + 1);
    arg3K0 = (Scode_pointerS);
    goto L32913;}
  else {
    arg0K0 = 0;
    arg0K1 = 0;
    arg0K2 = init_1252X;
    goto L47750;}}
 L28193: {
  foo_2042X = arg0K0;
  if ((1 == foo_2042X)) {
    if ((3 == (3 & bucket_1778X))) {
      arg0K0 = (-4 & bucket_1778X);
      goto L28198;}
    else {
      arg0K0 = bucket_1778X;
      goto L28198;}}
  else {
    s2_2043X = *((long *) (((char *) (-3 + foo_2042X))));
    len_2044X = (long)(((unsigned long)(*((long *) ((((char *) (-3 + string_1276X))) + -4))))>>8);
    if ((len_2044X == ((long)(((unsigned long)(*((long *) ((((char *) (-3 + s2_2043X))) + -4))))>>8)))) {
      if (((!memcmp((void *)(((char *) (-3 + s2_2043X))), (void *)(((char *) (-3 + string_1276X))),len_2044X)))) {
        arg0K0 = foo_2042X;
        goto L43736;}
      else {
        goto L28213;}}
    else {
      goto L28213;}}}
 L52099: {
  SvalS = 13;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L47851: {
  index_2045X = arg0K0;
  temp_2046X = index_2045X < (Snumber_of_channelsS);
  if (temp_2046X) {
    goto L47966;}
  else {
    x_2047X = add_more_channels(index_2045X);
    if (x_2047X) {
      goto L47966;}
    else {
      arg0K0 = 1;
      arg0K1 = 9;
      goto L47855;}}}
 L47913: {
  v_2048X = ps_open_fd(filename_1786X, 1, &v_2049X);
  arg0K0 = v_2048X;
  arg0K1 = v_2049X;
  goto L47922;}
 L47922: {
  channel_2050X = arg0K0;
  status_2051X = arg0K1;
  if ((status_2051X == NO_ERRORS)) {
    arg0K0 = channel_2050X;
    goto L47851;}
  else {push_exception_setupB(24, 1);
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) (arg4_1289X);
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) ((((mode_1290X)<<2)));
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) ((((status_2051X)<<2)));
    arg0K0 = 3;
    goto L30610;}}
 L55604: {
  waitP_2052X = arg4K0;
  start_2053X = ((arg3_1298X)>>2);
  count_2054X = ((arg2_1297X)>>2);
  v_2055X = 4 == (*((long *) (((char *) (-3 + arg5_1300X)))));
  if (v_2055X) {
    if ((3 == (3 & arg4_1299X))) {
      if ((17 == (31 & ((((*((long *) ((((char *) (-3 + arg4_1299X))) + -4))))>>2))))) {
        if ((3 == (3 & arg4_1299X))) {
          if ((0 == (128 & (*((long *) ((((char *) (-3 + arg4_1299X))) + -4)))))) {
            if ((((long)(((unsigned long)(*((long *) ((((char *) (-3 + arg4_1299X))) + -4))))>>8)) < (start_2053X + count_2054X))) {
              goto L48376;}
            else {
              got_2056X = ps_read_fd(((((*((long *) ((((char *) (-3 + arg5_1300X))) + 8))))>>2)), ((((char *) (-3 + arg4_1299X))) + start_2053X), count_2054X, waitP_2052X, &eofP_2057X, &pendingP_2058X, &status_2059X);
              if ((status_2059X == NO_ERRORS)) {
                if (eofP_2057X) {
                  if (pendingP_2058X) {
                    addr_2060X = (((char *) (-3 + arg5_1300X))) + 20;S48_WRITE_BARRIER(arg5_1300X, addr_2060X, 5);
                    *((long *) addr_2060X) = (long) (5);
                    arg0K0 = 21;
                    goto L48375;}
                  else {
                    arg0K0 = 21;
                    goto L48375;}}
                else {
                  if (pendingP_2058X) {
                    addr_2061X = (((char *) (-3 + arg5_1300X))) + 20;S48_WRITE_BARRIER(arg5_1300X, addr_2061X, 5);
                    *((long *) addr_2061X) = (long) (5);
                    arg0K0 = 1;
                    goto L48375;}
                  else {
                    arg0K0 = (((got_2056X)<<2));
                    goto L48375;}}}
              else {
                addr_2062X = s48_allocate_small(8);
                *((long *) addr_2062X) = (long) (1046);
                x_2063X = 3 + (((long) (addr_2062X + 4)));
                *((long *) (((char *) (-3 + x_2063X)))) = (long) ((((status_2059X)<<2)));
                arg0K0 = x_2063X;
                goto L48375;}}}
          else {
            goto L48376;}}
        else {
          goto L48376;}}
      else {
        goto L48376;}}
    else {
      goto L48376;}}
  else {
    goto L48376;}}
 L15802: {
  arg0K0 = (*((long *) ((((char *) (-3 + channel_1324X))) + 20)));
  goto L55956;}
 L15832: {
  val_2064X = *((long *) ((((char *) (-3 + ch_1798X))) + 16));
  addr_2065X = (((char *) (-3 + prev_1799X))) + 16;S48_WRITE_BARRIER(prev_1799X, addr_2065X, val_2064X);
  *((long *) addr_2065X) = (long) (val_2064X);
  addr_2066X = (((char *) (-3 + ch_1798X))) + 16;S48_WRITE_BARRIER(ch_1798X, addr_2066X, 1);
  *((long *) addr_2066X) = (long) (1);
  arg0K0 = (*((long *) ((((char *) (-3 + ch_1798X))) + 20)));
  goto L55956;}
 L22613: {
  v_2067X = arg0K0;
  arg0K0 = (-1 + i_1804X);
  arg0K1 = v_2067X;
  goto L22599;}
 L48935: {
  if ((1 == proposal_1334X)) {
    goto L48947;}
  else {
    addr_2068X = ((char *) (-3 + proposal_1334X));S48_WRITE_BARRIER(proposal_1334X, addr_2068X, 5);
    *((long *) addr_2068X) = (long) (5);
    goto L48947;}}
 L14460: {
  i_2069X = arg0K0;
  stob_2070X = *((long *) ((((char *) (-3 + log_1813X))) + (((i_2069X)<<2))));
  if ((1 == stob_2070X)) {
    copies_2071X = *((long *) ((((char *) (-3 + proposal_1335X))) + 12));
    arg0K0 = copies_2071X;
    goto L49298;}
  else {
    value_2072X = *((long *) ((((char *) (-3 + log_1813X))) + (8 + (((i_2069X)<<2)))));
    verify_2073X = *((long *) ((((char *) (-3 + log_1813X))) + (12 + (((i_2069X)<<2)))));
    if ((29 == verify_2073X)) {
      if ((3 == (3 & stob_2070X))) {
        if ((0 == (128 & (*((long *) ((((char *) (-3 + stob_2070X))) + -4)))))) {
          goto L14512;}
        else {
          goto L49198;}}
      else {
        goto L49198;}}
    else {
      if ((verify_2073X == ((((*((unsigned char *) ((((char *) (-3 + stob_2070X))) + ((((*((long *) ((((char *) (-3 + log_1813X))) + (4 + (((i_2069X)<<2)))))))>>2))))))<<2)))) {
        if ((verify_2073X == value_2072X)) {
          goto L14512;}
        else {
          if ((3 == (3 & stob_2070X))) {
            if ((0 == (128 & (*((long *) ((((char *) (-3 + stob_2070X))) + -4)))))) {
              goto L14512;}
            else {
              goto L49198;}}
          else {
            goto L49198;}}}
      else {
        goto L49198;}}}}
 L14274: {
  arg0K0 = (4 + i_1811X);
  goto L14222;}
 L49198: {
RELEASE_PROPOSAL_LOCK();
  x_2074X = Scurrent_threadS;
  addr_2075X = (((char *) (-3 + x_2074X))) + 12;S48_WRITE_BARRIER(x_2074X, addr_2075X, 1);
  *((long *) addr_2075X) = (long) (1);
  SvalS = 1;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L13937: {
  vector_2076X = arg0K0;
  if ((1 == vector_2076X)) {
    ps_error("Out of space, unable to allocate", 0);
    arg0K0 = vector_2076X;
    goto L13900;}
  else {
    arg0K0 = vector_2076X;
    goto L13900;}}
 L20664: {
  arg0K0 = (4 + i_1825X);
  goto L20642;}
 L20838: {
  arg0K0 = (4 + i_1829X);
  goto L20818;}
 L57299: {
  minutesP_2077X = arg4K0;
  pending_interruptP_return_tag = 6;
  goto pending_interruptP;
 pending_interruptP_return_6:
  x_2078X = pending_interruptP0_return_value;
  if (x_2078X) {
    goto L57329;}
  else {
    if ((0 == (Spending_interruptsS))) {s48_wait_for_event((((arg2_1426X)>>2)), minutesP_2077X);
      goto L57329;}
    else {
      goto L57329;}}}
 L38713: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (proc_1850X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (name_1849X);
  arg0K0 = 2;
  goto L30610;}
 L56211: {
  val_2079X = arg0K0;
  SvalS = val_2079X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L41952: {
  table_2080X = arg0K0;
  v_2081X = Haction4880(arg2_1435X);
  index_2082X = 1023 & v_2081X;
  link_2083X = *((long *) ((((char *) (-3 + table_2080X))) + (((index_2082X)<<2))));
  if ((0 == (3 & link_2083X))) {
    arg0K0 = (3 + (-4 & link_2083X));
    goto L27691;}
  else {
    arg0K0 = link_2083X;
    goto L27691;}}
 L49765: {
  l_2084X = arg0K0;
  i_2085X = arg0K1;
  if ((i_2085X < 0)) {
    SvalS = obj_1867X;
    Scode_pointerS = ((Scode_pointerS) + 1);
    arg3K0 = (Scode_pointerS);
    goto L32913;}
  else {
    d_2086X = *((long *) (((char *) (-3 + l_2084X))));
    arg0K0 = 0;
    arg0K1 = 0;
    arg0K2 = (((d_2086X)>>8));
    goto L49836;}}
 L31291: {
  x_2087X = arg0K0;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_2087X);
  arg0K0 = 2;
  arg0K1 = 25;
  arg0K2 = 0;
  goto L30038;}
 L31590: {
  x_2088X = arg0K0;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_2088X);
  arg0K0 = 2;
  arg0K1 = 25;
  arg0K2 = 0;
  goto L30038;}
 L39383: {
push_exception_setupB(5, 2);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (port_1881X);
  arg0K0 = 1;
  goto L30610;}
 L39585: {
push_exception_setupB(5, 2);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (port_1888X);
  arg0K0 = 1;
  goto L30610;}
 L39800: {
push_exception_setupB(5, 2);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (byte_1893X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (port_1894X);
  arg0K0 = 2;
  goto L30610;}
 L40165: {
push_exception_setupB(5, 2);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (port_1900X);
  arg0K0 = 1;
  goto L30610;}
 L40021: {
  i_2089X = arg0K0;
  p_2090X = *((long *) ((((char *) (-3 + port_1900X))) + 32));
  codec_2091X = *((long *) ((((char *) (-3 + port_1900X))) + 4));
  l_2092X = ((p_2090X)>>2);
  if ((i_2089X == l_2092X)) {
    val_2093X = ((i_2089X)<<2);
    addr_2094X = (((char *) (-3 + port_1900X))) + 28;S48_WRITE_BARRIER(port_1900X, addr_2094X, val_2093X);
    *((long *) addr_2094X) = (long) (val_2093X);push_exception_setupB(13, 2);
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) (port_1900X);
    arg0K0 = 1;
    goto L30610;}
  else {
    if ((0 == (3 & codec_2091X))) {
      encoding_okP_2095X = decode_scalar_value((((codec_2091X)>>2)), ((((char *) (-3 + b_1901X))) + i_2089X), (l_2092X - i_2089X), &okP_2096X, &incompleteP_2097X, &value_2098X, &count_2099X);
      if (encoding_okP_2095X) {
        if (okP_2096X) {
          if (incompleteP_2097X) {
            val_2100X = ((i_2089X)<<2);
            addr_2101X = (((char *) (-3 + port_1900X))) + 28;S48_WRITE_BARRIER(port_1900X, addr_2101X, val_2100X);
            *((long *) addr_2101X) = (long) (val_2100X);push_exception_setupB(13, 2);
            SstackS = ((SstackS) + -4);
            *((long *) (SstackS)) = (long) (port_1900X);
            arg0K0 = 1;
            goto L30610;}
          else {
            if ((1 == (*((long *) ((((char *) (-3 + port_1900X))) + 8))))) {
              goto L40075;}
            else {
              if ((13 == value_2098X)) {
                addr_2102X = (((char *) (-3 + port_1900X))) + 36;S48_WRITE_BARRIER(port_1900X, addr_2102X, 5);
                *((long *) addr_2102X) = (long) (5);
                val_2103X = (((i_2089X + count_2099X))<<2);
                addr_2104X = (((char *) (-3 + port_1900X))) + 28;S48_WRITE_BARRIER(port_1900X, addr_2104X, val_2103X);
                *((long *) addr_2104X) = (long) (val_2103X);
                SvalS = 2569;
                Scode_pointerS = ((Scode_pointerS) + 2);
                arg3K0 = (Scode_pointerS);
                goto L32913;}
              else {
                if ((10 == value_2098X)) {
                  if ((1 == (*((long *) ((((char *) (-3 + port_1900X))) + 36))))) {
                    goto L40075;}
                  else {
                    addr_2105X = (((char *) (-3 + port_1900X))) + 36;S48_WRITE_BARRIER(port_1900X, addr_2105X, 1);
                    *((long *) addr_2105X) = (long) (1);
                    arg0K0 = (i_2089X + count_2099X);
                    goto L40021;}}
                else {
                  goto L40075;}}}}}
        else {
          val_2106X = ((i_2089X)<<2);
          addr_2107X = (((char *) (-3 + port_1900X))) + 28;S48_WRITE_BARRIER(port_1900X, addr_2107X, val_2106X);
          *((long *) addr_2107X) = (long) (val_2106X);push_exception_setupB(13, 2);
          SstackS = ((SstackS) + -4);
          *((long *) (SstackS)) = (long) (port_1900X);
          arg0K0 = 1;
          goto L30610;}}
      else {push_exception_setupB(5, 2);
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (port_1900X);
        arg0K0 = 1;
        goto L30610;}}
    else {
      val_2108X = ((i_2089X)<<2);
      addr_2109X = (((char *) (-3 + port_1900X))) + 28;S48_WRITE_BARRIER(port_1900X, addr_2109X, val_2108X);
      *((long *) addr_2109X) = (long) (val_2108X);push_exception_setupB(13, 2);
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (port_1900X);
      arg0K0 = 1;
      goto L30610;}}}
 L40756: {
push_exception_setupB(5, 2);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (port_1902X);
  arg0K0 = 1;
  goto L30610;}
 L40612: {
  i_2110X = arg0K0;
  p_2111X = *((long *) ((((char *) (-3 + port_1902X))) + 32));
  codec_2112X = *((long *) ((((char *) (-3 + port_1902X))) + 4));
  l_2113X = ((p_2111X)>>2);
  if ((i_2110X == l_2113X)) {push_exception_setupB(13, 2);
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) (port_1902X);
    arg0K0 = 1;
    goto L30610;}
  else {
    if ((0 == (3 & codec_2112X))) {
      encoding_okP_2114X = decode_scalar_value((((codec_2112X)>>2)), ((((char *) (-3 + b_1903X))) + i_2110X), (l_2113X - i_2110X), &okP_2115X, &incompleteP_2116X, &value_2117X, &count_2118X);
      if (encoding_okP_2114X) {
        if (okP_2115X) {
          if (incompleteP_2116X) {push_exception_setupB(13, 2);
            SstackS = ((SstackS) + -4);
            *((long *) (SstackS)) = (long) (port_1902X);
            arg0K0 = 1;
            goto L30610;}
          else {
            if ((1 == (*((long *) ((((char *) (-3 + port_1902X))) + 8))))) {
              SvalS = (9 + (((value_2117X)<<8)));
              Scode_pointerS = ((Scode_pointerS) + 2);
              arg3K0 = (Scode_pointerS);
              goto L32913;}
            else {
              if ((13 == value_2117X)) {
                SvalS = 2569;
                Scode_pointerS = ((Scode_pointerS) + 2);
                arg3K0 = (Scode_pointerS);
                goto L32913;}
              else {
                if ((10 == value_2117X)) {
                  if ((1 == (*((long *) ((((char *) (-3 + port_1902X))) + 36))))) {
                    SvalS = (9 + (((value_2117X)<<8)));
                    Scode_pointerS = ((Scode_pointerS) + 2);
                    arg3K0 = (Scode_pointerS);
                    goto L32913;}
                  else {
                    arg0K0 = (i_2110X + count_2118X);
                    goto L40612;}}
                else {
                  SvalS = (9 + (((value_2117X)<<8)));
                  Scode_pointerS = ((Scode_pointerS) + 2);
                  arg3K0 = (Scode_pointerS);
                  goto L32913;}}}}}
        else {push_exception_setupB(13, 2);
          SstackS = ((SstackS) + -4);
          *((long *) (SstackS)) = (long) (port_1902X);
          arg0K0 = 1;
          goto L30610;}}
      else {push_exception_setupB(5, 2);
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (port_1902X);
        arg0K0 = 1;
        goto L30610;}}
    else {push_exception_setupB(13, 2);
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (port_1902X);
      arg0K0 = 1;
      goto L30610;}}}
 L41313: {
push_exception_setupB(5, 2);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (Kchar_1904X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (port_1905X);
  arg0K0 = 2;
  goto L30610;}
 L41259: {
  codec_okP_2119X = encode_scalar_value((((codec_1906X)>>2)), (((Kchar_1904X)>>8)), ((((char *) (-3 + b_1907X))) + i_1908X), (l_1909X - i_1908X), &encoding_okP_2120X, &out_of_spaceP_2121X, &count_2122X);
  if (codec_okP_2119X) {
    if (encoding_okP_2120X) {
      if (out_of_spaceP_2121X) {push_exception_setupB(13, 2);
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (Kchar_1904X);
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (port_1905X);
        arg0K0 = 2;
        goto L30610;}
      else {
        val_2123X = (((i_1908X + count_2122X))<<2);
        addr_2124X = (((char *) (-3 + port_1905X))) + 28;S48_WRITE_BARRIER(port_1905X, addr_2124X, val_2123X);
        *((long *) addr_2124X) = (long) (val_2123X);
        SvalS = 13;
        Scode_pointerS = ((Scode_pointerS) + 2);
        arg3K0 = (Scode_pointerS);
        goto L32913;}}
    else {push_exception_setupB(13, 2);
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (Kchar_1904X);
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (port_1905X);
      arg0K0 = 2;
      goto L30610;}}
  else {push_exception_setupB(5, 2);
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) (Kchar_1904X);
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) (port_1905X);
    arg0K0 = 2;
    goto L30610;}}
 L52006: {
  arg0K0 = (*((long *) ((((char *) (-3 + stuff_1921X))) + 4)));
  goto L52000;}
 L23921: {
  if ((3 == (3 & thing_1922X))) {
    if ((16 == (31 & ((((*((long *) ((((char *) (-3 + thing_1922X))) + -4))))>>2))))) {write_vm_string(thing_1922X, out_1547X);
      goto L52006;}
    else {
      goto L23925;}}
  else {
    goto L23925;}}
 L51991: {
  { long ignoreXX;
  PS_WRITE_CHAR(10, out_1547X, ignoreXX) }
  SvalS = 13;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L29656: {
  SvalS = (*((long *) ((((char *) (-3 + handlers_1550X))) + (((i_1548X)<<2)))));
  obj_2125X = SvalS;
  if ((3 == (3 & obj_2125X))) {
    if ((3 == (31 & ((((*((long *) ((((char *) (-3 + obj_2125X))) + -4))))>>2))))) {
      goto L29673;}
    else {
      goto L29712;}}
  else {
    goto L29712;}}
 L29698: {
  ps_error("interrupt handler is not a vector", 0);
  goto L29656;}
 L16013: {
  x_2126X = arg0K0;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_2126X);
  arg0K0 = 3;
  goto L29642;}
 L16033: {
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (channel_1928X);
  x_2127X = *((long *) ((((char *) (-3 + channel_1928X))) + 24));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_2127X);
  x_2128X = *((long *) ((((char *) (-3 + channel_1928X))) + 20));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_2128X);
  n_2129X = Senabled_interruptsS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((n_2129X)<<2)));
  arg0K0 = 4;
  goto L29642;}
 L16244: {
  v_2130X = arg0K0;
  Sos_signal_ring_startS = v_2130X;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((sig_1930X)<<2)));
  if (((Sos_signal_ring_readyS) == (Sos_signal_ring_startS))) {
    goto L16065;}
  else {
    Spending_interruptsS = (32 | (Spending_interruptsS));
    if ((0 == ((Spending_interruptsS) & (Senabled_interruptsS)))) {
      s48_Sstack_limitS = (Sreal_stack_limitS);
      if ((s48_Spending_eventsPS)) {
        s48_Sstack_limitS = (((char *) -1));
        goto L16065;}
      else {
        goto L16065;}}
    else {
      s48_Sstack_limitS = (((char *) -1));
      goto L16065;}}}
 L10445: {
  i_2131X = arg0K0;
  offset_2132X = arg0K1;
  if ((i_2131X == total_count_1586X)) {
    arg0K0 = offset_2132X;
    goto L65515;}
  else {
    env_2133X = *((long *) ((SstackS) + ((((*((unsigned char *) ((Scode_pointerS) + (1 + offset_2132X)))))<<2))));
    count_2134X = *((unsigned char *) ((Scode_pointerS) + (2 + offset_2132X)));
    arg0K0 = count_2134X;
    arg0K1 = i_2131X;
    arg0K2 = (2 + offset_2132X);
    goto L10462;}}
 L65515: {
  bytes_used_2135X = arg0K0;
  SvalS = new_env_1030X;
  Scode_pointerS = ((Scode_pointerS) + (1 + bytes_used_2135X));
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L11510: {
  i_2136X = arg0K0;
  offset_2137X = arg0K1;
  if ((i_2136X == total_count_1595X)) {
    arg0K0 = offset_2137X;
    goto L65506;}
  else {
    env_2138X = *((long *) ((SstackS) + ((((((((*((unsigned char *) ((Scode_pointerS) + (1 + offset_2137X)))))<<8)) + (*((unsigned char *) ((Scode_pointerS) + (2 + offset_2137X))))))<<2))));
    index_2139X = 2 + offset_2137X;
    count_2140X = ((((*((unsigned char *) ((Scode_pointerS) + (1 + index_2139X)))))<<8)) + (*((unsigned char *) ((Scode_pointerS) + (2 + index_2139X))));
    arg0K0 = count_2140X;
    arg0K1 = i_2136X;
    arg0K2 = (4 + offset_2137X);
    goto L11527;}}
 L65506: {
  bytes_used_2141X = arg0K0;
  SvalS = new_env_1036X;
  Scode_pointerS = ((Scode_pointerS) + (1 + bytes_used_2141X));
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L60160: {
  v_2142X = arg0K0;
  ScontS = (cont_1945X + (4 + (((v_2142X)<<2))));
  v_2143X = *((long *) (SstackS));
  SstackS = ((SstackS) + 4);
  v_2144X = s48_invoke_native_continuation((((long) (((char *) v_2143X)))), protocol_skip_1944X);
  arg0K0 = v_2144X;
  goto L60019;}
 L30971: {
  SstackS = (Sbottom_of_stackS);
  Sheap_continuationS = 1;
  ScontS = (Sbottom_of_stackS);push_exception_setupB(5, 0);
  x_2145X = SvalS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_2145X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (cont_1948X);
  arg0K0 = 2;
  goto L30610;}
 L30151: {
  v_2146X = arg0K0;
  SvalS = v_2146X;
  arg0K0 = cont_1662X;
  goto L30956;}
 L34366: {
  x_2147X = arg0K0;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_2147X);
  Scode_pointerS = ((Scode_pointerS) + 4);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L34348: {
  stack_nargs_2148X = arg0K0;
  l_2149X = arg0K1;
  if ((count_1667X == stack_nargs_2148X)) {
    arg0K0 = l_2149X;
    goto L34366;}
  else {
    x_2150X = *((long *) (((char *) (-3 + l_2149X))));
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) (x_2150X);
    arg0K0 = (1 + stack_nargs_2148X);
    arg0K1 = (*((long *) ((((char *) (-3 + l_2149X))) + 4)));
    goto L34348;}}
 L34271: {
  loc_2151X = arg3K0;
  arg_2152X = arg3K1;
  if ((arg_2152X < arg_top_1967X)) {
    SstackS = ((SstackS) + (0 - (((stack_nargs_1964X)<<2))));
    if ((0 == list_arg_count_1966X)) {
      goto L34258;}
    else {
      merged_arg0K0 = list_args_1965X;
      merged_arg0K1 = list_arg_count_1966X;
      push_list_return_tag = 3;
      goto push_list;
     push_list_return_3:
      goto L34258;}}
  else {
    *((long *) loc_2151X) = (long) ((*((long *) arg_2152X)));
    arg3K0 = (loc_2151X + -4);
    arg3K1 = (arg_2152X + -4);
    goto L34271;}}
 L19496: {
  if ((3 == (3 & x_1105X))) {
    if ((11 == (31 & ((((*((long *) ((((char *) (-3 + x_1105X))) + -4))))>>2))))) {
      arg0K0 = 5;
      goto L61886;}
    else {
      arg0K0 = 1;
      goto L61886;}}
  else {
    arg0K0 = 1;
    goto L61886;}}
 L51232: {
  SvalS = 1;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L51375: {
  if ((3 == (3 & n_1677X))) {
    if ((18 == (31 & ((((*((long *) ((((char *) (-3 + n_1677X))) + -4))))>>2))))) {
      goto L51384;}
    else {
      goto L51385;}}
  else {
    goto L51385;}}
 L12595: {
  if ((536870911 < lo_c_1975X)) {
    val_2153X = integer_multiply(arg2_1113X, y_1114X);
    SvalS = val_2153X;
    Scode_pointerS = ((Scode_pointerS) + 1);
    arg3K0 = (Scode_pointerS);
    goto L32913;}
  else {
    if ((lo_c_1975X < 0)) {
      val_2154X = integer_multiply(arg2_1113X, y_1114X);
      SvalS = val_2154X;
      Scode_pointerS = ((Scode_pointerS) + 1);
      arg3K0 = (Scode_pointerS);
      goto L32913;}
    else {
      if ((8192 < mid_c_1978X)) {
        val_2155X = integer_multiply(arg2_1113X, y_1114X);
        SvalS = val_2155X;
        Scode_pointerS = ((Scode_pointerS) + 1);
        arg3K0 = (Scode_pointerS);
        goto L32913;}
      else {
        if ((a_1115X < 0)) {
          if ((b_1116X < 0)) {s48_make_availableAgc(16);
            if ((536870911 < c_1979X)) {
              goto L63540;}
            else {
              if ((c_1979X < -536870912)) {
                goto L63540;}
              else {
                arg0K0 = (((c_1979X)<<2));
                goto L63535;}}}
          else {
            goto L12623;}}
        else {
          if ((b_1116X < 0)) {
            goto L12623;}
          else {s48_make_availableAgc(16);
            if ((536870911 < c_1979X)) {
              goto L63562;}
            else {
              if ((c_1979X < -536870912)) {
                goto L63562;}
              else {
                arg0K0 = (((c_1979X)<<2));
                goto L63557;}}}}}}}}
 L63643: {
  v_2156X = (char *) s48_long_to_bignum(c_1984X);
  v_2157X = enter_bignum(v_2156X);
  arg0K0 = v_2157X;
  goto L63638;}
 L63638: {
  val_2158X = arg0K0;
  SvalS = val_2158X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L12857: {
  x_2159X = 0 - c_1984X;s48_make_availableAgc(16);
  if ((536870911 < x_2159X)) {
    goto L63621;}
  else {
    if ((x_2159X < -536870912)) {
      goto L63621;}
    else {
      arg0K0 = (((x_2159X)<<2));
      goto L63616;}}}
 L63665: {
  v_2160X = (char *) s48_long_to_bignum(c_1984X);
  v_2161X = enter_bignum(v_2160X);
  arg0K0 = v_2161X;
  goto L63660;}
 L63660: {
  val_2162X = arg0K0;
  SvalS = val_2162X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L21197: {
  length0_2163X = arg0K0;
  extra0_2164X = arg0K1;
  if ((0 == (3 & y_1121X))) {
    arg0K0 = 3;
    goto L21205;}
  else {
    arg0K0 = 0;
    goto L21205;}}
 L44433: {
  val_2165X = arg0K0;
  SvalS = val_2165X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L44693: {
  val_2166X = arg0K0;
  SvalS = val_2166X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L45016: {
  val_2167X = arg0K0;
  SvalS = val_2167X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L45339: {
  val_2168X = arg0K0;
  SvalS = val_2168X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L45633: {
  val_2169X = arg0K0;
  SvalS = val_2169X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L13471: {
  if ((536870911 < c_2001X)) {
    val_2170X = Hinteger_op8281(arg2_1134X, y_1135X);
    SvalS = val_2170X;
    Scode_pointerS = ((Scode_pointerS) + 1);
    arg3K0 = (Scode_pointerS);
    goto L32913;}
  else {
    SvalS = (((c_2001X)<<2));
    Scode_pointerS = ((Scode_pointerS) + 1);
    arg3K0 = (Scode_pointerS);
    goto L32913;}}
 L13470: {
  SvalS = ((((0 - c_2001X))<<2));
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L46143: {
  n_2171X = arg0K0;
  SvalS = (((n_2171X)<<2));
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L53740: {
  v_2172X = (char *) s48_long_to_bignum(x_2006X);
  v_2173X = enter_bignum(v_2172X);
  arg0K0 = v_2173X;
  goto L53735;}
 L53735: {
  val_2174X = arg0K0;
  SvalS = val_2174X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L24791: {
  x_2175X = arg3K0;
  v_2176X = s48_bignum_test(x_2175X);
  if ((-1 == v_2176X)) {
    v_2177X = (char *) s48_bignum_negate(x_2175X);
    arg3K0 = v_2177X;
    goto L24793;}
  else {
    arg3K0 = x_2175X;
    goto L24793;}}
 L53851: {
  x_2178X = arg3K0;
  external_bignum_2179X = (char *) s48_bignum_arithmetic_shift(x_2178X, y_2024X);
  v_2180X = s48_bignum_fits_in_word_p(external_bignum_2179X, 30, 1);
  if (v_2180X) {
    n_2181X = s48_bignum_to_long(external_bignum_2179X);
    arg0K0 = (((n_2181X)<<2));
    goto L53779;}
  else {
    v_2182X = enter_bignum(external_bignum_2179X);
    arg0K0 = v_2182X;
    goto L53779;}}
 L53785: {
  val_2183X = arg0K0;
  SvalS = val_2183X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L47750: {
  bits_2184X = arg0K0;
  j_2185X = arg0K1;
  shifted_2186X = arg0K2;
  if ((j_2185X < 4)) {
    *((unsigned char *) ((((char *) (-3 + vector_1765X))) + ((((i_2041X)<<2)) + j_2185X))) = (unsigned char) ((255 & shifted_2186X));
    arg0K0 = (8 + bits_2184X);
    arg0K1 = (1 + j_2185X);
    arg0K2 = ((long)(((unsigned long)shifted_2186X)>>8));
    goto L47750;}
  else {
    arg0K0 = (-1 + i_2041X);
    goto L47663;}}
 L28198: {
  b_2187X = arg0K0;
  addr_2188X = s48_allocate_small(12);
  *((long *) addr_2188X) = (long) (2054);
  x_2189X = 3 + (((long) (addr_2188X + 4)));
  *((long *) (((char *) (-3 + x_2189X)))) = (long) (string_1276X);
  *((long *) ((((char *) (-3 + x_2189X))) + 4)) = (long) (b_2187X);
  if ((3 == (3 & x_2189X))) {
    arg0K0 = (-4 & x_2189X);
    goto L28204;}
  else {
    arg0K0 = x_2189X;
    goto L28204;}}
 L43736: {
  val_2190X = arg0K0;
  SvalS = val_2190X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L28213: {
  link_2191X = *((long *) ((((char *) (-3 + foo_2042X))) + 4));
  if ((0 == (3 & link_2191X))) {
    arg0K0 = (3 + (-4 & link_2191X));
    goto L28193;}
  else {
    arg0K0 = link_2191X;
    goto L28193;}}
 L47966: {
  if ((1 == (*((Svm_channelsS) + index_2045X)))) {
    channel_2192X = make_channel((((mode_1290X)<<2)), arg3_1288X, (((index_2045X)<<2)), close_silentlyP_1291X, 1, 1, 1, 0);
    *((Svm_channelsS) + index_2045X) = channel_2192X;
    arg0K0 = channel_2192X;
    arg0K1 = 9;
    goto L47855;}
  else {
    arg0K0 = 1;
    arg0K1 = 11;
    goto L47855;}}
 L47855: {
  channel_2193X = arg0K0;
  reason_2194X = arg0K1;
  if ((1 == channel_2193X)) {
    if ((3 == (3 & arg4_1289X))) {
      if ((17 == (31 & ((((*((long *) ((((char *) (-3 + arg4_1289X))) + -4))))>>2))))) {
        if ((1 == mode_1290X)) {
          goto L48000;}
        else {
          if ((3 == mode_1290X)) {
            goto L48000;}
          else {
            v_2195X = ps_close_fd(index_2045X);
            arg0K0 = v_2195X;
            goto L47995;}}}
      else {push_exception_setupB(reason_2194X, 1);
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) (arg4_1289X);
        SstackS = ((SstackS) + -4);
        *((long *) (SstackS)) = (long) ((((mode_1290X)<<2)));
        arg0K0 = 2;
        goto L30610;}}
    else {push_exception_setupB(reason_2194X, 1);
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (arg4_1289X);
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) ((((mode_1290X)<<2)));
      arg0K0 = 2;
      goto L30610;}}
  else {
    SvalS = channel_2193X;
    Scode_pointerS = ((Scode_pointerS) + 1);
    arg3K0 = (Scode_pointerS);
    goto L32913;}}
 L48376: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg5_1300X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (arg4_1299X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((start_2053X)<<2)));
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((count_2054X)<<2)));
  if (waitP_2052X) {
    arg0K0 = 5;
    goto L48392;}
  else {
    arg0K0 = 1;
    goto L48392;}}
 L48375: {
  val_2196X = arg0K0;
  SvalS = val_2196X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L48947: {
  x_2197X = Scurrent_threadS;
  addr_2198X = (((char *) (-3 + x_2197X))) + 12;S48_WRITE_BARRIER(x_2197X, addr_2198X, proposal_1334X);
  *((long *) addr_2198X) = (long) (proposal_1334X);
  SvalS = 13;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L49298: {
  copies_2199X = arg0K0;
  if ((1 == copies_2199X)) {
    log_2200X = *((long *) ((((char *) (-3 + proposal_1335X))) + 4));
    arg0K0 = 0;
    goto L13250;}
  else {
    thing_2201X = *((long *) ((((char *) (-3 + copies_2199X))) + 8));
    if ((3 == (3 & thing_2201X))) {
      if ((0 == (128 & (*((long *) ((((char *) (-3 + thing_2201X))) + -4)))))) {
        arg0K0 = (*((long *) ((((char *) (-3 + copies_2199X))) + 20)));
        goto L49298;}
      else {
        goto L49198;}}
    else {
      goto L49198;}}}
 L14512: {
  arg0K0 = (4 + i_2069X);
  goto L14460;}
 L13900: {
  entry_2202X = arg0K0;
  proposal_2203X = *((long *) ((((char *) (-3 + (Scurrent_threadS)))) + 12));
  value_2204X = Stemp0S;
  Stemp0S = 1;
  addr_2205X = ((char *) (-3 + entry_2202X));S48_WRITE_BARRIER(entry_2202X, addr_2205X, value_2204X);
  *((long *) addr_2205X) = (long) (value_2204X);
  addr_2206X = (((char *) (-3 + entry_2202X))) + 4;S48_WRITE_BARRIER(entry_2202X, addr_2206X, from_index_1819X);
  *((long *) addr_2206X) = (long) (from_index_1819X);
  value_2207X = Stemp1S;
  Stemp1S = 1;
  addr_2208X = (((char *) (-3 + entry_2202X))) + 8;S48_WRITE_BARRIER(entry_2202X, addr_2208X, value_2207X);
  *((long *) addr_2208X) = (long) (value_2207X);
  addr_2209X = (((char *) (-3 + entry_2202X))) + 12;S48_WRITE_BARRIER(entry_2202X, addr_2209X, to_index_1820X);
  *((long *) addr_2209X) = (long) (to_index_1820X);
  addr_2210X = (((char *) (-3 + entry_2202X))) + 16;S48_WRITE_BARRIER(entry_2202X, addr_2210X, count_1821X);
  *((long *) addr_2210X) = (long) (count_1821X);
  value_2211X = *((long *) ((((char *) (-3 + proposal_2203X))) + 12));
  addr_2212X = (((char *) (-3 + entry_2202X))) + 20;S48_WRITE_BARRIER(entry_2202X, addr_2212X, value_2211X);
  *((long *) addr_2212X) = (long) (value_2211X);
  addr_2213X = (((char *) (-3 + proposal_2203X))) + 12;S48_WRITE_BARRIER(proposal_2203X, addr_2213X, entry_2202X);
  *((long *) addr_2213X) = (long) (entry_2202X);
  SvalS = 13;
  Scode_pointerS = ((Scode_pointerS) + 2);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L57329: {
  SvalS = 13;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L27691: {
  bucket_2214X = arg0K0;
  arg0K0 = 1;
  arg0K1 = bucket_2214X;
  goto L27698;}
 L49836: {
  bits_2215X = arg0K0;
  j_2216X = arg0K1;
  shifted_2217X = arg0K2;
  if ((j_2216X < 4)) {
    *((unsigned char *) ((((char *) (-3 + obj_1867X))) + ((((i_2085X)<<2)) + j_2216X))) = (unsigned char) ((255 & shifted_2217X));
    arg0K0 = (8 + bits_2215X);
    arg0K1 = (1 + j_2216X);
    arg0K2 = ((long)(((unsigned long)shifted_2217X)>>8));
    goto L49836;}
  else {
    arg0K0 = (*((long *) ((((char *) (-3 + l_2084X))) + 4)));
    arg0K1 = (-1 + i_2085X);
    goto L49765;}}
 L40075: {
  addr_2218X = (((char *) (-3 + port_1900X))) + 36;S48_WRITE_BARRIER(port_1900X, addr_2218X, 1);
  *((long *) addr_2218X) = (long) (1);
  val_2219X = (((i_2089X + count_2099X))<<2);
  addr_2220X = (((char *) (-3 + port_1900X))) + 28;S48_WRITE_BARRIER(port_1900X, addr_2220X, val_2219X);
  *((long *) addr_2220X) = (long) (val_2219X);
  SvalS = (9 + (((value_2098X)<<8)));
  Scode_pointerS = ((Scode_pointerS) + 2);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L23925: {
  if ((3 == (3 & thing_1922X))) {
    if ((1 == (31 & ((((*((long *) ((((char *) (-3 + thing_1922X))) + -4))))>>2))))) {write_vm_string((*((long *) (((char *) (-3 + thing_1922X))))), out_1547X);
      goto L52006;}
    else {
      goto L23931;}}
  else {
    goto L23931;}}
 L29673: {
  Senabled_interruptsS = 0;
  if ((0 == ((Spending_interruptsS) & (Senabled_interruptsS)))) {
    s48_Sstack_limitS = (Sreal_stack_limitS);
    if ((s48_Spending_eventsPS)) {
      s48_Sstack_limitS = (((char *) -1));
      goto L29675;}
    else {
      goto L29675;}}
  else {
    s48_Sstack_limitS = (((char *) -1));
    goto L29675;}}
 L29712: {
  ps_error("interrupt handler is not a closure", 1, i_1548X);
  goto L29673;}
 L16065: {
  n_2221X = Senabled_interruptsS;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) ((((n_2221X)<<2)));
  arg0K0 = 2;
  goto L29642;}
 L10462: {
  count_2222X = arg0K0;
  i_2223X = arg0K1;
  offset_2224X = arg0K2;
  if ((0 == count_2222X)) {
    arg0K0 = i_2223X;
    arg0K1 = offset_2224X;
    goto L10445;}
  else {
    value_2225X = *((long *) ((((char *) (-3 + env_2133X))) + ((((*((unsigned char *) ((Scode_pointerS) + (1 + offset_2224X)))))<<2))));
    addr_2226X = (((char *) (-3 + new_env_1583X))) + (((i_2223X)<<2));S48_WRITE_BARRIER(new_env_1583X, addr_2226X, value_2225X);
    *((long *) addr_2226X) = (long) (value_2225X);
    arg0K0 = (-1 + count_2222X);
    arg0K1 = (1 + i_2223X);
    arg0K2 = (1 + offset_2224X);
    goto L10462;}}
 L11527: {
  count_2227X = arg0K0;
  i_2228X = arg0K1;
  offset_2229X = arg0K2;
  if ((0 == count_2227X)) {
    arg0K0 = i_2228X;
    arg0K1 = offset_2229X;
    goto L11510;}
  else {
    value_2230X = *((long *) ((((char *) (-3 + env_2138X))) + ((((((((*((unsigned char *) ((Scode_pointerS) + (1 + offset_2229X)))))<<8)) + (*((unsigned char *) ((Scode_pointerS) + (2 + offset_2229X))))))<<2))));
    addr_2231X = (((char *) (-3 + new_env_1592X))) + (((i_2228X)<<2));S48_WRITE_BARRIER(new_env_1592X, addr_2231X, value_2230X);
    *((long *) addr_2231X) = (long) (value_2230X);
    arg0K0 = (-1 + count_2227X);
    arg0K1 = (1 + i_2228X);
    arg0K2 = (2 + offset_2229X);
    goto L11527;}}
 L34258: {
  Scode_pointerS = ((Scode_pointerS) + (1 + bytes_used_1963X));
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L51385: {
  if ((3 == (3 & n_1677X))) {
    if ((11 == (31 & ((((*((long *) ((((char *) (-3 + n_1677X))) + -4))))>>2))))) {push_exception_setupB(5, 1);
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (n_1677X);
      arg0K0 = 1;
      goto L30610;}
    else {
      goto L51389;}}
  else {
    goto L51389;}}
 L63540: {
  v_2232X = (char *) s48_long_to_bignum(c_1979X);
  v_2233X = enter_bignum(v_2232X);
  arg0K0 = v_2233X;
  goto L63535;}
 L63535: {
  val_2234X = arg0K0;
  SvalS = val_2234X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L12623: {
  x_2235X = 0 - c_1979X;s48_make_availableAgc(16);
  if ((536870911 < x_2235X)) {
    goto L63518;}
  else {
    if ((x_2235X < -536870912)) {
      goto L63518;}
    else {
      arg0K0 = (((x_2235X)<<2));
      goto L63513;}}}
 L63562: {
  v_2236X = (char *) s48_long_to_bignum(c_1979X);
  v_2237X = enter_bignum(v_2236X);
  arg0K0 = v_2237X;
  goto L63557;}
 L63557: {
  val_2238X = arg0K0;
  SvalS = val_2238X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L63621: {
  v_2239X = (char *) s48_long_to_bignum(x_2159X);
  v_2240X = enter_bignum(v_2239X);
  arg0K0 = v_2240X;
  goto L63616;}
 L63616: {
  val_2241X = arg0K0;
  SvalS = val_2241X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L21205: {
  extra1_2242X = arg0K0;
  Stemp0S = arg2_1120X;
  Stemp1S = y_1121X;s48_make_availableAgc(((((((6 + (-2 & ((((7 + (((length0_2163X)<<2))))>>1)))) + extra0_2164X) + extra1_2242X))<<2)));
  value_2243X = Stemp0S;
  Stemp0S = 1;
  if ((0 == (3 & value_2243X))) {
    v_2244X = (char *) s48_long_to_bignum((((value_2243X)>>2)));
    arg3K0 = v_2244X;
    goto L24627;}
  else {
    arg3K0 = (((char *) (-3 + value_2243X)));
    goto L24627;}}
 L24793: {
  external_bignum_2245X = arg3K0;
  v_2246X = s48_bignum_fits_in_word_p(external_bignum_2245X, 30, 1);
  if (v_2246X) {
    n_2247X = s48_bignum_to_long(external_bignum_2245X);
    arg0K0 = (((n_2247X)<<2));
    goto L53717;}
  else {
    val_2248X = enter_bignum(external_bignum_2245X);
    arg0K0 = val_2248X;
    goto L53717;}}
 L53779: {
  val_2249X = arg0K0;
  SvalS = val_2249X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L28204: {
  value_2250X = arg0K0;
  addr_2251X = (((char *) (-3 + table_1275X))) + (((index_1278X)<<2));S48_WRITE_BARRIER(table_1275X, addr_2251X, value_2250X);
  *((long *) addr_2251X) = (long) (value_2250X);
  arg0K0 = x_2189X;
  goto L43736;}
 L48000: {
  v_2252X = ps_close_fd(index_2045X);
  arg0K0 = v_2252X;
  goto L47995;}
 L47995: {
  status_2253X = arg0K0;
  if ((status_2253X == NO_ERRORS)) {push_exception_setupB(reason_2194X, 1);
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) (arg4_1289X);
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) ((((mode_1290X)<<2)));
    arg0K0 = 2;
    goto L30610;}
  else {channel_close_error(status_2253X, index_2045X, arg4_1289X);push_exception_setupB(reason_2194X, 1);
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) (arg4_1289X);
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) ((((mode_1290X)<<2)));
    arg0K0 = 2;
    goto L30610;}}
 L48392: {
  x_2254X = arg0K0;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_2254X);
  arg0K0 = 5;
  goto L30610;}
 L13250: {
  i_2255X = arg0K0;
  stob_2256X = *((long *) ((((char *) (-3 + log_2200X))) + (((i_2255X)<<2))));
  if ((1 == stob_2256X)) {
    log_2257X = *((long *) ((((char *) (-3 + proposal_1335X))) + 8));
    arg0K0 = 0;
    goto L16940;}
  else {
    value_2258X = *((long *) ((((char *) (-3 + log_2200X))) + (8 + (((i_2255X)<<2)))));
    verify_2259X = *((long *) ((((char *) (-3 + log_2200X))) + (12 + (((i_2255X)<<2)))));
    if ((verify_2259X == value_2258X)) {
      goto L13282;}
    else {
      addr_2260X = (((char *) (-3 + stob_2256X))) + (-4 & (*((long *) ((((char *) (-3 + log_2200X))) + (4 + (((i_2255X)<<2)))))));S48_WRITE_BARRIER(stob_2256X, addr_2260X, value_2258X);
      *((long *) addr_2260X) = (long) (value_2258X);
      goto L13282;}}}
 L27698: {
  previous_foo_2261X = arg0K0;
  foo_2262X = arg0K1;
  if ((1 == foo_2262X)) {
    goto L41954;}
  else {
    s2_2263X = *((long *) (((char *) (-3 + foo_2262X))));
    len_2264X = (long)(((unsigned long)(*((long *) ((((char *) (-3 + arg2_1435X))) + -4))))>>8);
    if ((len_2264X == ((long)(((unsigned long)(*((long *) ((((char *) (-3 + s2_2263X))) + -4))))>>8)))) {
      if (((!memcmp((void *)(((char *) (-3 + s2_2263X))), (void *)(((char *) (-3 + arg2_1435X))),len_2264X)))) {
        if ((1 == previous_foo_2261X)) {
          value_2265X = *((long *) ((((char *) (-3 + foo_2262X))) + 12));
          addr_2266X = (((char *) (-3 + table_2080X))) + (((index_2082X)<<2));S48_WRITE_BARRIER(table_2080X, addr_2266X, value_2265X);
          *((long *) addr_2266X) = (long) (value_2265X);
          goto L41954;}
        else {
          val_2267X = *((long *) ((((char *) (-3 + foo_2262X))) + 12));
          addr_2268X = (((char *) (-3 + previous_foo_2261X))) + 12;S48_WRITE_BARRIER(previous_foo_2261X, addr_2268X, val_2267X);
          *((long *) addr_2268X) = (long) (val_2267X);
          goto L41954;}}
      else {
        goto L27757;}}
    else {
      goto L27757;}}}
 L23931: {
  if ((1 == thing_1922X)) {
    goto L23936;}
  else {
    if ((5 == thing_1922X)) {
      goto L23936;}
    else {
      if ((25 == thing_1922X)) {
        arg5K0 = "()";
        goto L23975;}
      else {
        if ((3 == (3 & thing_1922X))) {
          if ((0 == (31 & ((((*((long *) ((((char *) (-3 + thing_1922X))) + -4))))>>2))))) {
            arg5K0 = "(...)";
            goto L23975;}
          else {
            goto L23949;}}
        else {
          goto L23949;}}}}}
 L29675: {
  arg0K0 = arg_count_1925X;
  arg0K1 = 25;
  arg0K2 = 0;
  arg0K3 = (-2 - i_1548X);
  goto L60809;}
 L51389: {
  SvalS = 1;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L63518: {
  v_2269X = (char *) s48_long_to_bignum(x_2235X);
  v_2270X = enter_bignum(v_2269X);
  arg0K0 = v_2270X;
  goto L63513;}
 L63513: {
  val_2271X = arg0K0;
  SvalS = val_2271X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L24627: {
  x_2272X = arg3K0;
  value_2273X = Stemp1S;
  Stemp1S = 1;
  if ((0 == (3 & value_2273X))) {
    v_2274X = (char *) s48_long_to_bignum((((value_2273X)>>2)));
    arg3K0 = v_2274X;
    goto L24631;}
  else {
    arg3K0 = (((char *) (-3 + value_2273X)));
    goto L24631;}}
 L53717: {
  val_2275X = arg0K0;
  SvalS = val_2275X;
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L16940: {
  i_2276X = arg0K0;
  stob_2277X = *((long *) ((((char *) (-3 + log_2257X))) + (((i_2276X)<<2))));
  if ((1 == stob_2277X)) {
    copies_2278X = *((long *) ((((char *) (-3 + proposal_1335X))) + 12));
    arg0K0 = copies_2278X;
    goto L16855;}
  else {
    value_2279X = *((long *) ((((char *) (-3 + log_2257X))) + (8 + (((i_2276X)<<2)))));
    verify_2280X = *((long *) ((((char *) (-3 + log_2257X))) + (12 + (((i_2276X)<<2)))));
    if ((verify_2280X == value_2279X)) {
      goto L16972;}
    else {
      *((unsigned char *) ((((char *) (-3 + stob_2277X))) + ((((*((long *) ((((char *) (-3 + log_2257X))) + (4 + (((i_2276X)<<2)))))))>>2)))) = (unsigned char) ((((value_2279X)>>2)));
      goto L16972;}}}
 L13282: {
  arg0K0 = (4 + i_2255X);
  goto L13250;}
 L41954: {
  Scode_pointerS = ((Scode_pointerS) + 1);
  arg3K0 = (Scode_pointerS);
  goto L32913;}
 L27757: {
  link_2281X = *((long *) ((((char *) (-3 + foo_2262X))) + 12));
  if ((0 == (3 & link_2281X))) {
    arg0K0 = foo_2262X;
    arg0K1 = (3 + (-4 & link_2281X));
    goto L27698;}
  else {
    arg0K0 = foo_2262X;
    arg0K1 = link_2281X;
    goto L27698;}}
 L23936: {
  if ((1 == thing_1922X)) {
    arg5K0 = "#f";
    goto L23975;}
  else {
    arg5K0 = "#t";
    goto L23975;}}
 L23975: {
  v_2282X = arg5K0;
  ps_write_string(v_2282X, out_1547X);
  goto L52006;}
 L23949: {
  if ((3 == (3 & thing_1922X))) {
    if ((2 == (31 & ((((*((long *) ((((char *) (-3 + thing_1922X))) + -4))))>>2))))) {
      arg5K0 = "#(...)";
      goto L23975;}
    else {
      goto L23953;}}
  else {
    goto L23953;}}
 L24631: {
  y_2283X = arg3K0;
  div_by_zeroP_2284X = s48_bignum_divide(x_2272X, y_2283X, &quot_2285X, &rem_2286X);
  if (div_by_zeroP_2284X) {
    v_2287X = s48_bignum_fits_in_word_p(y_2283X, 30, 1);
    if (v_2287X) {
      n_2288X = s48_bignum_to_long(y_2283X);
      arg0K0 = (((n_2288X)<<2));
      goto L24653;}
    else {
      v_2289X = enter_bignum(y_2283X);
      arg0K0 = v_2289X;
      goto L24653;}}
  else {
    v_2290X = s48_bignum_fits_in_word_p(y_2283X, 30, 1);
    if (v_2290X) {
      n_2291X = s48_bignum_to_long(y_2283X);
      arg0K0 = (((n_2291X)<<2));
      goto L24662;}
    else {
      v_2292X = enter_bignum(y_2283X);
      arg0K0 = v_2292X;
      goto L24662;}}}
 L16855: {
  copies_2293X = arg0K0;
  if ((1 == copies_2293X)) {
    value_2294X = Sempty_logS;
    addr_2295X = (((char *) (-3 + proposal_1335X))) + 4;S48_WRITE_BARRIER(proposal_1335X, addr_2295X, value_2294X);
    *((long *) addr_2295X) = (long) (value_2294X);
    value_2296X = Sempty_logS;
    addr_2297X = (((char *) (-3 + proposal_1335X))) + 8;S48_WRITE_BARRIER(proposal_1335X, addr_2297X, value_2296X);
    *((long *) addr_2297X) = (long) (value_2296X);
    addr_2298X = (((char *) (-3 + proposal_1335X))) + 12;S48_WRITE_BARRIER(proposal_1335X, addr_2298X, 1);
    *((long *) addr_2298X) = (long) (1);RELEASE_PROPOSAL_LOCK();
    x_2299X = Scurrent_threadS;
    addr_2300X = (((char *) (-3 + x_2299X))) + 12;S48_WRITE_BARRIER(x_2299X, addr_2300X, 1);
    *((long *) addr_2300X) = (long) (1);
    SvalS = 5;
    Scode_pointerS = ((Scode_pointerS) + 1);
    arg3K0 = (Scode_pointerS);
    goto L32913;}
  else {
    stob_2301X = *((long *) ((((char *) (-3 + copies_2293X))) + 8));
    v_2302X = (((*((long *) ((((char *) (-3 + copies_2293X))) + 12))))>>2);
    stob_2303X = *((long *) (((char *) (-3 + copies_2293X))));
    v_2304X = (((*((long *) ((((char *) (-3 + copies_2293X))) + 4))))>>2);
    v_2305X = (((*((long *) ((((char *) (-3 + copies_2293X))) + 16))))>>2);
    memmove((void *)((((char *) (-3 + stob_2301X))) + v_2302X), (void *)((((char *) (-3 + stob_2303X))) + v_2304X),v_2305X);
    arg0K0 = (*((long *) ((((char *) (-3 + copies_2293X))) + 20)));
    goto L16855;}}
 L16972: {
  arg0K0 = (4 + i_2276X);
  goto L16940;}
 L23953: {
  if ((3 == (3 & thing_1922X))) {
    if ((3 == (31 & ((((*((long *) ((((char *) (-3 + thing_1922X))) + -4))))>>2))))) {
      arg5K0 = "#{procedure}";
      goto L23975;}
    else {
      goto L23957;}}
  else {
    goto L23957;}}
 L24653: {
  v_2306X = arg0K0;
  v_2307X = s48_bignum_fits_in_word_p(x_2272X, 30, 1);
  if (v_2307X) {
    n_2308X = s48_bignum_to_long(x_2272X);
    arg4K0 = 1;
    arg0K1 = 0;
    arg0K2 = 0;
    arg0K3 = (((n_2308X)<<2));
    arg0K4 = v_2306X;
    goto L53390;}
  else {
    v_2309X = enter_bignum(x_2272X);
    arg4K0 = 1;
    arg0K1 = 0;
    arg0K2 = 0;
    arg0K3 = v_2309X;
    arg0K4 = v_2306X;
    goto L53390;}}
 L24662: {
  v_2310X = arg0K0;
  v_2311X = s48_bignum_fits_in_word_p(rem_2286X, 30, 1);
  if (v_2311X) {
    n_2312X = s48_bignum_to_long(rem_2286X);
    arg0K0 = (((n_2312X)<<2));
    goto L24658;}
  else {
    v_2313X = enter_bignum(rem_2286X);
    arg0K0 = v_2313X;
    goto L24658;}}
 L23957: {
  if ((3 == (3 & thing_1922X))) {
    if ((12 == (31 & ((((*((long *) ((((char *) (-3 + thing_1922X))) + -4))))>>2))))) {
      arg5K0 = "#{template}";
      goto L23975;}
    else {
      goto L23961;}}
  else {
    goto L23961;}}
 L53390: {
  div_by_zeroP_2314X = arg4K0;
  quot_2315X = arg0K1;
  rem_2316X = arg0K2;
  x_2317X = arg0K3;
  y_2318X = arg0K4;
  if (div_by_zeroP_2314X) {
    goto L53413;}
  else {
    if ((0 == (3 & rem_2316X))) {
      if ((0 == rem_2316X)) {
        SvalS = quot_2315X;
        Scode_pointerS = ((Scode_pointerS) + 1);
        arg3K0 = (Scode_pointerS);
        goto L32913;}
      else {
        goto L53413;}}
    else {
      goto L53413;}}}
 L24658: {
  v_2319X = arg0K0;
  v_2320X = s48_bignum_fits_in_word_p(quot_2285X, 30, 1);
  if (v_2320X) {
    n_2321X = s48_bignum_to_long(quot_2285X);
    arg0K0 = (((n_2321X)<<2));
    goto L24656;}
  else {
    v_2322X = enter_bignum(quot_2285X);
    arg0K0 = v_2322X;
    goto L24656;}}
 L23961: {
  if ((3 == (3 & thing_1922X))) {
    if ((4 == (31 & ((((*((long *) ((((char *) (-3 + thing_1922X))) + -4))))>>2))))) {
      arg5K0 = "#{location}";
      goto L23975;}
    else {
      goto L23965;}}
  else {
    goto L23965;}}
 L53413: {
push_exception_setupB(5, 1);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_2317X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (y_2318X);
  arg0K0 = 2;
  goto L30610;}
 L24656: {
  v_2323X = arg0K0;
  v_2324X = s48_bignum_fits_in_word_p(x_2272X, 30, 1);
  if (v_2324X) {
    n_2325X = s48_bignum_to_long(x_2272X);
    arg4K0 = 0;
    arg0K1 = v_2323X;
    arg0K2 = v_2319X;
    arg0K3 = (((n_2325X)<<2));
    arg0K4 = v_2310X;
    goto L53390;}
  else {
    v_2326X = enter_bignum(x_2272X);
    arg4K0 = 0;
    arg0K1 = v_2323X;
    arg0K2 = v_2319X;
    arg0K3 = v_2326X;
    arg0K4 = v_2310X;
    goto L53390;}}
 L23965: {
  if ((3 == (3 & thing_1922X))) {
    if ((17 == (31 & ((((*((long *) ((((char *) (-3 + thing_1922X))) + -4))))>>2))))) {
      arg5K0 = "#{code-vector}";
      goto L23975;}
    else {
      goto L23969;}}
  else {
    goto L23969;}}
 L23969: {
  if ((3 == (3 & thing_1922X))) {
    if ((10 == (31 & ((((*((long *) ((((char *) (-3 + thing_1922X))) + -4))))>>2))))) {
      arg5K0 = "#{continuation}";
      goto L23975;}
    else {
      arg5K0 = "???";
      goto L23975;}}
  else {
    arg5K0 = "???";
    goto L23975;}}
 loseD0: {
  message_914X = merged_arg5K0;{
  ps_write_string("Template UIDs: ", (stderr));
  current_code_2327X = current_code_vector();
  out_2328X = stderr;
  merged_arg3K0 = (SstackS);
  merged_arg0K1 = (((((ScontS) - (SstackS)))>>2));
  merged_arg0K2 = current_code_2327X;
  find_template_return_tag = 0;
  goto find_template;
 find_template_return_0:
  template_2329X = find_template0_return_value;
  merged_arg0K0 = template_2329X;
  merged_arg4K1 = 0;
  merged_arg6K2 = out_2328X;
  maybe_write_template_return_tag = 0;
  goto maybe_write_template;
 maybe_write_template_return_0:
  not_firstP_2330X = maybe_write_template0_return_value;
  arg3K0 = (ScontS);
  arg4K1 = not_firstP_2330X;
  goto L27643;}
 L27643: {
  cont_2331X = arg3K0;
  not_firstP_2332X = arg4K1;
  if ((cont_2331X == (Sbottom_of_stackS))) {
    cont_2333X = Sheap_continuationS;
    arg0K0 = cont_2333X;
    arg4K1 = not_firstP_2332X;
    goto L26895;}
  else {
    code_pointer_2334X = ((char *) (*((long *) cont_2331X)));
    pointer_2335X = code_pointer_2334X + -5;
    v_2336X = 3 + (((long) (code_pointer_2334X + (0 - (((((*((unsigned char *) pointer_2335X)))<<8)) + (*((unsigned char *) (pointer_2335X + 1))))))));
    pointer_2337X = (((char *) (*((long *) cont_2331X)))) + -2;
    size_2338X = ((((*((unsigned char *) pointer_2337X)))<<8)) + (*((unsigned char *) (pointer_2337X + 1)));
    if ((65535 == size_2338X)) {
      arg0K0 = ((((*((long *) (cont_2331X + 4))))>>2));
      goto L22003;}
    else {
      arg0K0 = size_2338X;
      goto L22003;}}}
 L26895: {
  cont_2339X = arg0K0;
  not_firstP_2340X = arg4K1;
  if ((3 == (3 & cont_2339X))) {
    if ((10 == (31 & ((((*((long *) ((((char *) (-3 + cont_2339X))) + -4))))>>2))))) {
      merged_arg3K0 = (((char *) (-3 + cont_2339X)));
      merged_arg0K1 = ((((3 + ((long)(((unsigned long)(*((long *) ((((char *) (-3 + cont_2339X))) + -4))))>>8))))>>2));
      merged_arg0K2 = (*((long *) ((((char *) (-3 + cont_2339X))) + 4)));
      find_template_return_tag = 1;
      goto find_template;
     find_template_return_1:
      v_2341X = find_template0_return_value;
      merged_arg0K0 = v_2341X;
      merged_arg4K1 = not_firstP_2340X;
      merged_arg6K2 = out_2328X;
      maybe_write_template_return_tag = 1;
      goto maybe_write_template;
     maybe_write_template_return_1:
      v_2342X = maybe_write_template0_return_value;
      arg0K0 = (*((long *) ((((char *) (-3 + cont_2339X))) + 8)));
      arg4K1 = v_2342X;
      goto L26895;}
    else {
      goto L30708;}}
  else {
    goto L30708;}}
 L22003: {
  v_2343X = arg0K0;
  merged_arg3K0 = (cont_2331X + 4);
  merged_arg0K1 = v_2343X;
  merged_arg0K2 = v_2336X;
  find_template_return_tag = 2;
  goto find_template;
 find_template_return_2:
  v_2344X = find_template0_return_value;
  merged_arg0K0 = v_2344X;
  merged_arg4K1 = not_firstP_2332X;
  merged_arg6K2 = out_2328X;
  maybe_write_template_return_tag = 2;
  goto maybe_write_template;
 maybe_write_template_return_2:
  v_2345X = maybe_write_template0_return_value;
  pointer_2346X = (((char *) (*((long *) cont_2331X)))) + -2;
  size_2347X = ((((*((unsigned char *) pointer_2346X)))<<8)) + (*((unsigned char *) (pointer_2346X + 1)));
  if ((65535 == size_2347X)) {
    arg0K0 = ((((*((long *) (cont_2331X + 4))))>>2));
    goto L27661;}
  else {
    arg0K0 = size_2347X;
    goto L27661;}}
 L30708: {
  { long ignoreXX;
  PS_WRITE_CHAR(10, (stderr), ignoreXX) }
  why_2348X = (((*((long *) ((SstackS) + (((nargs_951X)<<2))))))>>2);
  if ((why_2348X == 1)) {
    if ((0 == (3 & (*((long *) (((char *) (-3 + (*((long *) ((SstackS) + (-4 + (((nargs_951X)<<2)))))))))))))) {
      ps_error(message_914X, 3, opcode_952X, why_2348X, ((((*((long *) (((char *) (-3 + (*((long *) ((SstackS) + (-4 + (((nargs_951X)<<2))))))))))))>>2)));
      goto loseD0_return;}
    else {
      goto L30655;}}
  else {
    goto L30655;}}
 L27661: {
  v_2349X = arg0K0;
  arg3K0 = (cont_2331X + (4 + (((v_2349X)<<2))));
  arg4K1 = v_2345X;
  goto L27643;}
 L30655: {
  ps_error(message_914X, 2, opcode_952X, why_2348X);
  goto loseD0_return;}
 loseD0_return:
  switch (loseD0_return_tag) {
  case 0: goto loseD0_return_0;
  default: goto loseD0_return_1;
  }}

 maybe_write_template: {
  template_911X = merged_arg0K0;
  not_firstP_912X = merged_arg4K1;
  out_913X = merged_arg6K2;{
  if (not_firstP_912X) {
    ps_write_string(" <- ", out_913X);
    goto L23648;}
  else {
    goto L23648;}}
 L23648: {
  if ((3 == (3 & template_911X))) {
    if ((12 == (31 & ((((*((long *) ((((char *) (-3 + template_911X))) + -4))))>>2))))) {
      name_2350X = *((long *) ((((char *) (-3 + template_911X))) + 8));
      if ((0 == (3 & name_2350X))) {
        ps_write_integer((((name_2350X)>>2)), out_913X);
        maybe_write_template0_return_value = 1;
        goto maybe_write_template_return;}
      else {
        if ((3 == (3 & name_2350X))) {
          if ((9 == (31 & ((((*((long *) ((((char *) (-3 + name_2350X))) + -4))))>>2))))) {
            obj_2351X = *((long *) ((((char *) (-3 + name_2350X))) + 8));
            if ((3 == (3 & obj_2351X))) {
              if ((16 == (31 & ((((*((long *) ((((char *) (-3 + obj_2351X))) + -4))))>>2))))) {write_vm_string((*((long *) ((((char *) (-3 + name_2350X))) + 8))), out_913X);
                maybe_write_template0_return_value = 1;
                goto maybe_write_template_return;}
              else {
                goto L23683;}}
            else {
              goto L23683;}}
          else {
            goto L23683;}}
        else {
          goto L23683;}}}
    else {
      goto L23706;}}
  else {
    goto L23706;}}
 L23683: {
  if ((3 == (3 & name_2350X))) {
    if ((9 == (31 & ((((*((long *) ((((char *) (-3 + name_2350X))) + -4))))>>2))))) {
      obj_2352X = *((long *) ((((char *) (-3 + name_2350X))) + 8));
      if ((3 == (3 & obj_2352X))) {
        if ((1 == (31 & ((((*((long *) ((((char *) (-3 + obj_2352X))) + -4))))>>2))))) {write_vm_string((*((long *) (((char *) (-3 + (*((long *) ((((char *) (-3 + name_2350X))) + 8)))))))), out_913X);
          maybe_write_template0_return_value = 1;
          goto maybe_write_template_return;}
        else {
          goto L23703;}}
      else {
        goto L23703;}}
    else {
      goto L23703;}}
  else {
    goto L23703;}}
 L23706: {
  ps_write_string(" ?? ", out_913X);
  maybe_write_template0_return_value = 1;
  goto maybe_write_template_return;}
 L23703: {
  ps_write_string("?", out_913X);
  maybe_write_template0_return_value = 1;
  goto maybe_write_template_return;}
 maybe_write_template_return:
  switch (maybe_write_template_return_tag) {
  case 0: goto maybe_write_template_return_0;
  case 1: goto maybe_write_template_return_1;
  default: goto maybe_write_template_return_2;
  }}

 find_template: {
  start_908X = merged_arg3K0;
  count_909X = merged_arg0K1;
  code_vector_910X = merged_arg0K2;{
  arg0K0 = 0;
  goto L18975;}
 L18975: {
  i_2353X = arg0K0;
  if ((i_2353X == count_909X)) {
    find_template0_return_value = 1;
    goto find_template_return;}
  else {
    next_2354X = *((long *) (start_908X + (((i_2353X)<<2))));
    if ((3 == (3 & next_2354X))) {
      if ((12 == (31 & ((((*((long *) ((((char *) (-3 + next_2354X))) + -4))))>>2))))) {
        if (((*((long *) (((char *) (-3 + next_2354X))))) == code_vector_910X)) {
          find_template0_return_value = next_2354X;
          goto find_template_return;}
        else {
          goto L18997;}}
      else {
        goto L18997;}}
    else {
      goto L18997;}}}
 L18997: {
  arg0K0 = (1 + i_2353X);
  goto L18975;}
 find_template_return:
  switch (find_template_return_tag) {
  case 0: goto find_template_return_0;
  case 1: goto find_template_return_1;
  default: goto find_template_return_2;
  }}

 rest_list_setupAgc: {
  wants_stack_args_904X = merged_arg0K0;
  stack_arg_count_905X = merged_arg0K1;
  list_args_906X = merged_arg0K2;
  list_arg_count_907X = merged_arg0K3;{
  if ((stack_arg_count_905X == wants_stack_args_904X)) {
    merged_arg0K0 = list_args_906X;
    merged_arg0K1 = list_arg_count_907X;
    copy_listSAgc_return_tag = 1;
    goto copy_listSAgc;
   copy_listSAgc_return_1:
    x_2355X = copy_listSAgc0_return_value;
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) (x_2355X);
    goto rest_list_setupAgc_return;}
  else {
    if ((stack_arg_count_905X < wants_stack_args_904X)) {
      count_2356X = wants_stack_args_904X - stack_arg_count_905X;
      merged_arg0K0 = list_args_906X;
      merged_arg0K1 = count_2356X;
      push_list_return_tag = 4;
      goto push_list;
     push_list_return_4:
      v_2357X = push_list0_return_value;
      merged_arg0K0 = v_2357X;
      merged_arg0K1 = (list_arg_count_907X - count_2356X);
      copy_listSAgc_return_tag = 2;
      goto copy_listSAgc;
     copy_listSAgc_return_2:
      x_2358X = copy_listSAgc0_return_value;
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (x_2358X);
      goto rest_list_setupAgc_return;}
    else {
      merged_arg0K0 = list_args_906X;
      merged_arg0K1 = list_arg_count_907X;
      copy_listSAgc_return_tag = 3;
      goto copy_listSAgc;
     copy_listSAgc_return_3:
      v_2359X = copy_listSAgc0_return_value;
      merged_arg0K0 = v_2359X;
      merged_arg0K1 = (stack_arg_count_905X - wants_stack_args_904X);
      pop_args_GlistSAgc_return_tag = 12;
      goto pop_args_GlistSAgc;
     pop_args_GlistSAgc_return_12:
      x_2360X = pop_args_GlistSAgc0_return_value;
      SstackS = ((SstackS) + -4);
      *((long *) (SstackS)) = (long) (x_2360X);
      goto rest_list_setupAgc_return;}}}
 rest_list_setupAgc_return:
  switch (rest_list_setupAgc_return_tag) {
  case 0: goto rest_list_setupAgc_return_0;
  default: goto rest_list_setupAgc_return_1;
  }}

 push_list: {
  list_902X = merged_arg0K0;
  count_903X = merged_arg0K1;{
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (list_902X);
  merged_arg0K0 = count_903X;
  ensure_stack_spaceB_return_tag = 2;
  goto ensure_stack_spaceB;
 ensure_stack_spaceB_return_2:
  v_2361X = ensure_stack_spaceB0_return_value;
  if (v_2361X) {
    s48_Sstack_limitS = (((char *) -1));
    goto L29093;}
  else {
    goto L29093;}}
 L29093: {
  list_2362X = *((long *) (SstackS));
  SstackS = ((SstackS) + 4);
  arg0K0 = count_903X;
  arg0K1 = list_2362X;
  goto L29102;}
 L29102: {
  i_2363X = arg0K0;
  l_2364X = arg0K1;
  if ((0 < i_2363X)) {
    x_2365X = *((long *) (((char *) (-3 + l_2364X))));
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) (x_2365X);
    arg0K0 = (-1 + i_2363X);
    arg0K1 = (*((long *) ((((char *) (-3 + l_2364X))) + 4)));
    goto L29102;}
  else {
    push_list0_return_value = l_2364X;
    goto push_list_return;}}
 push_list_return:
  switch (push_list_return_tag) {
  case 0: goto push_list_return_0;
  case 1: goto push_list_return_1;
  case 2: goto push_list_return_2;
  case 3: goto push_list_return_3;
  default: goto push_list_return_4;
  }}

 ensure_stack_spaceB: {
  need_901X = merged_arg0K0;{
  if ((((SstackS) + (256 - (((need_901X)<<2)))) < (s48_Sstack_limitS))) {
    interruptP_2366X = (s48_Sstack_limitS) == (((char *) -1));
    s48_Sstack_limitS = (Sreal_stack_limitS);
    if ((((SstackS) + (256 - (((need_901X)<<2)))) < (Sreal_stack_limitS))) {s48_copy_stack_into_heap();
      if ((((SstackS) + (256 - (((need_901X)<<2)))) < (Sreal_stack_limitS))) {
        ps_error("VM's stack is too small (how can this happen?)", 0);
        ensure_stack_spaceB0_return_value = interruptP_2366X;
        goto ensure_stack_spaceB_return;}
      else {
        ensure_stack_spaceB0_return_value = interruptP_2366X;
        goto ensure_stack_spaceB_return;}}
    else {
      ensure_stack_spaceB0_return_value = interruptP_2366X;
      goto ensure_stack_spaceB_return;}}
  else {
    ensure_stack_spaceB0_return_value = 0;
    goto ensure_stack_spaceB_return;}}
 ensure_stack_spaceB_return:
  switch (ensure_stack_spaceB_return_tag) {
  case 0: goto ensure_stack_spaceB_return_0;
  case 1: goto ensure_stack_spaceB_return_1;
  default: goto ensure_stack_spaceB_return_2;
  }}

 pop_args_GlistSAgc: {
  start_899X = merged_arg0K0;
  count_900X = merged_arg0K1;{
  Stemp0S = start_899X;s48_make_availableAgc(((((3 * count_900X))<<2)));
  value_2367X = Stemp0S;
  Stemp0S = 1;
  arg0K0 = value_2367X;
  arg0K1 = count_900X;
  goto L22802;}
 L22802: {
  args_2368X = arg0K0;
  count_2369X = arg0K1;
  if ((0 == count_2369X)) {
    pop_args_GlistSAgc0_return_value = args_2368X;
    goto pop_args_GlistSAgc_return;}
  else {
    a_2370X = *((long *) (SstackS));
    SstackS = ((SstackS) + 4);
    addr_2371X = s48_allocate_small(12);
    *((long *) addr_2371X) = (long) (2050);
    x_2372X = 3 + (((long) (addr_2371X + 4)));
    *((long *) (((char *) (-3 + x_2372X)))) = (long) (a_2370X);
    *((long *) ((((char *) (-3 + x_2372X))) + 4)) = (long) (args_2368X);
    arg0K0 = x_2372X;
    arg0K1 = (-1 + count_2369X);
    goto L22802;}}
 pop_args_GlistSAgc_return:
  switch (pop_args_GlistSAgc_return_tag) {
  case 0: goto pop_args_GlistSAgc_return_0;
  case 1: goto pop_args_GlistSAgc_return_1;
  case 2: goto pop_args_GlistSAgc_return_2;
  case 3: goto pop_args_GlistSAgc_return_3;
  case 4: goto pop_args_GlistSAgc_return_4;
  case 5: goto pop_args_GlistSAgc_return_5;
  case 6: goto pop_args_GlistSAgc_return_6;
  case 7: goto pop_args_GlistSAgc_return_7;
  case 8: goto pop_args_GlistSAgc_return_8;
  case 9: goto pop_args_GlistSAgc_return_9;
  case 10: goto pop_args_GlistSAgc_return_10;
  case 11: goto pop_args_GlistSAgc_return_11;
  default: goto pop_args_GlistSAgc_return_12;
  }}

 copy_listSAgc: {
  list_897X = merged_arg0K0;
  length_898X = merged_arg0K1;{
  if ((0 == length_898X)) {
    copy_listSAgc0_return_value = 25;
    goto copy_listSAgc_return;}
  else {
    Stemp0S = list_897X;s48_make_availableAgc(((((3 * length_898X))<<2)));
    value_2373X = Stemp0S;
    Stemp0S = 1;
    a_2374X = *((long *) (((char *) (-3 + value_2373X))));
    addr_2375X = s48_allocate_small(12);
    *((long *) addr_2375X) = (long) (2050);
    x_2376X = 3 + (((long) (addr_2375X + 4)));
    *((long *) (((char *) (-3 + x_2376X)))) = (long) (a_2374X);
    *((long *) ((((char *) (-3 + x_2376X))) + 4)) = (long) (25);
    arg0K0 = (*((long *) ((((char *) (-3 + value_2373X))) + 4)));
    arg0K1 = x_2376X;
    goto L22690;}}
 L22690: {
  l_2377X = arg0K0;
  last_2378X = arg0K1;
  if ((25 == l_2377X)) {
    copy_listSAgc0_return_value = x_2376X;
    goto copy_listSAgc_return;}
  else {
    a_2379X = *((long *) (((char *) (-3 + l_2377X))));
    addr_2380X = s48_allocate_small(12);
    *((long *) addr_2380X) = (long) (2050);
    x_2381X = 3 + (((long) (addr_2380X + 4)));
    *((long *) (((char *) (-3 + x_2381X)))) = (long) (a_2379X);
    *((long *) ((((char *) (-3 + x_2381X))) + 4)) = (long) (25);
    addr_2382X = (((char *) (-3 + last_2378X))) + 4;S48_WRITE_BARRIER(last_2378X, addr_2382X, x_2381X);
    *((long *) addr_2382X) = (long) (x_2381X);
    arg0K0 = (*((long *) ((((char *) (-3 + l_2377X))) + 4)));
    arg0K1 = x_2381X;
    goto L22690;}}
 copy_listSAgc_return:
  switch (copy_listSAgc_return_tag) {
  case 0: goto copy_listSAgc_return_0;
  case 1: goto copy_listSAgc_return_1;
  case 2: goto copy_listSAgc_return_2;
  default: goto copy_listSAgc_return_3;
  }}

 pop_continuationB: {
{ SstackS = (ScontS);
  cont_2383X = ScontS;
  pointer_2384X = (((char *) (*((long *) cont_2383X)))) + -2;
  size_2385X = ((((*((unsigned char *) pointer_2384X)))<<8)) + (*((unsigned char *) (pointer_2384X + 1)));
  if ((65535 == size_2385X)) {
    arg0K0 = ((((*((long *) (cont_2383X + 4))))>>2));
    goto L22534;}
  else {
    arg0K0 = size_2385X;
    goto L22534;}}
 L22534: {
  v_2386X = arg0K0;
  ScontS = (cont_2383X + (4 + (((v_2386X)<<2))));
  v_2387X = *((long *) (SstackS));
  SstackS = ((SstackS) + 4);
  Scode_pointerS = (((char *) v_2387X));
  Slast_code_pointer_resumedS = (Scode_pointerS);
  goto pop_continuationB_return;}
 pop_continuationB_return:
  switch (pop_continuationB_return_tag) {
  case 0: goto pop_continuationB_return_0;
  case 1: goto pop_continuationB_return_1;
  case 2: goto pop_continuationB_return_2;
  case 3: goto pop_continuationB_return_3;
  case 4: goto pop_continuationB_return_4;
  case 5: goto pop_continuationB_return_5;
  default: goto pop_continuationB_return_6;
  }}

 shift_space: {
  x_895X = merged_arg0K0;
  n_896X = merged_arg0K1;{
  if ((0 == (3 & x_895X))) {
    arg0K0 = 1;
    arg0K1 = 3;
    goto L21230;}
  else {
    arg0K0 = (-1 + ((((3 + ((long)(((unsigned long)(*((long *) ((((char *) (-3 + x_895X))) + -4))))>>8))))>>2)));
    arg0K1 = 0;
    goto L21230;}}
 L21230: {
  x_size_2388X = arg0K0;
  extra_2389X = arg0K1;
  if ((n_896X < 0)) {
    if ((x_size_2388X < 1)) {
      arg0K0 = 1;
      goto L21272;}
    else {
      arg0K0 = x_size_2388X;
      goto L21272;}}
  else {
    n_2390X = n_896X / 30;
    arg0K0 = (3 + (((((7 + (((x_size_2388X)<<2))))>>2)) + ((((7 + (((n_2390X)<<2))))>>2))));
    goto L21250;}}
 L21272: {
  v_2391X = arg0K0;
  arg0K0 = (4 + ((-2 & ((((11 + (((v_2391X)<<2))))>>1))) + ((((7 + (((x_size_2388X)<<2))))>>2))));
  goto L21250;}
 L21250: {
  v_2392X = arg0K0;
  shift_space0_return_value = (extra_2389X + v_2392X);
  goto shift_space_return;}
 shift_space_return:
  switch (shift_space_return_tag) {
  case 0: goto shift_space_return_0;
  default: goto shift_space_return_1;
  }}

 proposal_d_write: {
  stob_892X = merged_arg0K0;
  index_893X = merged_arg0K1;
  value_894X = merged_arg0K2;{
  log_2393X = *((long *) ((((char *) (-3 + (*((long *) ((((char *) (-3 + (Scurrent_threadS)))) + 12)))))) + 4));
  arg0K0 = 0;
  goto L20731;}
 L20731: {
  i_2394X = arg0K0;
  next_stob_2395X = *((long *) ((((char *) (-3 + log_2393X))) + (((i_2394X)<<2))));
  if ((1 == next_stob_2395X)) {add_log_entryAgc(1, i_2394X, stob_892X, index_893X, value_894X, 0);
    goto proposal_d_write_return;}
  else {
    if ((stob_892X == next_stob_2395X)) {
      if ((index_893X == (*((long *) ((((char *) (-3 + log_2393X))) + (4 + (((i_2394X)<<2)))))))) {
        addr_2396X = (((char *) (-3 + log_2393X))) + (8 + (((i_2394X)<<2)));S48_WRITE_BARRIER(log_2393X, addr_2396X, value_894X);
        *((long *) addr_2396X) = (long) (value_894X);
        goto proposal_d_write_return;}
      else {
        goto L20751;}}
    else {
      goto L20751;}}}
 L20751: {
  arg0K0 = (4 + i_2394X);
  goto L20731;}
 proposal_d_write_return:
  switch (proposal_d_write_return_tag) {
  case 0: goto proposal_d_write_return_0;
  case 1: goto proposal_d_write_return_1;
  default: goto proposal_d_write_return_2;
  }}

 proposal_d_read: {
  stob_890X = merged_arg0K0;
  index_891X = merged_arg0K1;{
  log_2397X = *((long *) ((((char *) (-3 + (*((long *) ((((char *) (-3 + (Scurrent_threadS)))) + 12)))))) + 4));
  arg0K0 = 0;
  goto L20554;}
 L20554: {
  i_2398X = arg0K0;
  next_stob_2399X = *((long *) ((((char *) (-3 + log_2397X))) + (((i_2398X)<<2))));
  if ((1 == next_stob_2399X)) {
    v_2400X = add_log_entryAgc(1, i_2398X, stob_890X, index_891X, (*((long *) ((((char *) (-3 + stob_890X))) + (-4 & index_891X)))), 1);
    proposal_d_read0_return_value = v_2400X;
    goto proposal_d_read_return;}
  else {
    if ((stob_890X == next_stob_2399X)) {
      if ((index_891X == (*((long *) ((((char *) (-3 + log_2397X))) + (4 + (((i_2398X)<<2)))))))) {
        proposal_d_read0_return_value = (*((long *) ((((char *) (-3 + log_2397X))) + (8 + (((i_2398X)<<2))))));
        goto proposal_d_read_return;}
      else {
        goto L20576;}}
    else {
      goto L20576;}}}
 L20576: {
  arg0K0 = (4 + i_2398X);
  goto L20554;}
 proposal_d_read_return:
  switch (proposal_d_read_return_tag) {
  case 0: goto proposal_d_read_return_0;
  case 1: goto proposal_d_read_return_1;
  default: goto proposal_d_read_return_2;
  }}

 pending_interruptP: {
{ if ((s48_Spending_eventsPS)) {
    s48_Spending_eventsPS = 0;
    goto L20525;}
  else {
    goto L20511;}}
 L20525: {
  type_2401X = s48_get_next_event(&channel_2402X, &status_2403X);
  if ((type_2401X == ALARM_EVENT)) {
    arg0K0 = 1;
    goto L20531;}
  else {
    if ((type_2401X == KEYBOARD_INTERRUPT_EVENT)) {
      arg0K0 = 2;
      goto L20531;}
    else {
      if ((type_2401X == IO_COMPLETION_EVENT)) {enqueue_channelB(channel_2402X, status_2403X, 1);
        arg0K0 = 16;
        goto L20531;}
      else {
        if ((type_2401X == IO_ERROR_EVENT)) {enqueue_channelB(channel_2402X, status_2403X, 5);
          arg0K0 = 16;
          goto L20531;}
        else {
          if ((type_2401X == OS_SIGNAL_EVENT)) {
            arg0K0 = 32;
            goto L20531;}
          else {
            if ((type_2401X == EXTERNAL_EVENT)) {
              arg0K0 = 64;
              goto L20531;}
            else {
              if ((type_2401X == NO_EVENT)) {
                arg0K0 = 0;
                goto L20531;}
              else {
                if ((type_2401X == ERROR_EVENT)) {
                  ps_write_string("OS error while getting event", (stderr));
                  { long ignoreXX;
                  PS_WRITE_CHAR(10, (stderr), ignoreXX) }
                  ps_write_string((ps_error_string(status_2403X)), (stderr));
                  { long ignoreXX;
                  PS_WRITE_CHAR(10, (stderr), ignoreXX) }
                  arg0K0 = 0;
                  goto L20531;}
                else {
                  ps_write_string("unknown type of event", (stderr));
                  { long ignoreXX;
                  PS_WRITE_CHAR(10, (stderr), ignoreXX) }
                  arg0K0 = 0;
                  goto L20531;}}}}}}}}}
 L20511: {
  if ((0 == ((Spending_interruptsS) & (Senabled_interruptsS)))) {
    s48_Sstack_limitS = (Sreal_stack_limitS);
    if ((s48_Spending_eventsPS)) {
      s48_Sstack_limitS = (((char *) -1));
      pending_interruptP0_return_value = 0;
      goto pending_interruptP_return;}
    else {
      pending_interruptP0_return_value = 0;
      goto pending_interruptP_return;}}
  else {
    pending_interruptP0_return_value = 1;
    goto pending_interruptP_return;}}
 L20531: {
  interrupt_bit_2404X = arg0K0;
  Spending_interruptsS = ((Spending_interruptsS) | interrupt_bit_2404X);
  if ((type_2401X == NO_EVENT)) {
    goto L20511;}
  else {
    goto L20525;}}
 pending_interruptP_return:
  switch (pending_interruptP_return_tag) {
  case 0: goto pending_interruptP_return_0;
  case 1: goto pending_interruptP_return_1;
  case 2: goto pending_interruptP_return_2;
  case 3: goto pending_interruptP_return_3;
  case 4: goto pending_interruptP_return_4;
  case 5: goto pending_interruptP_return_5;
  default: goto pending_interruptP_return_6;
  }}

 make_closure: {
  a_888X = merged_arg0K0;
  b_889X = merged_arg0K1;{
  addr_2405X = s48_allocate_small(12);
  *((long *) addr_2405X) = (long) (2062);
  x_2406X = 3 + (((long) (addr_2405X + 4)));
  *((long *) (((char *) (-3 + x_2406X)))) = (long) (a_888X);
  *((long *) ((((char *) (-3 + x_2406X))) + 4)) = (long) (b_889X);
  if ((3 == (3 & x_2406X))) {
    if ((0 == (128 & (*((long *) ((((char *) (-3 + x_2406X))) + -4)))))) {
      *((long *) ((((char *) (-3 + x_2406X))) + -4)) = (long) ((128 | (*((long *) ((((char *) (-3 + x_2406X))) + -4)))));
      make_closure0_return_value = x_2406X;
      goto make_closure_return;}
    else {
      make_closure0_return_value = x_2406X;
      goto make_closure_return;}}
  else {
    make_closure0_return_value = x_2406X;
    goto make_closure_return;}}
 make_closure_return:
  switch (make_closure_return_tag) {
  case 0: goto make_closure_return_0;
  default: goto make_closure_return_1;
  }}

 get_current_port: {
  marker_887X = merged_arg0K0;{
  thread_2407X = Scurrent_threadS;
  if ((3 == (3 & thread_2407X))) {
    if ((9 == (31 & ((((*((long *) ((((char *) (-3 + thread_2407X))) + -4))))>>2))))) {
      if ((1 < ((((3 + ((long)(((unsigned long)(*((long *) ((((char *) (-3 + thread_2407X))) + -4))))>>8))))>>2)))) {
        arg0K0 = (*((long *) ((((char *) (-3 + thread_2407X))) + 4)));
        goto L18429;}
      else {
        goto L18479;}}
    else {
      goto L18479;}}
  else {
    goto L18479;}}
 L18429: {
  env_2408X = arg0K0;
  if ((3 == (3 & env_2408X))) {
    if ((0 == (31 & ((((*((long *) ((((char *) (-3 + env_2408X))) + -4))))>>2))))) {
      obj_2409X = *((long *) (((char *) (-3 + env_2408X))));
      if ((3 == (3 & obj_2409X))) {
        if ((0 == (31 & ((((*((long *) ((((char *) (-3 + obj_2409X))) + -4))))>>2))))) {
          if ((marker_887X == (*((long *) (((char *) (-3 + (*((long *) (((char *) (-3 + env_2408X)))))))))))) {
            get_current_port0_return_value = (*((long *) ((((char *) (-3 + (*((long *) (((char *) (-3 + env_2408X)))))))) + 4)));
            goto get_current_port_return;}
          else {
            arg0K0 = (*((long *) ((((char *) (-3 + env_2408X))) + 4)));
            goto L18429;}}
        else {
          goto L18501;}}
      else {
        goto L18501;}}
    else {
      goto L18501;}}
  else {
    goto L18501;}}
 L18479: {
  ps_error("current thread is not a record", 0);
  get_current_port0_return_value = v_2410X;
  goto get_current_port_return;}
 L18501: {
  if ((25 == env_2408X)) {
    if (((((marker_887X)>>2)) == 1)) {
      arg5K0 = "dynamic environment doesn't have current-output-port";
      goto L18455;}
    else {
      arg5K0 = "dynamic environment doesn't have current-input-port";
      goto L18455;}}
  else {
    ps_error("dynamic environment is not a proper list", 0);
    goto get_current_port_return;}}
 L18455: {
  v_2411X = arg5K0;
  ps_error(v_2411X, 0);
  goto get_current_port_return;}
 get_current_port_return:
  switch (get_current_port_return_tag) {
  case 0: goto get_current_port_return_0;
  case 1: goto get_current_port_return_1;
  case 2: goto get_current_port_return_2;
  case 3: goto get_current_port_return_3;
  case 4: goto get_current_port_return_4;
  default: goto get_current_port_return_5;
  }}

 okay_argument_list: {
  list_886X = merged_arg0K0;{
  arg0K0 = list_886X;
  arg0K1 = 0;
  arg0K2 = list_886X;
  arg4K3 = 0;
  goto L18296;}
 L18296: {
  fast_2412X = arg0K0;
  len_2413X = arg0K1;
  slow_2414X = arg0K2;
  move_slowP_2415X = arg4K3;
  if ((25 == fast_2412X)) {
    okay_argument_list0_return_value = 1;
    okay_argument_list1_return_value = len_2413X;
    goto okay_argument_list_return;}
  else {
    if ((3 == (3 & fast_2412X))) {
      if ((0 == (31 & ((((*((long *) ((((char *) (-3 + fast_2412X))) + -4))))>>2))))) {
        if (move_slowP_2415X) {
          if ((fast_2412X == slow_2414X)) {
            okay_argument_list0_return_value = 0;
            okay_argument_list1_return_value = 0;
            goto okay_argument_list_return;}
          else {
            arg0K0 = (*((long *) ((((char *) (-3 + fast_2412X))) + 4)));
            arg0K1 = (1 + len_2413X);
            arg0K2 = (*((long *) ((((char *) (-3 + slow_2414X))) + 4)));
            arg4K3 = 0;
            goto L18296;}}
        else {
          arg0K0 = (*((long *) ((((char *) (-3 + fast_2412X))) + 4)));
          arg0K1 = (1 + len_2413X);
          arg0K2 = slow_2414X;
          arg4K3 = 1;
          goto L18296;}}
      else {
        okay_argument_list0_return_value = 0;
        okay_argument_list1_return_value = 0;
        goto okay_argument_list_return;}}
    else {
      okay_argument_list0_return_value = 0;
      okay_argument_list1_return_value = 0;
      goto okay_argument_list_return;}}}
 okay_argument_list_return:
  switch (okay_argument_list_return_tag) {
  case 0: goto okay_argument_list_return_0;
  case 1: goto okay_argument_list_return_1;
  default: goto okay_argument_list_return_2;
  }}

 copy_continuation_from_heapB: {
  cont_884X = merged_arg0K0;
  stack_arg_count_885X = merged_arg0K1;{
  stack_size_2416X = -2 + ((((3 + ((long)(((unsigned long)(*((long *) ((((char *) (-3 + cont_884X))) + -4))))>>8))))>>2));
  new_cont_2417X = (Sbottom_of_stackS) + (0 - (((stack_size_2416X)<<2)));
  if ((0 == stack_arg_count_885X)) {
    SstackS = new_cont_2417X;
    goto L18125;}
  else {
    new_stack_2418X = new_cont_2417X + (0 - (((stack_arg_count_885X)<<2)));
    if ((new_stack_2418X < (SstackS))) {
      memmove((void *)new_stack_2418X, (void *)(SstackS),(((stack_arg_count_885X)<<2)));
      SstackS = new_stack_2418X;
      goto L18125;}
    else {
      goto L18125;}}}
 L18125: {
  ScontS = new_cont_2417X;
  memmove((void *)(new_cont_2417X + 4), (void *)((((char *) (-3 + cont_884X))) + 12),(-4 + (((stack_size_2416X)<<2))));
  *((long *) new_cont_2417X) = (long) ((((long) ((((char *) (-3 + (*((long *) ((((char *) (-3 + cont_884X))) + 4)))))) + ((((*((long *) (((char *) (-3 + cont_884X))))))>>2))))));
  Sheap_continuationS = (*((long *) ((((char *) (-3 + cont_884X))) + 8)));
  copy_continuation_from_heapB0_return_value = new_cont_2417X;
  goto copy_continuation_from_heapB_return;}
 copy_continuation_from_heapB_return:
  switch (copy_continuation_from_heapB_return_tag) {
  case 0: goto copy_continuation_from_heapB_return_0;
  case 1: goto copy_continuation_from_heapB_return_1;
  default: goto copy_continuation_from_heapB_return_2;
  }}

 get_error_string: {
  status_883X = merged_arg0K0;{
  string_2419X = ps_error_string(status_883X);
  x_2420X = strlen((char *) string_2419X);
  if ((x_2420X < 512)) {
    arg0K0 = x_2420X;
    goto L17110;}
  else {
    arg0K0 = 512;
    goto L17110;}}
 L17110: {
  len_2421X = arg0K0;
  len_2422X = ((len_2421X)<<2);
  addr_2423X = s48_allocate_small((4 + len_2422X));
  *((long *) addr_2423X) = (long) ((66 + (((len_2422X)<<8))));
  new_2424X = 3 + (((long) (addr_2423X + 4)));
  arg0K0 = 0;
  goto L17120;}
 L17120: {
  i_2425X = arg0K0;
  if ((i_2425X == len_2421X)) {
    get_error_string0_return_value = new_2424X;
    goto get_error_string_return;}
  else {
    c_2426X = ((unsigned char) (*(string_2419X + i_2425X)));
    arg0K0 = 0;
    arg0K1 = 0;
    arg0K2 = c_2426X;
    goto L17159;}}
 L17159: {
  bits_2427X = arg0K0;
  j_2428X = arg0K1;
  shifted_2429X = arg0K2;
  if ((j_2428X < 4)) {
    *((unsigned char *) ((((char *) (-3 + new_2424X))) + ((((i_2425X)<<2)) + j_2428X))) = (unsigned char) ((255 & shifted_2429X));
    arg0K0 = (8 + bits_2427X);
    arg0K1 = (1 + j_2428X);
    arg0K2 = ((long)(((unsigned long)shifted_2429X)>>8));
    goto L17159;}
  else {
    arg0K0 = (1 + i_2425X);
    goto L17120;}}
 get_error_string_return:
  switch (get_error_string_return_tag) {
  case 0: goto get_error_string_return_0;
  case 1: goto get_error_string_return_1;
  case 2: goto get_error_string_return_2;
  default: goto get_error_string_return_3;
  }}

 s48_pop_interrupt_state: {
{ p_2430X = *((long *) (SstackS));
  SstackS = ((SstackS) + 4);
  Senabled_interruptsS = (((p_2430X)>>2));
  if ((0 == ((Spending_interruptsS) & (Senabled_interruptsS)))) {
    s48_Sstack_limitS = (Sreal_stack_limitS);
    if ((s48_Spending_eventsPS)) {
      s48_Sstack_limitS = (((char *) -1));
      goto L13106;}
    else {
      goto L13106;}}
  else {
    s48_Sstack_limitS = (((char *) -1));
    goto L13106;}}
 L13106: {
  proposal_2431X = *((long *) (SstackS));
  SstackS = ((SstackS) + 4);
  x_2432X = Scurrent_threadS;
  addr_2433X = (((char *) (-3 + x_2432X))) + 12;S48_WRITE_BARRIER(x_2432X, addr_2433X, proposal_2431X);
  *((long *) addr_2433X) = (long) (proposal_2431X);
  goto s48_pop_interrupt_state_return;}
 s48_pop_interrupt_state_return:
  switch (s48_pop_interrupt_state_return_tag) {
  case 0: goto s48_pop_interrupt_state_return_0;
  case 1: goto s48_pop_interrupt_state_return_1;
  default: goto s48_pop_interrupt_state_return_2;
  }}

 move_args_above_contB: {
  nargs_882X = merged_arg0K0;{
  top_of_args_2434X = SstackS;
  if (((ScontS) == (top_of_args_2434X + (((nargs_882X)<<2))))) {
    goto move_args_above_contB_return;}
  else {
    SstackS = (ScontS);
    arg3K0 = ((SstackS) + -4);
    arg3K1 = (top_of_args_2434X + (-4 + (((nargs_882X)<<2))));
    goto L8687;}}
 L8687: {
  loc_2435X = arg3K0;
  arg_2436X = arg3K1;
  if ((arg_2436X < top_of_args_2434X)) {
    SstackS = ((SstackS) + (0 - (((nargs_882X)<<2))));
    goto move_args_above_contB_return;}
  else {
    *((long *) loc_2435X) = (long) ((*((long *) arg_2436X)));
    arg3K0 = (loc_2435X + -4);
    arg3K1 = (arg_2436X + -4);
    goto L8687;}}
 move_args_above_contB_return:
  switch (move_args_above_contB_return_tag) {
  case 0: goto move_args_above_contB_return_0;
  case 1: goto move_args_above_contB_return_1;
  case 2: goto move_args_above_contB_return_2;
  case 3: goto move_args_above_contB_return_3;
  case 4: goto move_args_above_contB_return_4;
  case 5: goto move_args_above_contB_return_5;
  case 6: goto move_args_above_contB_return_6;
  case 7: goto move_args_above_contB_return_7;
  default: goto move_args_above_contB_return_8;
  }}

}
long s48_call_startup_procedure(char **startup_vector_2437X, long startup_vector_length_2438X)
{
  long arg0K2;
  long arg0K1;
  long arg0K0;
  long merged_arg0K1;
  char *merged_arg5K0;

  int enter_string_return_tag;
  long enter_string0_return_value;
  char *string_2439X;
  long shifted_2496X;
  long j_2495X;
  long bits_2494X;
  long c_2493X;
  long i_2492X;
  long s_2491X;
  char * addr_2490X;
  long len_2489X;
  long len_2488X;
  long v_2487X;
  long x_2486X;
  long error_encoding_2485X;
  long output_encoding_2484X;
  long input_encoding_2483X;
  long vm_channel_2482X;
  long v_2481X;
  long channel_2480X;
  long vm_channel_2479X;
  long v_2478X;
  long channel_2477X;
  long vm_channel_2476X;
  long v_2475X;
  long channel_2474X;
  char *error_encoding_2473X;
  long v_2472X;
  char *input_encoding_2471X;
  long v_2470X;
  char *output_encoding_2469X;
  long v_2468X;
  long i_2467X;
  long length_2466X;
  long *v_2465X;
  long v_2464X;
  long v_2463X;
  long y_2462X;
  long x_2461X;
  long v_2460X;
  char * addr_2459X;
  long i_2458X;
  long x_2457X;
  long y_2456X;
  long vec_2455X;
  char * addr_2454X;
  long length_2453X;
  long len_2452X;
  char *s_2451X;
  long y_2450X;
  long x_2449X;
  long i_2448X;
  long vector_2447X;
  char * addr_2446X;
  long len_2445X;
  long count_2444X;
  long i_2443X;
  long code_2442X;
  long code_2441X;
  long code_2440X;
 {  SstackS = (Sbottom_of_stackS);
  Sheap_continuationS = 1;
  ScontS = (Sbottom_of_stackS);
  code_2440X = Sinterrupted_byte_opcode_return_codeS;
  Slast_code_calledS = code_2440X;
  Scode_pointerS = (((char *) (-3 + code_2440X)));
  code_2441X = Sinterrupted_native_call_return_codeS;
  Slast_code_calledS = code_2441X;
  Scode_pointerS = (((char *) (-3 + code_2441X)));
  code_2442X = Snative_poll_return_codeS;
  Slast_code_calledS = code_2442X;
  Scode_pointerS = (((char *) (-3 + code_2442X)));
  Slast_code_pointer_resumedS = (Scode_pointerS);
  SvalS = 13;
  Scurrent_threadS = 25;SHARED_SETB((Ssession_dataS), 25);SHARED_SETB((Sexception_handlersS), 25);SHARED_SETB((Sinterrupt_handlersS), 25);
  Senabled_interruptsS = 0;SHARED_SETB((Sfinalizer_alistS), 25);
  Sfinalize_theseS = 25;
  Spending_interruptsS = 0;
  s48_Spending_interruptPS = 0;
  Sos_signal_ring_startS = 0;
  Sos_signal_ring_readyS = 0;
  Sos_signal_ring_endS = 0;
  Sinterrupted_templateS = 1;
  arg0K0 = 0;
  arg0K1 = 0;
  goto L20337;}
 L20337: {
  i_2443X = arg0K0;
  count_2444X = arg0K1;
  if ((i_2443X == startup_vector_length_2438X)) {s48_make_availableAgc(((((((1 + startup_vector_length_2438X) + startup_vector_length_2438X) + ((((3 + count_2444X))>>2))))<<2)));
    len_2445X = ((startup_vector_length_2438X)<<2);
    addr_2446X = s48_allocate_small((4 + len_2445X));
    *((long *) addr_2446X) = (long) ((10 + (((len_2445X)<<8))));
    vector_2447X = 3 + (((long) (addr_2446X + 4)));
    arg0K0 = 0;
    goto L20454;}
  else {
    arg0K0 = (1 + i_2443X);
    arg0K1 = (1 + (count_2444X + (strlen((char *) (*(startup_vector_2437X + i_2443X))))));
    goto L20337;}}
 L20454: {
  i_2448X = arg0K0;
  if ((i_2448X == startup_vector_length_2438X)) {
    SstackS = ((SstackS) + -4);
    *((long *) (SstackS)) = (long) (vector_2447X);
    x_2449X = STDOUT_FD();
    y_2450X = STDERR_FD();
    if ((x_2449X < y_2450X)) {
      arg0K0 = y_2450X;
      goto L26402;}
    else {
      arg0K0 = x_2449X;
      goto L26402;}}
  else {
    s_2451X = *(startup_vector_2437X + i_2448X);
    len_2452X = strlen((char *) s_2451X);
    length_2453X = 1 + len_2452X;
    addr_2454X = s48_allocate_small((4 + length_2453X));
    *((long *) addr_2454X) = (long) ((70 + (((length_2453X)<<8))));
    vec_2455X = 3 + (((long) (addr_2454X + 4)));
    arg0K0 = 0;
    goto L20474;}}
 L26402: {
  y_2456X = arg0K0;
  x_2457X = STDIN_FD();
  if ((x_2457X < y_2456X)) {
    arg0K0 = y_2456X;
    goto L26404;}
  else {
    arg0K0 = x_2457X;
    goto L26404;}}
 L20474: {
  i_2458X = arg0K0;
  if ((len_2452X < i_2458X)) {
    addr_2459X = (((char *) (-3 + vector_2447X))) + (((i_2448X)<<2));S48_WRITE_BARRIER(vector_2447X, addr_2459X, vec_2455X);
    *((long *) addr_2459X) = (long) (vec_2455X);
    arg0K0 = (1 + i_2448X);
    goto L20454;}
  else {
    *((unsigned char *) ((((char *) (-3 + vec_2455X))) + i_2458X)) = (unsigned char) ((((unsigned char) (*(s_2451X + i_2458X)))));
    arg0K0 = (1 + i_2458X);
    goto L20474;}}
 L26404: {
  v_2460X = arg0K0;
  x_2461X = Snumber_of_channelsS;
  y_2462X = 1 + v_2460X;
  if ((x_2461X < y_2462X)) {
    arg0K0 = y_2462X;
    goto L26406;}
  else {
    arg0K0 = x_2461X;
    goto L26406;}}
 L26406: {
  v_2463X = arg0K0;
  Snumber_of_channelsS = v_2463X;
  v_2464X = STDIN_FD();
  Svm_channelsS = ((long*)malloc(sizeof(long) * (Snumber_of_channelsS)));
  Spending_channels_headS = 1;
  Spending_channels_tailS = 1;
  if ((NULL == (Svm_channelsS))) {
    ps_error("out of memory, unable to continue", 0);
    goto L26428;}
  else {
    goto L26428;}}
 L26428: {
  v_2465X = Svm_channelsS;
  length_2466X = Snumber_of_channelsS;
  arg0K0 = 0;
  goto L26528;}
 L26528: {
  i_2467X = arg0K0;
  if ((i_2467X < length_2466X)) {
    *(v_2465X + i_2467X) = 1;
    arg0K0 = (1 + i_2467X);
    goto L26528;}
  else {
    v_2468X = STDOUT_FD();
    output_encoding_2469X = ps_console_encoding(v_2468X);
    v_2470X = STDIN_FD();
    input_encoding_2471X = ps_console_encoding(v_2470X);
    v_2472X = STDERR_FD();
    error_encoding_2473X = ps_console_encoding(v_2472X);
    if ((NULL == input_encoding_2471X)) {
      goto L26465;}
    else {
      if ((NULL == output_encoding_2469X)) {
        goto L26465;}
      else {
        if ((NULL == error_encoding_2473X)) {
          goto L26465;}
        else {
          goto L26470;}}}}}
 L26465: {
  ps_error("out of memory, unable to continue", 0);
  goto L26470;}
 L26470: {
s48_make_availableAgc(((((3 * (12 + (((((((3 + ((((strlen((char *) "standard output")))<<2))))>>2)) + ((((3 + ((((strlen((char *) input_encoding_2471X)))<<2))))>>2))) + ((((3 + ((((strlen((char *) output_encoding_2469X)))<<2))))>>2))) + ((((3 + ((((strlen((char *) error_encoding_2473X)))<<2))))>>2))))))<<2)));
  channel_2474X = STDERR_FD();
  merged_arg5K0 = "standard error";
  merged_arg0K1 = 0;
  enter_string_return_tag = 0;
  goto enter_string;
 enter_string_return_0:
  v_2475X = enter_string0_return_value;
  vm_channel_2476X = make_channel(8, v_2475X, (((channel_2474X)<<2)), 1, 1, 1, 1, 0);
  *((Svm_channelsS) + channel_2474X) = vm_channel_2476X;
  channel_2477X = STDIN_FD();
  merged_arg5K0 = "standard input";
  merged_arg0K1 = 0;
  enter_string_return_tag = 1;
  goto enter_string;
 enter_string_return_1:
  v_2478X = enter_string0_return_value;
  vm_channel_2479X = make_channel(4, v_2478X, (((channel_2477X)<<2)), 1, 1, 1, 1, 0);
  *((Svm_channelsS) + channel_2477X) = vm_channel_2479X;
  channel_2480X = STDOUT_FD();
  merged_arg5K0 = "standard output";
  merged_arg0K1 = 0;
  enter_string_return_tag = 2;
  goto enter_string;
 enter_string_return_2:
  v_2481X = enter_string0_return_value;
  vm_channel_2482X = make_channel(8, v_2481X, (((channel_2480X)<<2)), 1, 1, 1, 1, 0);
  *((Svm_channelsS) + channel_2480X) = vm_channel_2482X;
  merged_arg5K0 = input_encoding_2471X;
  merged_arg0K1 = 0;
  enter_string_return_tag = 3;
  goto enter_string;
 enter_string_return_3:
  input_encoding_2483X = enter_string0_return_value;
  merged_arg5K0 = output_encoding_2469X;
  merged_arg0K1 = 0;
  enter_string_return_tag = 4;
  goto enter_string;
 enter_string_return_4:
  output_encoding_2484X = enter_string0_return_value;
  merged_arg5K0 = error_encoding_2473X;
  merged_arg0K1 = 0;
  enter_string_return_tag = 5;
  goto enter_string;
 enter_string_return_5:
  error_encoding_2485X = enter_string0_return_value;
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (vm_channel_2479X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (input_encoding_2483X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (vm_channel_2482X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (output_encoding_2484X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (vm_channel_2476X);
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (error_encoding_2485X);
  x_2486X = s48_resumer_records();
  SstackS = ((SstackS) + -4);
  *((long *) (SstackS)) = (long) (x_2486X);s48_initialization_completeB();
  v_2487X = s48_startup_procedure();
  return s48_restart(v_2487X, 8);}
 enter_string: {
  string_2439X = merged_arg5K0;{
  len_2488X = strlen((char *) string_2439X);
  len_2489X = ((len_2488X)<<2);
  addr_2490X = s48_allocate_small((4 + len_2489X));
  *((long *) addr_2490X) = (long) ((66 + (((len_2489X)<<8))));
  s_2491X = 3 + (((long) (addr_2490X + 4)));
  arg0K0 = 0;
  goto L17704;}
 L17704: {
  i_2492X = arg0K0;
  if ((i_2492X < len_2488X)) {
    c_2493X = ((unsigned char) (*(string_2439X + i_2492X)));
    arg0K0 = 0;
    arg0K1 = 0;
    arg0K2 = c_2493X;
    goto L17715;}
  else {
    enter_string0_return_value = s_2491X;
    goto enter_string_return;}}
 L17715: {
  bits_2494X = arg0K0;
  j_2495X = arg0K1;
  shifted_2496X = arg0K2;
  if ((j_2495X < 4)) {
    *((unsigned char *) ((((char *) (-3 + s_2491X))) + ((((i_2492X)<<2)) + j_2495X))) = (unsigned char) ((255 & shifted_2496X));
    arg0K0 = (8 + bits_2494X);
    arg0K1 = (1 + j_2495X);
    arg0K2 = ((long)(((unsigned long)shifted_2496X)>>8));
    goto L17715;}
  else {
    arg0K0 = (1 + i_2492X);
    goto L17704;}}
 enter_string_return:
  switch (enter_string_return_tag) {
  case 0: goto enter_string_return_0;
  case 1: goto enter_string_return_1;
  case 2: goto enter_string_return_2;
  case 3: goto enter_string_return_3;
  case 4: goto enter_string_return_4;
  default: goto enter_string_return_5;
  }}

}
long s48_external_event_uid(void)
{
  long uid_2497X;
 {  uid_2497X = unused_event_type_uid();
  if ((-1 == uid_2497X)) {
    return uid_2497X;}
  else {use_event_type_uidB(uid_2497X);
    return uid_2497X;}}
}
long s48_permanent_external_event_uid(char *name_2498X)
{
  char * addr_2511X;
  long val_2510X;
  long uid_2509X;
  char * addr_2508X;
  long val_2507X;
  char v_2506X;
  char * addr_2505X;
  long val_2504X;
  long uid_2503X;
  long uid_val_2502X;
  long binding_2501X;
  long value_2500X;
  long value_2499X;
 {  value_2499X = enter_stringAgc_n(name_2498X, (strlen((char *) name_2498X)));
  Stemp0S = value_2499X;s48_make_availableAgc(20);
  value_2500X = Stemp0S;
  Stemp0S = 1;
  binding_2501X = Hlookup814((Simported_bindingsS), value_2500X, 0);
  uid_val_2502X = *((long *) ((((char *) (-3 + binding_2501X))) + 8));
  if ((0 == (3 & uid_val_2502X))) {
    uid_2503X = ((uid_val_2502X)>>2);
    if ((uid_2503X < (Snumber_of_event_typesS))) {
      val_2504X = ((uid_2503X)<<2);
      addr_2505X = (((char *) (-3 + binding_2501X))) + 8;S48_WRITE_BARRIER(binding_2501X, addr_2505X, val_2504X);
      *((long *) addr_2505X) = (long) (val_2504X);use_event_type_uidB(uid_2503X);
      return uid_2503X;}
    else {
      v_2506X = add_external_event_types((1 + uid_2503X));
      if (v_2506X) {
        val_2507X = ((uid_2503X)<<2);
        addr_2508X = (((char *) (-3 + binding_2501X))) + 8;S48_WRITE_BARRIER(binding_2501X, addr_2508X, val_2507X);
        *((long *) addr_2508X) = (long) (val_2507X);use_event_type_uidB(uid_2503X);
        return uid_2503X;}
      else {
        return -1;}}}
  else {
    uid_2509X = unused_event_type_uid();
    if ((-1 == uid_2509X)) {
      return uid_2509X;}
    else {
      val_2510X = ((uid_2509X)<<2);
      addr_2511X = (((char *) (-3 + binding_2501X))) + 8;S48_WRITE_BARRIER(binding_2501X, addr_2511X, val_2510X);
      *((long *) addr_2511X) = (long) (val_2510X);use_event_type_uidB(uid_2509X);
      return uid_2509X;}}}
}void
s48_init(void)
{
Snumber_of_channelsS = 100;
Spending_channels_headS = 1;
Spending_channels_tailS = 1;
Sutf_8_state_tableS = malloc(128 * sizeof(long));
Sutf_8_state_tableS[0] = 0;
Sutf_8_state_tableS[1] = 0;
Sutf_8_state_tableS[2] = 0;
Sutf_8_state_tableS[3] = 0;
Sutf_8_state_tableS[4] = 0;
Sutf_8_state_tableS[5] = 0;
Sutf_8_state_tableS[6] = 0;
Sutf_8_state_tableS[7] = 0;
Sutf_8_state_tableS[8] = 0;
Sutf_8_state_tableS[9] = 0;
Sutf_8_state_tableS[10] = 0;
Sutf_8_state_tableS[11] = 0;
Sutf_8_state_tableS[12] = 0;
Sutf_8_state_tableS[13] = 0;
Sutf_8_state_tableS[14] = 0;
Sutf_8_state_tableS[15] = 0;
Sutf_8_state_tableS[16] = -1;
Sutf_8_state_tableS[17] = -1;
Sutf_8_state_tableS[18] = -1;
Sutf_8_state_tableS[19] = -1;
Sutf_8_state_tableS[20] = -1;
Sutf_8_state_tableS[21] = -1;
Sutf_8_state_tableS[22] = -1;
Sutf_8_state_tableS[23] = -1;
Sutf_8_state_tableS[24] = 1;
Sutf_8_state_tableS[25] = 1;
Sutf_8_state_tableS[26] = 1;
Sutf_8_state_tableS[27] = 1;
Sutf_8_state_tableS[28] = 2;
Sutf_8_state_tableS[29] = 2;
Sutf_8_state_tableS[30] = 3;
Sutf_8_state_tableS[31] = -1;
Sutf_8_state_tableS[32] = -2;
Sutf_8_state_tableS[33] = -2;
Sutf_8_state_tableS[34] = -2;
Sutf_8_state_tableS[35] = -2;
Sutf_8_state_tableS[36] = -2;
Sutf_8_state_tableS[37] = -2;
Sutf_8_state_tableS[38] = -2;
Sutf_8_state_tableS[39] = -2;
Sutf_8_state_tableS[40] = -2;
Sutf_8_state_tableS[41] = -2;
Sutf_8_state_tableS[42] = -2;
Sutf_8_state_tableS[43] = -2;
Sutf_8_state_tableS[44] = -2;
Sutf_8_state_tableS[45] = -2;
Sutf_8_state_tableS[46] = -2;
Sutf_8_state_tableS[47] = -2;
Sutf_8_state_tableS[48] = 0;
Sutf_8_state_tableS[49] = 0;
Sutf_8_state_tableS[50] = 0;
Sutf_8_state_tableS[51] = 0;
Sutf_8_state_tableS[52] = 0;
Sutf_8_state_tableS[53] = 0;
Sutf_8_state_tableS[54] = 0;
Sutf_8_state_tableS[55] = 0;
Sutf_8_state_tableS[56] = -2;
Sutf_8_state_tableS[57] = -2;
Sutf_8_state_tableS[58] = -2;
Sutf_8_state_tableS[59] = -2;
Sutf_8_state_tableS[60] = -2;
Sutf_8_state_tableS[61] = -2;
Sutf_8_state_tableS[62] = -2;
Sutf_8_state_tableS[63] = -2;
Sutf_8_state_tableS[64] = -2;
Sutf_8_state_tableS[65] = -2;
Sutf_8_state_tableS[66] = -2;
Sutf_8_state_tableS[67] = -2;
Sutf_8_state_tableS[68] = -2;
Sutf_8_state_tableS[69] = -2;
Sutf_8_state_tableS[70] = -2;
Sutf_8_state_tableS[71] = -2;
Sutf_8_state_tableS[72] = -2;
Sutf_8_state_tableS[73] = -2;
Sutf_8_state_tableS[74] = -2;
Sutf_8_state_tableS[75] = -2;
Sutf_8_state_tableS[76] = -2;
Sutf_8_state_tableS[77] = -2;
Sutf_8_state_tableS[78] = -2;
Sutf_8_state_tableS[79] = -2;
Sutf_8_state_tableS[80] = 1;
Sutf_8_state_tableS[81] = 1;
Sutf_8_state_tableS[82] = 1;
Sutf_8_state_tableS[83] = 1;
Sutf_8_state_tableS[84] = 1;
Sutf_8_state_tableS[85] = 1;
Sutf_8_state_tableS[86] = 1;
Sutf_8_state_tableS[87] = 1;
Sutf_8_state_tableS[88] = -2;
Sutf_8_state_tableS[89] = -2;
Sutf_8_state_tableS[90] = -2;
Sutf_8_state_tableS[91] = -2;
Sutf_8_state_tableS[92] = -2;
Sutf_8_state_tableS[93] = -2;
Sutf_8_state_tableS[94] = -2;
Sutf_8_state_tableS[95] = -2;
Sutf_8_state_tableS[96] = -2;
Sutf_8_state_tableS[97] = -2;
Sutf_8_state_tableS[98] = -2;
Sutf_8_state_tableS[99] = -2;
Sutf_8_state_tableS[100] = -2;
Sutf_8_state_tableS[101] = -2;
Sutf_8_state_tableS[102] = -2;
Sutf_8_state_tableS[103] = -2;
Sutf_8_state_tableS[104] = -2;
Sutf_8_state_tableS[105] = -2;
Sutf_8_state_tableS[106] = -2;
Sutf_8_state_tableS[107] = -2;
Sutf_8_state_tableS[108] = -2;
Sutf_8_state_tableS[109] = -2;
Sutf_8_state_tableS[110] = -2;
Sutf_8_state_tableS[111] = -2;
Sutf_8_state_tableS[112] = 2;
Sutf_8_state_tableS[113] = 2;
Sutf_8_state_tableS[114] = 2;
Sutf_8_state_tableS[115] = 2;
Sutf_8_state_tableS[116] = 2;
Sutf_8_state_tableS[117] = 2;
Sutf_8_state_tableS[118] = 2;
Sutf_8_state_tableS[119] = 2;
Sutf_8_state_tableS[120] = -2;
Sutf_8_state_tableS[121] = -2;
Sutf_8_state_tableS[122] = -2;
Sutf_8_state_tableS[123] = -2;
Sutf_8_state_tableS[124] = -2;
Sutf_8_state_tableS[125] = -2;
Sutf_8_state_tableS[126] = -2;
Sutf_8_state_tableS[127] = -2;
Sutf_8_masksS = malloc(4 * sizeof(long));
Sutf_8_masksS[0] = 127;
Sutf_8_masksS[1] = 31;
Sutf_8_masksS[2] = 15;
Sutf_8_masksS[3] = 7;
Stemp0S = 1;
Stemp1S = 1;
Sstack_warningPS = 1;
Simported_bindingsS = 1;
Sexported_bindingsS = 1;
Snumber_of_event_typesS = 100;
Sgc_in_troublePS = 0;
Sos_signal_ringS = malloc(32 * sizeof(long));
Sos_signal_ringS[0] = 0;
Sos_signal_ringS[1] = 0;
Sos_signal_ringS[2] = 0;
Sos_signal_ringS[3] = 0;
Sos_signal_ringS[4] = 0;
Sos_signal_ringS[5] = 0;
Sos_signal_ringS[6] = 0;
Sos_signal_ringS[7] = 0;
Sos_signal_ringS[8] = 0;
Sos_signal_ringS[9] = 0;
Sos_signal_ringS[10] = 0;
Sos_signal_ringS[11] = 0;
Sos_signal_ringS[12] = 0;
Sos_signal_ringS[13] = 0;
Sos_signal_ringS[14] = 0;
Sos_signal_ringS[15] = 0;
Sos_signal_ringS[16] = 0;
Sos_signal_ringS[17] = 0;
Sos_signal_ringS[18] = 0;
Sos_signal_ringS[19] = 0;
Sos_signal_ringS[20] = 0;
Sos_signal_ringS[21] = 0;
Sos_signal_ringS[22] = 0;
Sos_signal_ringS[23] = 0;
Sos_signal_ringS[24] = 0;
Sos_signal_ringS[25] = 0;
Sos_signal_ringS[26] = 0;
Sos_signal_ringS[27] = 0;
Sos_signal_ringS[28] = 0;
Sos_signal_ringS[29] = 0;
Sos_signal_ringS[30] = 0;
Sos_signal_ringS[31] = 0;
Sos_signal_ring_startS = 0;
Sos_signal_ring_readyS = 0;
Sos_signal_ring_endS = 0;
Sexternal_exceptionPS = 0;
Sexternal_root_stackS = NULL;
Sexternal_root_stack_baseS = NULL;
Spermanent_external_rootsS = NULL;
Spost_gc_cleanupS = HtopD11605;
Sgc_root_procS = HtopD11616;
Snative_exception_contS = 0;
s48_Scallback_return_stack_blockS = 1;
s48_Spending_eventsPS = 0;
}
