
#define PSTRUE  (0 == 0)

#define PSFALSE (0 == 1)

#define	psbool  char		/* boolean type */
