
extern int s48_main (int argc, char ** argv);

int
main(int argc, char *argv[])
{
  return s48_main (argc, argv);
}
