#if ! defined(ENVIRON_NAME)

#define ENVIRON_NAME	s48_bogus_environ

#endif

