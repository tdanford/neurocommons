
#include <stdlib.h>

char	**s48_bogus_environ = NULL;
